package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TtHistoryDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class TtHistoryDTO   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("assigneeGroup")
  private String assigneeGroup = null;

  @JsonProperty("notes")
  private String notes = null;

  @JsonProperty("operationDate")
  private OffsetDateTime operationDate = null;

  @JsonProperty("operatorUser")
  private String operatorUser = null;

  @JsonProperty("payload")
  private String payload = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("statusReason")
  private String statusReason = null;

  @JsonProperty("ttmsOperation")
  private String ttmsOperation = null;

  @JsonProperty("ticketId")
  private String ticketId = null;

  @JsonProperty("source")
  private String source = null;

  public TtHistoryDTO id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public TtHistoryDTO assigneeGroup(String assigneeGroup) {
    this.assigneeGroup = assigneeGroup;
    return this;
  }

  /**
   * Get assigneeGroup
   * @return assigneeGroup
   **/
  @Schema(description = "")
  
    public String getAssigneeGroup() {
    return assigneeGroup;
  }

  public void setAssigneeGroup(String assigneeGroup) {
    this.assigneeGroup = assigneeGroup;
  }

  public TtHistoryDTO notes(String notes) {
    this.notes = notes;
    return this;
  }

  /**
   * Get notes
   * @return notes
   **/
  @Schema(description = "")
  
    public String getNotes() {
    return notes;
  }

  public void setNotes(String notes) {
    this.notes = notes;
  }

  public TtHistoryDTO operationDate(OffsetDateTime operationDate) {
    this.operationDate = operationDate;
    return this;
  }

  /**
   * Get operationDate
   * @return operationDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOperationDate() {
    return operationDate;
  }

  public void setOperationDate(OffsetDateTime operationDate) {
    this.operationDate = operationDate;
  }

  public TtHistoryDTO operatorUser(String operatorUser) {
    this.operatorUser = operatorUser;
    return this;
  }

  /**
   * Get operatorUser
   * @return operatorUser
   **/
  @Schema(description = "")
  
    public String getOperatorUser() {
    return operatorUser;
  }

  public void setOperatorUser(String operatorUser) {
    this.operatorUser = operatorUser;
  }

  public TtHistoryDTO payload(String payload) {
    this.payload = payload;
    return this;
  }

  /**
   * Get payload
   * @return payload
   **/
  @Schema(description = "")
  
    public String getPayload() {
    return payload;
  }

  public void setPayload(String payload) {
    this.payload = payload;
  }

  public TtHistoryDTO status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  @Schema(description = "")
  
    public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public TtHistoryDTO statusReason(String statusReason) {
    this.statusReason = statusReason;
    return this;
  }

  /**
   * Get statusReason
   * @return statusReason
   **/
  @Schema(description = "")
  
    public String getStatusReason() {
    return statusReason;
  }

  public void setStatusReason(String statusReason) {
    this.statusReason = statusReason;
  }

  public TtHistoryDTO ttmsOperation(String ttmsOperation) {
    this.ttmsOperation = ttmsOperation;
    return this;
  }

  /**
   * Get ttmsOperation
   * @return ttmsOperation
   **/
  @Schema(description = "")
  
    public String getTtmsOperation() {
    return ttmsOperation;
  }

  public void setTtmsOperation(String ttmsOperation) {
    this.ttmsOperation = ttmsOperation;
  }

  public TtHistoryDTO ticketId(String ticketId) {
    this.ticketId = ticketId;
    return this;
  }

  /**
   * Get ticketId
   * @return ticketId
   **/
  @Schema(description = "")
  
    public String getTicketId() {
    return ticketId;
  }

  public void setTicketId(String ticketId) {
    this.ticketId = ticketId;
  }

  public TtHistoryDTO source(String source) {
    this.source = source;
    return this;
  }

  /**
   * Get source
   * @return source
   **/
  @Schema(description = "")
  
    public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TtHistoryDTO ttHistoryDTO = (TtHistoryDTO) o;
    return Objects.equals(this.id, ttHistoryDTO.id) &&
        Objects.equals(this.assigneeGroup, ttHistoryDTO.assigneeGroup) &&
        Objects.equals(this.notes, ttHistoryDTO.notes) &&
        Objects.equals(this.operationDate, ttHistoryDTO.operationDate) &&
        Objects.equals(this.operatorUser, ttHistoryDTO.operatorUser) &&
        Objects.equals(this.payload, ttHistoryDTO.payload) &&
        Objects.equals(this.status, ttHistoryDTO.status) &&
        Objects.equals(this.statusReason, ttHistoryDTO.statusReason) &&
        Objects.equals(this.ttmsOperation, ttHistoryDTO.ttmsOperation) &&
        Objects.equals(this.ticketId, ttHistoryDTO.ticketId) &&
        Objects.equals(this.source, ttHistoryDTO.source);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, assigneeGroup, notes, operationDate, operatorUser, payload, status, statusReason, ttmsOperation, ticketId, source);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TtHistoryDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    assigneeGroup: ").append(toIndentedString(assigneeGroup)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    operationDate: ").append(toIndentedString(operationDate)).append("\n");
    sb.append("    operatorUser: ").append(toIndentedString(operatorUser)).append("\n");
    sb.append("    payload: ").append(toIndentedString(payload)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    statusReason: ").append(toIndentedString(statusReason)).append("\n");
    sb.append("    ttmsOperation: ").append(toIndentedString(ttmsOperation)).append("\n");
    sb.append("    ticketId: ").append(toIndentedString(ticketId)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
