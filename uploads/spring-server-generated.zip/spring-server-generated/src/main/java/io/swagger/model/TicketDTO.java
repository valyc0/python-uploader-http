package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TicketDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class TicketDTO   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("blkWorkOrderNumber")
  private String blkWorkOrderNumber = null;

  @JsonProperty("blkWorkOrderNumber2")
  private String blkWorkOrderNumber2 = null;

  @JsonProperty("blkWorkOrderNumber3")
  private String blkWorkOrderNumber3 = null;

  @JsonProperty("carrierBlock")
  private String carrierBlock = null;

  @JsonProperty("createDate")
  private OffsetDateTime createDate = null;

  @JsonProperty("creatorGroup")
  private String creatorGroup = null;

  @JsonProperty("creatorUser")
  private String creatorUser = null;

  @JsonProperty("dtblockByWorkOrder")
  private OffsetDateTime dtblockByWorkOrder = null;

  @JsonProperty("endDateOccurs")
  private OffsetDateTime endDateOccurs = null;

  @JsonProperty("holdMkvnResponse")
  private String holdMkvnResponse = null;

  @JsonProperty("lastModifiedDate")
  private OffsetDateTime lastModifiedDate = null;

  @JsonProperty("marketingRequestDate")
  private OffsetDateTime marketingRequestDate = null;

  @JsonProperty("marketingRequestType")
  private String marketingRequestType = null;

  @JsonProperty("nmBlockDate")
  private OffsetDateTime nmBlockDate = null;

  @JsonProperty("nmBlockType")
  private String nmBlockType = null;

  @JsonProperty("nmNumberingRange")
  private String nmNumberingRange = null;

  @JsonProperty("notes")
  private String notes = null;

  @JsonProperty("ownerGroup")
  private String ownerGroup = null;

  @JsonProperty("sourceType")
  private String sourceType = null;

  @JsonProperty("phoneNumberBlock")
  private String phoneNumberBlock = null;

  @JsonProperty("reasonForClosure")
  private String reasonForClosure = null;

  @JsonProperty("reportedByCategory")
  private String reportedByCategory = null;

  @JsonProperty("reportedBySubcategory")
  private String reportedBySubcategory = null;

  @JsonProperty("reportedDatetime")
  private OffsetDateTime reportedDatetime = null;

  @JsonProperty("routingDestination")
  private String routingDestination = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("statusReason")
  private String statusReason = null;

  @JsonProperty("ticketClosureDate")
  private OffsetDateTime ticketClosureDate = null;

  @JsonProperty("totalMinutes")
  private Integer totalMinutes = null;

  @JsonProperty("verificationAction")
  private String verificationAction = null;

  @JsonProperty("reopenTrafficDate")
  private OffsetDateTime reopenTrafficDate = null;

  public TicketDTO id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public TicketDTO blkWorkOrderNumber(String blkWorkOrderNumber) {
    this.blkWorkOrderNumber = blkWorkOrderNumber;
    return this;
  }

  /**
   * Get blkWorkOrderNumber
   * @return blkWorkOrderNumber
   **/
  @Schema(description = "")
  
    public String getBlkWorkOrderNumber() {
    return blkWorkOrderNumber;
  }

  public void setBlkWorkOrderNumber(String blkWorkOrderNumber) {
    this.blkWorkOrderNumber = blkWorkOrderNumber;
  }

  public TicketDTO blkWorkOrderNumber2(String blkWorkOrderNumber2) {
    this.blkWorkOrderNumber2 = blkWorkOrderNumber2;
    return this;
  }

  /**
   * Get blkWorkOrderNumber2
   * @return blkWorkOrderNumber2
   **/
  @Schema(description = "")
  
    public String getBlkWorkOrderNumber2() {
    return blkWorkOrderNumber2;
  }

  public void setBlkWorkOrderNumber2(String blkWorkOrderNumber2) {
    this.blkWorkOrderNumber2 = blkWorkOrderNumber2;
  }

  public TicketDTO blkWorkOrderNumber3(String blkWorkOrderNumber3) {
    this.blkWorkOrderNumber3 = blkWorkOrderNumber3;
    return this;
  }

  /**
   * Get blkWorkOrderNumber3
   * @return blkWorkOrderNumber3
   **/
  @Schema(description = "")
  
    public String getBlkWorkOrderNumber3() {
    return blkWorkOrderNumber3;
  }

  public void setBlkWorkOrderNumber3(String blkWorkOrderNumber3) {
    this.blkWorkOrderNumber3 = blkWorkOrderNumber3;
  }

  public TicketDTO carrierBlock(String carrierBlock) {
    this.carrierBlock = carrierBlock;
    return this;
  }

  /**
   * Get carrierBlock
   * @return carrierBlock
   **/
  @Schema(description = "")
  
    public String getCarrierBlock() {
    return carrierBlock;
  }

  public void setCarrierBlock(String carrierBlock) {
    this.carrierBlock = carrierBlock;
  }

  public TicketDTO createDate(OffsetDateTime createDate) {
    this.createDate = createDate;
    return this;
  }

  /**
   * Get createDate
   * @return createDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getCreateDate() {
    return createDate;
  }

  public void setCreateDate(OffsetDateTime createDate) {
    this.createDate = createDate;
  }

  public TicketDTO creatorGroup(String creatorGroup) {
    this.creatorGroup = creatorGroup;
    return this;
  }

  /**
   * Get creatorGroup
   * @return creatorGroup
   **/
  @Schema(description = "")
  
    public String getCreatorGroup() {
    return creatorGroup;
  }

  public void setCreatorGroup(String creatorGroup) {
    this.creatorGroup = creatorGroup;
  }

  public TicketDTO creatorUser(String creatorUser) {
    this.creatorUser = creatorUser;
    return this;
  }

  /**
   * Get creatorUser
   * @return creatorUser
   **/
  @Schema(description = "")
  
    public String getCreatorUser() {
    return creatorUser;
  }

  public void setCreatorUser(String creatorUser) {
    this.creatorUser = creatorUser;
  }

  public TicketDTO dtblockByWorkOrder(OffsetDateTime dtblockByWorkOrder) {
    this.dtblockByWorkOrder = dtblockByWorkOrder;
    return this;
  }

  /**
   * Get dtblockByWorkOrder
   * @return dtblockByWorkOrder
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDtblockByWorkOrder() {
    return dtblockByWorkOrder;
  }

  public void setDtblockByWorkOrder(OffsetDateTime dtblockByWorkOrder) {
    this.dtblockByWorkOrder = dtblockByWorkOrder;
  }

  public TicketDTO endDateOccurs(OffsetDateTime endDateOccurs) {
    this.endDateOccurs = endDateOccurs;
    return this;
  }

  /**
   * Get endDateOccurs
   * @return endDateOccurs
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getEndDateOccurs() {
    return endDateOccurs;
  }

  public void setEndDateOccurs(OffsetDateTime endDateOccurs) {
    this.endDateOccurs = endDateOccurs;
  }

  public TicketDTO holdMkvnResponse(String holdMkvnResponse) {
    this.holdMkvnResponse = holdMkvnResponse;
    return this;
  }

  /**
   * Get holdMkvnResponse
   * @return holdMkvnResponse
   **/
  @Schema(description = "")
  
    public String getHoldMkvnResponse() {
    return holdMkvnResponse;
  }

  public void setHoldMkvnResponse(String holdMkvnResponse) {
    this.holdMkvnResponse = holdMkvnResponse;
  }

  public TicketDTO lastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public TicketDTO marketingRequestDate(OffsetDateTime marketingRequestDate) {
    this.marketingRequestDate = marketingRequestDate;
    return this;
  }

  /**
   * Get marketingRequestDate
   * @return marketingRequestDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getMarketingRequestDate() {
    return marketingRequestDate;
  }

  public void setMarketingRequestDate(OffsetDateTime marketingRequestDate) {
    this.marketingRequestDate = marketingRequestDate;
  }

  public TicketDTO marketingRequestType(String marketingRequestType) {
    this.marketingRequestType = marketingRequestType;
    return this;
  }

  /**
   * Get marketingRequestType
   * @return marketingRequestType
   **/
  @Schema(description = "")
  
    public String getMarketingRequestType() {
    return marketingRequestType;
  }

  public void setMarketingRequestType(String marketingRequestType) {
    this.marketingRequestType = marketingRequestType;
  }

  public TicketDTO nmBlockDate(OffsetDateTime nmBlockDate) {
    this.nmBlockDate = nmBlockDate;
    return this;
  }

  /**
   * Get nmBlockDate
   * @return nmBlockDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getNmBlockDate() {
    return nmBlockDate;
  }

  public void setNmBlockDate(OffsetDateTime nmBlockDate) {
    this.nmBlockDate = nmBlockDate;
  }

  public TicketDTO nmBlockType(String nmBlockType) {
    this.nmBlockType = nmBlockType;
    return this;
  }

  /**
   * Get nmBlockType
   * @return nmBlockType
   **/
  @Schema(description = "")
  
    public String getNmBlockType() {
    return nmBlockType;
  }

  public void setNmBlockType(String nmBlockType) {
    this.nmBlockType = nmBlockType;
  }

  public TicketDTO nmNumberingRange(String nmNumberingRange) {
    this.nmNumberingRange = nmNumberingRange;
    return this;
  }

  /**
   * Get nmNumberingRange
   * @return nmNumberingRange
   **/
  @Schema(description = "")
  
    public String getNmNumberingRange() {
    return nmNumberingRange;
  }

  public void setNmNumberingRange(String nmNumberingRange) {
    this.nmNumberingRange = nmNumberingRange;
  }

  public TicketDTO notes(String notes) {
    this.notes = notes;
    return this;
  }

  /**
   * Get notes
   * @return notes
   **/
  @Schema(description = "")
  
    public String getNotes() {
    return notes;
  }

  public void setNotes(String notes) {
    this.notes = notes;
  }

  public TicketDTO ownerGroup(String ownerGroup) {
    this.ownerGroup = ownerGroup;
    return this;
  }

  /**
   * Get ownerGroup
   * @return ownerGroup
   **/
  @Schema(description = "")
  
    public String getOwnerGroup() {
    return ownerGroup;
  }

  public void setOwnerGroup(String ownerGroup) {
    this.ownerGroup = ownerGroup;
  }

  public TicketDTO sourceType(String sourceType) {
    this.sourceType = sourceType;
    return this;
  }

  /**
   * Get sourceType
   * @return sourceType
   **/
  @Schema(description = "")
  
    public String getSourceType() {
    return sourceType;
  }

  public void setSourceType(String sourceType) {
    this.sourceType = sourceType;
  }

  public TicketDTO phoneNumberBlock(String phoneNumberBlock) {
    this.phoneNumberBlock = phoneNumberBlock;
    return this;
  }

  /**
   * Get phoneNumberBlock
   * @return phoneNumberBlock
   **/
  @Schema(description = "")
  
    public String getPhoneNumberBlock() {
    return phoneNumberBlock;
  }

  public void setPhoneNumberBlock(String phoneNumberBlock) {
    this.phoneNumberBlock = phoneNumberBlock;
  }

  public TicketDTO reasonForClosure(String reasonForClosure) {
    this.reasonForClosure = reasonForClosure;
    return this;
  }

  /**
   * Get reasonForClosure
   * @return reasonForClosure
   **/
  @Schema(description = "")
  
    public String getReasonForClosure() {
    return reasonForClosure;
  }

  public void setReasonForClosure(String reasonForClosure) {
    this.reasonForClosure = reasonForClosure;
  }

  public TicketDTO reportedByCategory(String reportedByCategory) {
    this.reportedByCategory = reportedByCategory;
    return this;
  }

  /**
   * Get reportedByCategory
   * @return reportedByCategory
   **/
  @Schema(description = "")
  
    public String getReportedByCategory() {
    return reportedByCategory;
  }

  public void setReportedByCategory(String reportedByCategory) {
    this.reportedByCategory = reportedByCategory;
  }

  public TicketDTO reportedBySubcategory(String reportedBySubcategory) {
    this.reportedBySubcategory = reportedBySubcategory;
    return this;
  }

  /**
   * Get reportedBySubcategory
   * @return reportedBySubcategory
   **/
  @Schema(description = "")
  
    public String getReportedBySubcategory() {
    return reportedBySubcategory;
  }

  public void setReportedBySubcategory(String reportedBySubcategory) {
    this.reportedBySubcategory = reportedBySubcategory;
  }

  public TicketDTO reportedDatetime(OffsetDateTime reportedDatetime) {
    this.reportedDatetime = reportedDatetime;
    return this;
  }

  /**
   * Get reportedDatetime
   * @return reportedDatetime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getReportedDatetime() {
    return reportedDatetime;
  }

  public void setReportedDatetime(OffsetDateTime reportedDatetime) {
    this.reportedDatetime = reportedDatetime;
  }

  public TicketDTO routingDestination(String routingDestination) {
    this.routingDestination = routingDestination;
    return this;
  }

  /**
   * Get routingDestination
   * @return routingDestination
   **/
  @Schema(description = "")
  
    public String getRoutingDestination() {
    return routingDestination;
  }

  public void setRoutingDestination(String routingDestination) {
    this.routingDestination = routingDestination;
  }

  public TicketDTO sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public TicketDTO status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  @Schema(description = "")
  
    public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public TicketDTO statusReason(String statusReason) {
    this.statusReason = statusReason;
    return this;
  }

  /**
   * Get statusReason
   * @return statusReason
   **/
  @Schema(description = "")
  
    public String getStatusReason() {
    return statusReason;
  }

  public void setStatusReason(String statusReason) {
    this.statusReason = statusReason;
  }

  public TicketDTO ticketClosureDate(OffsetDateTime ticketClosureDate) {
    this.ticketClosureDate = ticketClosureDate;
    return this;
  }

  /**
   * Get ticketClosureDate
   * @return ticketClosureDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getTicketClosureDate() {
    return ticketClosureDate;
  }

  public void setTicketClosureDate(OffsetDateTime ticketClosureDate) {
    this.ticketClosureDate = ticketClosureDate;
  }

  public TicketDTO totalMinutes(Integer totalMinutes) {
    this.totalMinutes = totalMinutes;
    return this;
  }

  /**
   * Get totalMinutes
   * @return totalMinutes
   **/
  @Schema(description = "")
  
    public Integer getTotalMinutes() {
    return totalMinutes;
  }

  public void setTotalMinutes(Integer totalMinutes) {
    this.totalMinutes = totalMinutes;
  }

  public TicketDTO verificationAction(String verificationAction) {
    this.verificationAction = verificationAction;
    return this;
  }

  /**
   * Get verificationAction
   * @return verificationAction
   **/
  @Schema(description = "")
  
    public String getVerificationAction() {
    return verificationAction;
  }

  public void setVerificationAction(String verificationAction) {
    this.verificationAction = verificationAction;
  }

  public TicketDTO reopenTrafficDate(OffsetDateTime reopenTrafficDate) {
    this.reopenTrafficDate = reopenTrafficDate;
    return this;
  }

  /**
   * Get reopenTrafficDate
   * @return reopenTrafficDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getReopenTrafficDate() {
    return reopenTrafficDate;
  }

  public void setReopenTrafficDate(OffsetDateTime reopenTrafficDate) {
    this.reopenTrafficDate = reopenTrafficDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TicketDTO ticketDTO = (TicketDTO) o;
    return Objects.equals(this.id, ticketDTO.id) &&
        Objects.equals(this.blkWorkOrderNumber, ticketDTO.blkWorkOrderNumber) &&
        Objects.equals(this.blkWorkOrderNumber2, ticketDTO.blkWorkOrderNumber2) &&
        Objects.equals(this.blkWorkOrderNumber3, ticketDTO.blkWorkOrderNumber3) &&
        Objects.equals(this.carrierBlock, ticketDTO.carrierBlock) &&
        Objects.equals(this.createDate, ticketDTO.createDate) &&
        Objects.equals(this.creatorGroup, ticketDTO.creatorGroup) &&
        Objects.equals(this.creatorUser, ticketDTO.creatorUser) &&
        Objects.equals(this.dtblockByWorkOrder, ticketDTO.dtblockByWorkOrder) &&
        Objects.equals(this.endDateOccurs, ticketDTO.endDateOccurs) &&
        Objects.equals(this.holdMkvnResponse, ticketDTO.holdMkvnResponse) &&
        Objects.equals(this.lastModifiedDate, ticketDTO.lastModifiedDate) &&
        Objects.equals(this.marketingRequestDate, ticketDTO.marketingRequestDate) &&
        Objects.equals(this.marketingRequestType, ticketDTO.marketingRequestType) &&
        Objects.equals(this.nmBlockDate, ticketDTO.nmBlockDate) &&
        Objects.equals(this.nmBlockType, ticketDTO.nmBlockType) &&
        Objects.equals(this.nmNumberingRange, ticketDTO.nmNumberingRange) &&
        Objects.equals(this.notes, ticketDTO.notes) &&
        Objects.equals(this.ownerGroup, ticketDTO.ownerGroup) &&
        Objects.equals(this.sourceType, ticketDTO.sourceType) &&
        Objects.equals(this.phoneNumberBlock, ticketDTO.phoneNumberBlock) &&
        Objects.equals(this.reasonForClosure, ticketDTO.reasonForClosure) &&
        Objects.equals(this.reportedByCategory, ticketDTO.reportedByCategory) &&
        Objects.equals(this.reportedBySubcategory, ticketDTO.reportedBySubcategory) &&
        Objects.equals(this.reportedDatetime, ticketDTO.reportedDatetime) &&
        Objects.equals(this.routingDestination, ticketDTO.routingDestination) &&
        Objects.equals(this.sellingDestination, ticketDTO.sellingDestination) &&
        Objects.equals(this.status, ticketDTO.status) &&
        Objects.equals(this.statusReason, ticketDTO.statusReason) &&
        Objects.equals(this.ticketClosureDate, ticketDTO.ticketClosureDate) &&
        Objects.equals(this.totalMinutes, ticketDTO.totalMinutes) &&
        Objects.equals(this.verificationAction, ticketDTO.verificationAction) &&
        Objects.equals(this.reopenTrafficDate, ticketDTO.reopenTrafficDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, blkWorkOrderNumber, blkWorkOrderNumber2, blkWorkOrderNumber3, carrierBlock, createDate, creatorGroup, creatorUser, dtblockByWorkOrder, endDateOccurs, holdMkvnResponse, lastModifiedDate, marketingRequestDate, marketingRequestType, nmBlockDate, nmBlockType, nmNumberingRange, notes, ownerGroup, sourceType, phoneNumberBlock, reasonForClosure, reportedByCategory, reportedBySubcategory, reportedDatetime, routingDestination, sellingDestination, status, statusReason, ticketClosureDate, totalMinutes, verificationAction, reopenTrafficDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TicketDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    blkWorkOrderNumber: ").append(toIndentedString(blkWorkOrderNumber)).append("\n");
    sb.append("    blkWorkOrderNumber2: ").append(toIndentedString(blkWorkOrderNumber2)).append("\n");
    sb.append("    blkWorkOrderNumber3: ").append(toIndentedString(blkWorkOrderNumber3)).append("\n");
    sb.append("    carrierBlock: ").append(toIndentedString(carrierBlock)).append("\n");
    sb.append("    createDate: ").append(toIndentedString(createDate)).append("\n");
    sb.append("    creatorGroup: ").append(toIndentedString(creatorGroup)).append("\n");
    sb.append("    creatorUser: ").append(toIndentedString(creatorUser)).append("\n");
    sb.append("    dtblockByWorkOrder: ").append(toIndentedString(dtblockByWorkOrder)).append("\n");
    sb.append("    endDateOccurs: ").append(toIndentedString(endDateOccurs)).append("\n");
    sb.append("    holdMkvnResponse: ").append(toIndentedString(holdMkvnResponse)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("    marketingRequestDate: ").append(toIndentedString(marketingRequestDate)).append("\n");
    sb.append("    marketingRequestType: ").append(toIndentedString(marketingRequestType)).append("\n");
    sb.append("    nmBlockDate: ").append(toIndentedString(nmBlockDate)).append("\n");
    sb.append("    nmBlockType: ").append(toIndentedString(nmBlockType)).append("\n");
    sb.append("    nmNumberingRange: ").append(toIndentedString(nmNumberingRange)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    ownerGroup: ").append(toIndentedString(ownerGroup)).append("\n");
    sb.append("    sourceType: ").append(toIndentedString(sourceType)).append("\n");
    sb.append("    phoneNumberBlock: ").append(toIndentedString(phoneNumberBlock)).append("\n");
    sb.append("    reasonForClosure: ").append(toIndentedString(reasonForClosure)).append("\n");
    sb.append("    reportedByCategory: ").append(toIndentedString(reportedByCategory)).append("\n");
    sb.append("    reportedBySubcategory: ").append(toIndentedString(reportedBySubcategory)).append("\n");
    sb.append("    reportedDatetime: ").append(toIndentedString(reportedDatetime)).append("\n");
    sb.append("    routingDestination: ").append(toIndentedString(routingDestination)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    statusReason: ").append(toIndentedString(statusReason)).append("\n");
    sb.append("    ticketClosureDate: ").append(toIndentedString(ticketClosureDate)).append("\n");
    sb.append("    totalMinutes: ").append(toIndentedString(totalMinutes)).append("\n");
    sb.append("    verificationAction: ").append(toIndentedString(verificationAction)).append("\n");
    sb.append("    reopenTrafficDate: ").append(toIndentedString(reopenTrafficDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
