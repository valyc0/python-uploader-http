package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.EventiAzioniDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * EventiAzioniResponseDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class EventiAzioniResponseDTO   {
  @JsonProperty("page")
  private Integer page = null;

  @JsonProperty("size")
  private Integer size = null;

  @JsonProperty("totalrecord")
  private Long totalrecord = null;

  @JsonProperty("eventiAzioni")
  @Valid
  private List<EventiAzioniDTO> eventiAzioni = null;

  public EventiAzioniResponseDTO page(Integer page) {
    this.page = page;
    return this;
  }

  /**
   * Get page
   * @return page
   **/
  @Schema(description = "")
  
    public Integer getPage() {
    return page;
  }

  public void setPage(Integer page) {
    this.page = page;
  }

  public EventiAzioniResponseDTO size(Integer size) {
    this.size = size;
    return this;
  }

  /**
   * Get size
   * @return size
   **/
  @Schema(description = "")
  
    public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public EventiAzioniResponseDTO totalrecord(Long totalrecord) {
    this.totalrecord = totalrecord;
    return this;
  }

  /**
   * Get totalrecord
   * @return totalrecord
   **/
  @Schema(description = "")
  
    public Long getTotalrecord() {
    return totalrecord;
  }

  public void setTotalrecord(Long totalrecord) {
    this.totalrecord = totalrecord;
  }

  public EventiAzioniResponseDTO eventiAzioni(List<EventiAzioniDTO> eventiAzioni) {
    this.eventiAzioni = eventiAzioni;
    return this;
  }

  public EventiAzioniResponseDTO addEventiAzioniItem(EventiAzioniDTO eventiAzioniItem) {
    if (this.eventiAzioni == null) {
      this.eventiAzioni = new ArrayList<EventiAzioniDTO>();
    }
    this.eventiAzioni.add(eventiAzioniItem);
    return this;
  }

  /**
   * Get eventiAzioni
   * @return eventiAzioni
   **/
  @Schema(description = "")
      @Valid
    public List<EventiAzioniDTO> getEventiAzioni() {
    return eventiAzioni;
  }

  public void setEventiAzioni(List<EventiAzioniDTO> eventiAzioni) {
    this.eventiAzioni = eventiAzioni;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EventiAzioniResponseDTO eventiAzioniResponseDTO = (EventiAzioniResponseDTO) o;
    return Objects.equals(this.page, eventiAzioniResponseDTO.page) &&
        Objects.equals(this.size, eventiAzioniResponseDTO.size) &&
        Objects.equals(this.totalrecord, eventiAzioniResponseDTO.totalrecord) &&
        Objects.equals(this.eventiAzioni, eventiAzioniResponseDTO.eventiAzioni);
  }

  @Override
  public int hashCode() {
    return Objects.hash(page, size, totalrecord, eventiAzioni);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EventiAzioniResponseDTO {\n");
    
    sb.append("    page: ").append(toIndentedString(page)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    totalrecord: ").append(toIndentedString(totalrecord)).append("\n");
    sb.append("    eventiAzioni: ").append(toIndentedString(eventiAzioni)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
