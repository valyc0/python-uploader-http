package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PhoneNumberBlockDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class PhoneNumberBlockDTO   {
  @JsonProperty("countryCode")
  private String countryCode = null;

  @JsonProperty("calledNumber")
  private String calledNumber = null;

  public PhoneNumberBlockDTO countryCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Get countryCode
   * @return countryCode
   **/
  @Schema(description = "")
  
    public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public PhoneNumberBlockDTO calledNumber(String calledNumber) {
    this.calledNumber = calledNumber;
    return this;
  }

  /**
   * Get calledNumber
   * @return calledNumber
   **/
  @Schema(description = "")
  
    public String getCalledNumber() {
    return calledNumber;
  }

  public void setCalledNumber(String calledNumber) {
    this.calledNumber = calledNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PhoneNumberBlockDTO phoneNumberBlockDTO = (PhoneNumberBlockDTO) o;
    return Objects.equals(this.countryCode, phoneNumberBlockDTO.countryCode) &&
        Objects.equals(this.calledNumber, phoneNumberBlockDTO.calledNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(countryCode, calledNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PhoneNumberBlockDTO {\n");
    
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("    calledNumber: ").append(toIndentedString(calledNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
