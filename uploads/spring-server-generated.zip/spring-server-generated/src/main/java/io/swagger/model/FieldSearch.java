package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * oggetto per l&#x27;ordinamento dei campi
 */
@Schema(description = "oggetto per l'ordinamento dei campi")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class FieldSearch   {
  @JsonProperty("field")
  private String field = null;

  @JsonProperty("sortOrder")
  private String sortOrder = null;

  public FieldSearch field(String field) {
    this.field = field;
    return this;
  }

  /**
   * campo su cui fare sorting
   * @return field
   **/
  @Schema(description = "campo su cui fare sorting")
  
    public String getField() {
    return field;
  }

  public void setField(String field) {
    this.field = field;
  }

  public FieldSearch sortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

  /**
   * order:DESC,ASC
   * @return sortOrder
   **/
  @Schema(description = "order:DESC,ASC")
  
    public String getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FieldSearch fieldSearch = (FieldSearch) o;
    return Objects.equals(this.field, fieldSearch.field) &&
        Objects.equals(this.sortOrder, fieldSearch.sortOrder);
  }

  @Override
  public int hashCode() {
    return Objects.hash(field, sortOrder);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FieldSearch {\n");
    
    sb.append("    field: ").append(toIndentedString(field)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
