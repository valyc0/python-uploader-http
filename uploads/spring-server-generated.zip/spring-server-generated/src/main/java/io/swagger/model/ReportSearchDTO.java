package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.FieldSearch;
import io.swagger.model.SearchPageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ReportSearchDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class ReportSearchDTO   {
  @JsonProperty("rif")
  private String rif = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("istrout")
  private String istrout = null;

  @JsonProperty("sourceType")
  private String sourceType = null;

  @JsonProperty("mese")
  private String mese = null;

  @JsonProperty("anno")
  private String anno = null;

  @JsonProperty("quarter")
  private String quarter = null;

  @JsonProperty("risultanzaAnalisi")
  private String risultanzaAnalisi = null;

  @JsonProperty("fieldSearchs")
  @Valid
  private List<FieldSearch> fieldSearchs = null;

  @JsonProperty("pageable")
  private SearchPageDTO pageable = null;

  public ReportSearchDTO rif(String rif) {
    this.rif = rif;
    return this;
  }

  /**
   * Get rif
   * @return rif
   **/
  @Schema(description = "")
  
    public String getRif() {
    return rif;
  }

  public void setRif(String rif) {
    this.rif = rif;
  }

  public ReportSearchDTO sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public ReportSearchDTO istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public ReportSearchDTO istrout(String istrout) {
    this.istrout = istrout;
    return this;
  }

  /**
   * Get istrout
   * @return istrout
   **/
  @Schema(description = "")
  
    public String getIstrout() {
    return istrout;
  }

  public void setIstrout(String istrout) {
    this.istrout = istrout;
  }

  public ReportSearchDTO sourceType(String sourceType) {
    this.sourceType = sourceType;
    return this;
  }

  /**
   * Get sourceType
   * @return sourceType
   **/
  @Schema(description = "")
  
    public String getSourceType() {
    return sourceType;
  }

  public void setSourceType(String sourceType) {
    this.sourceType = sourceType;
  }

  public ReportSearchDTO mese(String mese) {
    this.mese = mese;
    return this;
  }

  /**
   * Get mese
   * @return mese
   **/
  @Schema(description = "")
  
    public String getMese() {
    return mese;
  }

  public void setMese(String mese) {
    this.mese = mese;
  }

  public ReportSearchDTO anno(String anno) {
    this.anno = anno;
    return this;
  }

  /**
   * Get anno
   * @return anno
   **/
  @Schema(description = "")
  
    public String getAnno() {
    return anno;
  }

  public void setAnno(String anno) {
    this.anno = anno;
  }

  public ReportSearchDTO quarter(String quarter) {
    this.quarter = quarter;
    return this;
  }

  /**
   * Get quarter
   * @return quarter
   **/
  @Schema(description = "")
  
    public String getQuarter() {
    return quarter;
  }

  public void setQuarter(String quarter) {
    this.quarter = quarter;
  }

  public ReportSearchDTO risultanzaAnalisi(String risultanzaAnalisi) {
    this.risultanzaAnalisi = risultanzaAnalisi;
    return this;
  }

  /**
   * Get risultanzaAnalisi
   * @return risultanzaAnalisi
   **/
  @Schema(description = "")
  
    public String getRisultanzaAnalisi() {
    return risultanzaAnalisi;
  }

  public void setRisultanzaAnalisi(String risultanzaAnalisi) {
    this.risultanzaAnalisi = risultanzaAnalisi;
  }

  public ReportSearchDTO fieldSearchs(List<FieldSearch> fieldSearchs) {
    this.fieldSearchs = fieldSearchs;
    return this;
  }

  public ReportSearchDTO addFieldSearchsItem(FieldSearch fieldSearchsItem) {
    if (this.fieldSearchs == null) {
      this.fieldSearchs = new ArrayList<FieldSearch>();
    }
    this.fieldSearchs.add(fieldSearchsItem);
    return this;
  }

  /**
   * Get fieldSearchs
   * @return fieldSearchs
   **/
  @Schema(description = "")
      @Valid
    public List<FieldSearch> getFieldSearchs() {
    return fieldSearchs;
  }

  public void setFieldSearchs(List<FieldSearch> fieldSearchs) {
    this.fieldSearchs = fieldSearchs;
  }

  public ReportSearchDTO pageable(SearchPageDTO pageable) {
    this.pageable = pageable;
    return this;
  }

  /**
   * Get pageable
   * @return pageable
   **/
  @Schema(description = "")
  
    @Valid
    public SearchPageDTO getPageable() {
    return pageable;
  }

  public void setPageable(SearchPageDTO pageable) {
    this.pageable = pageable;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReportSearchDTO reportSearchDTO = (ReportSearchDTO) o;
    return Objects.equals(this.rif, reportSearchDTO.rif) &&
        Objects.equals(this.sellingDestination, reportSearchDTO.sellingDestination) &&
        Objects.equals(this.istrin, reportSearchDTO.istrin) &&
        Objects.equals(this.istrout, reportSearchDTO.istrout) &&
        Objects.equals(this.sourceType, reportSearchDTO.sourceType) &&
        Objects.equals(this.mese, reportSearchDTO.mese) &&
        Objects.equals(this.anno, reportSearchDTO.anno) &&
        Objects.equals(this.quarter, reportSearchDTO.quarter) &&
        Objects.equals(this.risultanzaAnalisi, reportSearchDTO.risultanzaAnalisi) &&
        Objects.equals(this.fieldSearchs, reportSearchDTO.fieldSearchs) &&
        Objects.equals(this.pageable, reportSearchDTO.pageable);
  }

  @Override
  public int hashCode() {
    return Objects.hash(rif, sellingDestination, istrin, istrout, sourceType, mese, anno, quarter, risultanzaAnalisi, fieldSearchs, pageable);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReportSearchDTO {\n");
    
    sb.append("    rif: ").append(toIndentedString(rif)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    istrout: ").append(toIndentedString(istrout)).append("\n");
    sb.append("    sourceType: ").append(toIndentedString(sourceType)).append("\n");
    sb.append("    mese: ").append(toIndentedString(mese)).append("\n");
    sb.append("    anno: ").append(toIndentedString(anno)).append("\n");
    sb.append("    quarter: ").append(toIndentedString(quarter)).append("\n");
    sb.append("    risultanzaAnalisi: ").append(toIndentedString(risultanzaAnalisi)).append("\n");
    sb.append("    fieldSearchs: ").append(toIndentedString(fieldSearchs)).append("\n");
    sb.append("    pageable: ").append(toIndentedString(pageable)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
