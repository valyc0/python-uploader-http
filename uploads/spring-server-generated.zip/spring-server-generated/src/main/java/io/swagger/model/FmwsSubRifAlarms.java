package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * FmwsSubRifAlarms
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class FmwsSubRifAlarms   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("subrifId")
  private String subrifId = null;

  @JsonProperty("rifId")
  private String rifId = null;

  @JsonProperty("cdf")
  private String cdf = null;

  @JsonProperty("alarmId")
  private String alarmId = null;

  @JsonProperty("alarmReferenceType")
  private String alarmReferenceType = null;

  @JsonProperty("alarmReferenceValue")
  private String alarmReferenceValue = null;

  @JsonProperty("alarmFraudCategory")
  private String alarmFraudCategory = null;

  @JsonProperty("ticketId")
  private String ticketId = null;

  @JsonProperty("attempts")
  private Long attempts = null;

  @JsonProperty("answered")
  private Long answered = null;

  @JsonProperty("totalMinutes")
  private Long totalMinutes = null;

  @JsonProperty("totalCost")
  private Long totalCost = null;

  @JsonProperty("creationDate")
  private OffsetDateTime creationDate = null;

  @JsonProperty("lastModifiedDate")
  private OffsetDateTime lastModifiedDate = null;

  public FmwsSubRifAlarms id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public FmwsSubRifAlarms subrifId(String subrifId) {
    this.subrifId = subrifId;
    return this;
  }

  /**
   * Get subrifId
   * @return subrifId
   **/
  @Schema(description = "")
  
    public String getSubrifId() {
    return subrifId;
  }

  public void setSubrifId(String subrifId) {
    this.subrifId = subrifId;
  }

  public FmwsSubRifAlarms rifId(String rifId) {
    this.rifId = rifId;
    return this;
  }

  /**
   * Get rifId
   * @return rifId
   **/
  @Schema(description = "")
  
    public String getRifId() {
    return rifId;
  }

  public void setRifId(String rifId) {
    this.rifId = rifId;
  }

  public FmwsSubRifAlarms cdf(String cdf) {
    this.cdf = cdf;
    return this;
  }

  /**
   * Get cdf
   * @return cdf
   **/
  @Schema(description = "")
  
    public String getCdf() {
    return cdf;
  }

  public void setCdf(String cdf) {
    this.cdf = cdf;
  }

  public FmwsSubRifAlarms alarmId(String alarmId) {
    this.alarmId = alarmId;
    return this;
  }

  /**
   * Get alarmId
   * @return alarmId
   **/
  @Schema(description = "")
  
    public String getAlarmId() {
    return alarmId;
  }

  public void setAlarmId(String alarmId) {
    this.alarmId = alarmId;
  }

  public FmwsSubRifAlarms alarmReferenceType(String alarmReferenceType) {
    this.alarmReferenceType = alarmReferenceType;
    return this;
  }

  /**
   * Get alarmReferenceType
   * @return alarmReferenceType
   **/
  @Schema(description = "")
  
    public String getAlarmReferenceType() {
    return alarmReferenceType;
  }

  public void setAlarmReferenceType(String alarmReferenceType) {
    this.alarmReferenceType = alarmReferenceType;
  }

  public FmwsSubRifAlarms alarmReferenceValue(String alarmReferenceValue) {
    this.alarmReferenceValue = alarmReferenceValue;
    return this;
  }

  /**
   * Get alarmReferenceValue
   * @return alarmReferenceValue
   **/
  @Schema(description = "")
  
    public String getAlarmReferenceValue() {
    return alarmReferenceValue;
  }

  public void setAlarmReferenceValue(String alarmReferenceValue) {
    this.alarmReferenceValue = alarmReferenceValue;
  }

  public FmwsSubRifAlarms alarmFraudCategory(String alarmFraudCategory) {
    this.alarmFraudCategory = alarmFraudCategory;
    return this;
  }

  /**
   * Get alarmFraudCategory
   * @return alarmFraudCategory
   **/
  @Schema(description = "")
  
    public String getAlarmFraudCategory() {
    return alarmFraudCategory;
  }

  public void setAlarmFraudCategory(String alarmFraudCategory) {
    this.alarmFraudCategory = alarmFraudCategory;
  }

  public FmwsSubRifAlarms ticketId(String ticketId) {
    this.ticketId = ticketId;
    return this;
  }

  /**
   * Get ticketId
   * @return ticketId
   **/
  @Schema(description = "")
  
    public String getTicketId() {
    return ticketId;
  }

  public void setTicketId(String ticketId) {
    this.ticketId = ticketId;
  }

  public FmwsSubRifAlarms attempts(Long attempts) {
    this.attempts = attempts;
    return this;
  }

  /**
   * Get attempts
   * @return attempts
   **/
  @Schema(description = "")
  
    public Long getAttempts() {
    return attempts;
  }

  public void setAttempts(Long attempts) {
    this.attempts = attempts;
  }

  public FmwsSubRifAlarms answered(Long answered) {
    this.answered = answered;
    return this;
  }

  /**
   * Get answered
   * @return answered
   **/
  @Schema(description = "")
  
    public Long getAnswered() {
    return answered;
  }

  public void setAnswered(Long answered) {
    this.answered = answered;
  }

  public FmwsSubRifAlarms totalMinutes(Long totalMinutes) {
    this.totalMinutes = totalMinutes;
    return this;
  }

  /**
   * Get totalMinutes
   * @return totalMinutes
   **/
  @Schema(description = "")
  
    public Long getTotalMinutes() {
    return totalMinutes;
  }

  public void setTotalMinutes(Long totalMinutes) {
    this.totalMinutes = totalMinutes;
  }

  public FmwsSubRifAlarms totalCost(Long totalCost) {
    this.totalCost = totalCost;
    return this;
  }

  /**
   * Get totalCost
   * @return totalCost
   **/
  @Schema(description = "")
  
    public Long getTotalCost() {
    return totalCost;
  }

  public void setTotalCost(Long totalCost) {
    this.totalCost = totalCost;
  }

  public FmwsSubRifAlarms creationDate(OffsetDateTime creationDate) {
    this.creationDate = creationDate;
    return this;
  }

  /**
   * Get creationDate
   * @return creationDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(OffsetDateTime creationDate) {
    this.creationDate = creationDate;
  }

  public FmwsSubRifAlarms lastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FmwsSubRifAlarms fmwsSubRifAlarms = (FmwsSubRifAlarms) o;
    return Objects.equals(this.id, fmwsSubRifAlarms.id) &&
        Objects.equals(this.subrifId, fmwsSubRifAlarms.subrifId) &&
        Objects.equals(this.rifId, fmwsSubRifAlarms.rifId) &&
        Objects.equals(this.cdf, fmwsSubRifAlarms.cdf) &&
        Objects.equals(this.alarmId, fmwsSubRifAlarms.alarmId) &&
        Objects.equals(this.alarmReferenceType, fmwsSubRifAlarms.alarmReferenceType) &&
        Objects.equals(this.alarmReferenceValue, fmwsSubRifAlarms.alarmReferenceValue) &&
        Objects.equals(this.alarmFraudCategory, fmwsSubRifAlarms.alarmFraudCategory) &&
        Objects.equals(this.ticketId, fmwsSubRifAlarms.ticketId) &&
        Objects.equals(this.attempts, fmwsSubRifAlarms.attempts) &&
        Objects.equals(this.answered, fmwsSubRifAlarms.answered) &&
        Objects.equals(this.totalMinutes, fmwsSubRifAlarms.totalMinutes) &&
        Objects.equals(this.totalCost, fmwsSubRifAlarms.totalCost) &&
        Objects.equals(this.creationDate, fmwsSubRifAlarms.creationDate) &&
        Objects.equals(this.lastModifiedDate, fmwsSubRifAlarms.lastModifiedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, subrifId, rifId, cdf, alarmId, alarmReferenceType, alarmReferenceValue, alarmFraudCategory, ticketId, attempts, answered, totalMinutes, totalCost, creationDate, lastModifiedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FmwsSubRifAlarms {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    subrifId: ").append(toIndentedString(subrifId)).append("\n");
    sb.append("    rifId: ").append(toIndentedString(rifId)).append("\n");
    sb.append("    cdf: ").append(toIndentedString(cdf)).append("\n");
    sb.append("    alarmId: ").append(toIndentedString(alarmId)).append("\n");
    sb.append("    alarmReferenceType: ").append(toIndentedString(alarmReferenceType)).append("\n");
    sb.append("    alarmReferenceValue: ").append(toIndentedString(alarmReferenceValue)).append("\n");
    sb.append("    alarmFraudCategory: ").append(toIndentedString(alarmFraudCategory)).append("\n");
    sb.append("    ticketId: ").append(toIndentedString(ticketId)).append("\n");
    sb.append("    attempts: ").append(toIndentedString(attempts)).append("\n");
    sb.append("    answered: ").append(toIndentedString(answered)).append("\n");
    sb.append("    totalMinutes: ").append(toIndentedString(totalMinutes)).append("\n");
    sb.append("    totalCost: ").append(toIndentedString(totalCost)).append("\n");
    sb.append("    creationDate: ").append(toIndentedString(creationDate)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
