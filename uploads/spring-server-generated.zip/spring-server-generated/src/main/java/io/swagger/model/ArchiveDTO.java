package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.MailDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ArchiveDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class ArchiveDTO   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("contentType")
  private String contentType = null;

  @JsonProperty("troubleTicket")
  private String troubleTicket = null;

  @JsonProperty("rif")
  private String rif = null;

  @JsonProperty("filename")
  private String filename = null;

  @JsonProperty("mailDTO")
  private MailDTO mailDTO = null;

  @JsonProperty("utente")
  private String utente = null;

  @JsonProperty("nota")
  private String nota = null;

  @JsonProperty("tipo")
  private String tipo = null;

  @JsonProperty("size")
  private String size = null;

  @JsonProperty("lastModifiedDate")
  private OffsetDateTime lastModifiedDate = null;

  public ArchiveDTO id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ArchiveDTO contentType(String contentType) {
    this.contentType = contentType;
    return this;
  }

  /**
   * Get contentType
   * @return contentType
   **/
  @Schema(description = "")
  
    public String getContentType() {
    return contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public ArchiveDTO troubleTicket(String troubleTicket) {
    this.troubleTicket = troubleTicket;
    return this;
  }

  /**
   * Get troubleTicket
   * @return troubleTicket
   **/
  @Schema(description = "")
  
    public String getTroubleTicket() {
    return troubleTicket;
  }

  public void setTroubleTicket(String troubleTicket) {
    this.troubleTicket = troubleTicket;
  }

  public ArchiveDTO rif(String rif) {
    this.rif = rif;
    return this;
  }

  /**
   * Get rif
   * @return rif
   **/
  @Schema(description = "")
  
    public String getRif() {
    return rif;
  }

  public void setRif(String rif) {
    this.rif = rif;
  }

  public ArchiveDTO filename(String filename) {
    this.filename = filename;
    return this;
  }

  /**
   * Get filename
   * @return filename
   **/
  @Schema(description = "")
  
    public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public ArchiveDTO mailDTO(MailDTO mailDTO) {
    this.mailDTO = mailDTO;
    return this;
  }

  /**
   * Get mailDTO
   * @return mailDTO
   **/
  @Schema(description = "")
  
    @Valid
    public MailDTO getMailDTO() {
    return mailDTO;
  }

  public void setMailDTO(MailDTO mailDTO) {
    this.mailDTO = mailDTO;
  }

  public ArchiveDTO utente(String utente) {
    this.utente = utente;
    return this;
  }

  /**
   * Get utente
   * @return utente
   **/
  @Schema(description = "")
  
    public String getUtente() {
    return utente;
  }

  public void setUtente(String utente) {
    this.utente = utente;
  }

  public ArchiveDTO nota(String nota) {
    this.nota = nota;
    return this;
  }

  /**
   * Get nota
   * @return nota
   **/
  @Schema(description = "")
  
    public String getNota() {
    return nota;
  }

  public void setNota(String nota) {
    this.nota = nota;
  }

  public ArchiveDTO tipo(String tipo) {
    this.tipo = tipo;
    return this;
  }

  /**
   * Get tipo
   * @return tipo
   **/
  @Schema(description = "")
  
    public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public ArchiveDTO size(String size) {
    this.size = size;
    return this;
  }

  /**
   * Get size
   * @return size
   **/
  @Schema(description = "")
  
    public String getSize() {
    return size;
  }

  public void setSize(String size) {
    this.size = size;
  }

  public ArchiveDTO lastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ArchiveDTO archiveDTO = (ArchiveDTO) o;
    return Objects.equals(this.id, archiveDTO.id) &&
        Objects.equals(this.contentType, archiveDTO.contentType) &&
        Objects.equals(this.troubleTicket, archiveDTO.troubleTicket) &&
        Objects.equals(this.rif, archiveDTO.rif) &&
        Objects.equals(this.filename, archiveDTO.filename) &&
        Objects.equals(this.mailDTO, archiveDTO.mailDTO) &&
        Objects.equals(this.utente, archiveDTO.utente) &&
        Objects.equals(this.nota, archiveDTO.nota) &&
        Objects.equals(this.tipo, archiveDTO.tipo) &&
        Objects.equals(this.size, archiveDTO.size) &&
        Objects.equals(this.lastModifiedDate, archiveDTO.lastModifiedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, contentType, troubleTicket, rif, filename, mailDTO, utente, nota, tipo, size, lastModifiedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ArchiveDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    contentType: ").append(toIndentedString(contentType)).append("\n");
    sb.append("    troubleTicket: ").append(toIndentedString(troubleTicket)).append("\n");
    sb.append("    rif: ").append(toIndentedString(rif)).append("\n");
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    mailDTO: ").append(toIndentedString(mailDTO)).append("\n");
    sb.append("    utente: ").append(toIndentedString(utente)).append("\n");
    sb.append("    nota: ").append(toIndentedString(nota)).append("\n");
    sb.append("    tipo: ").append(toIndentedString(tipo)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
