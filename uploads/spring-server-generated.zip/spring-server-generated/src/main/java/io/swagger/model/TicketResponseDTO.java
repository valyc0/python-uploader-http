package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.CarrierInfoDTO;
import io.swagger.model.ReferenceDTO;
import io.swagger.model.TicketAzioniDTO;
import io.swagger.model.TicketDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TicketResponseDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class TicketResponseDTO   {
  @JsonProperty("ticket")
  private TicketDTO ticket = null;

  @JsonProperty("azioni")
  @Valid
  private List<TicketAzioniDTO> azioni = null;

  @JsonProperty("referenceDTOs")
  @Valid
  private List<ReferenceDTO> referenceDTOs = null;

  @JsonProperty("carrierInfoInDTOs")
  @Valid
  private List<CarrierInfoDTO> carrierInfoInDTOs = null;

  @JsonProperty("carrierInfoOutDTOs")
  @Valid
  private List<CarrierInfoDTO> carrierInfoOutDTOs = null;

  public TicketResponseDTO ticket(TicketDTO ticket) {
    this.ticket = ticket;
    return this;
  }

  /**
   * Get ticket
   * @return ticket
   **/
  @Schema(description = "")
  
    @Valid
    public TicketDTO getTicket() {
    return ticket;
  }

  public void setTicket(TicketDTO ticket) {
    this.ticket = ticket;
  }

  public TicketResponseDTO azioni(List<TicketAzioniDTO> azioni) {
    this.azioni = azioni;
    return this;
  }

  public TicketResponseDTO addAzioniItem(TicketAzioniDTO azioniItem) {
    if (this.azioni == null) {
      this.azioni = new ArrayList<TicketAzioniDTO>();
    }
    this.azioni.add(azioniItem);
    return this;
  }

  /**
   * Get azioni
   * @return azioni
   **/
  @Schema(description = "")
      @Valid
    public List<TicketAzioniDTO> getAzioni() {
    return azioni;
  }

  public void setAzioni(List<TicketAzioniDTO> azioni) {
    this.azioni = azioni;
  }

  public TicketResponseDTO referenceDTOs(List<ReferenceDTO> referenceDTOs) {
    this.referenceDTOs = referenceDTOs;
    return this;
  }

  public TicketResponseDTO addReferenceDTOsItem(ReferenceDTO referenceDTOsItem) {
    if (this.referenceDTOs == null) {
      this.referenceDTOs = new ArrayList<ReferenceDTO>();
    }
    this.referenceDTOs.add(referenceDTOsItem);
    return this;
  }

  /**
   * Get referenceDTOs
   * @return referenceDTOs
   **/
  @Schema(description = "")
      @Valid
    public List<ReferenceDTO> getReferenceDTOs() {
    return referenceDTOs;
  }

  public void setReferenceDTOs(List<ReferenceDTO> referenceDTOs) {
    this.referenceDTOs = referenceDTOs;
  }

  public TicketResponseDTO carrierInfoInDTOs(List<CarrierInfoDTO> carrierInfoInDTOs) {
    this.carrierInfoInDTOs = carrierInfoInDTOs;
    return this;
  }

  public TicketResponseDTO addCarrierInfoInDTOsItem(CarrierInfoDTO carrierInfoInDTOsItem) {
    if (this.carrierInfoInDTOs == null) {
      this.carrierInfoInDTOs = new ArrayList<CarrierInfoDTO>();
    }
    this.carrierInfoInDTOs.add(carrierInfoInDTOsItem);
    return this;
  }

  /**
   * Get carrierInfoInDTOs
   * @return carrierInfoInDTOs
   **/
  @Schema(description = "")
      @Valid
    public List<CarrierInfoDTO> getCarrierInfoInDTOs() {
    return carrierInfoInDTOs;
  }

  public void setCarrierInfoInDTOs(List<CarrierInfoDTO> carrierInfoInDTOs) {
    this.carrierInfoInDTOs = carrierInfoInDTOs;
  }

  public TicketResponseDTO carrierInfoOutDTOs(List<CarrierInfoDTO> carrierInfoOutDTOs) {
    this.carrierInfoOutDTOs = carrierInfoOutDTOs;
    return this;
  }

  public TicketResponseDTO addCarrierInfoOutDTOsItem(CarrierInfoDTO carrierInfoOutDTOsItem) {
    if (this.carrierInfoOutDTOs == null) {
      this.carrierInfoOutDTOs = new ArrayList<CarrierInfoDTO>();
    }
    this.carrierInfoOutDTOs.add(carrierInfoOutDTOsItem);
    return this;
  }

  /**
   * Get carrierInfoOutDTOs
   * @return carrierInfoOutDTOs
   **/
  @Schema(description = "")
      @Valid
    public List<CarrierInfoDTO> getCarrierInfoOutDTOs() {
    return carrierInfoOutDTOs;
  }

  public void setCarrierInfoOutDTOs(List<CarrierInfoDTO> carrierInfoOutDTOs) {
    this.carrierInfoOutDTOs = carrierInfoOutDTOs;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TicketResponseDTO ticketResponseDTO = (TicketResponseDTO) o;
    return Objects.equals(this.ticket, ticketResponseDTO.ticket) &&
        Objects.equals(this.azioni, ticketResponseDTO.azioni) &&
        Objects.equals(this.referenceDTOs, ticketResponseDTO.referenceDTOs) &&
        Objects.equals(this.carrierInfoInDTOs, ticketResponseDTO.carrierInfoInDTOs) &&
        Objects.equals(this.carrierInfoOutDTOs, ticketResponseDTO.carrierInfoOutDTOs);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ticket, azioni, referenceDTOs, carrierInfoInDTOs, carrierInfoOutDTOs);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TicketResponseDTO {\n");
    
    sb.append("    ticket: ").append(toIndentedString(ticket)).append("\n");
    sb.append("    azioni: ").append(toIndentedString(azioni)).append("\n");
    sb.append("    referenceDTOs: ").append(toIndentedString(referenceDTOs)).append("\n");
    sb.append("    carrierInfoInDTOs: ").append(toIndentedString(carrierInfoInDTOs)).append("\n");
    sb.append("    carrierInfoOutDTOs: ").append(toIndentedString(carrierInfoOutDTOs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
