package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * DisputeSubrifDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class DisputeSubrifDTO   {
  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("istrout")
  private String istrout = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("rif")
  private String rif = null;

  @JsonProperty("subrif")
  private String subrif = null;

  @JsonProperty("year")
  private String year = null;

  @JsonProperty("month")
  private String month = null;

  @JsonProperty("minute")
  private BigDecimal minute = null;

  @JsonProperty("cost")
  private BigDecimal cost = null;

  @JsonProperty("trafficStartDate")
  private OffsetDateTime trafficStartDate = null;

  @JsonProperty("trafficEndDate")
  private OffsetDateTime trafficEndDate = null;

  public DisputeSubrifDTO istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public DisputeSubrifDTO istrout(String istrout) {
    this.istrout = istrout;
    return this;
  }

  /**
   * Get istrout
   * @return istrout
   **/
  @Schema(description = "")
  
    public String getIstrout() {
    return istrout;
  }

  public void setIstrout(String istrout) {
    this.istrout = istrout;
  }

  public DisputeSubrifDTO sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public DisputeSubrifDTO rif(String rif) {
    this.rif = rif;
    return this;
  }

  /**
   * Get rif
   * @return rif
   **/
  @Schema(description = "")
  
    public String getRif() {
    return rif;
  }

  public void setRif(String rif) {
    this.rif = rif;
  }

  public DisputeSubrifDTO subrif(String subrif) {
    this.subrif = subrif;
    return this;
  }

  /**
   * Get subrif
   * @return subrif
   **/
  @Schema(description = "")
  
    public String getSubrif() {
    return subrif;
  }

  public void setSubrif(String subrif) {
    this.subrif = subrif;
  }

  public DisputeSubrifDTO year(String year) {
    this.year = year;
    return this;
  }

  /**
   * Get year
   * @return year
   **/
  @Schema(description = "")
  
    public String getYear() {
    return year;
  }

  public void setYear(String year) {
    this.year = year;
  }

  public DisputeSubrifDTO month(String month) {
    this.month = month;
    return this;
  }

  /**
   * Get month
   * @return month
   **/
  @Schema(description = "")
  
    public String getMonth() {
    return month;
  }

  public void setMonth(String month) {
    this.month = month;
  }

  public DisputeSubrifDTO minute(BigDecimal minute) {
    this.minute = minute;
    return this;
  }

  /**
   * Get minute
   * @return minute
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getMinute() {
    return minute;
  }

  public void setMinute(BigDecimal minute) {
    this.minute = minute;
  }

  public DisputeSubrifDTO cost(BigDecimal cost) {
    this.cost = cost;
    return this;
  }

  /**
   * Get cost
   * @return cost
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getCost() {
    return cost;
  }

  public void setCost(BigDecimal cost) {
    this.cost = cost;
  }

  public DisputeSubrifDTO trafficStartDate(OffsetDateTime trafficStartDate) {
    this.trafficStartDate = trafficStartDate;
    return this;
  }

  /**
   * Get trafficStartDate
   * @return trafficStartDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getTrafficStartDate() {
    return trafficStartDate;
  }

  public void setTrafficStartDate(OffsetDateTime trafficStartDate) {
    this.trafficStartDate = trafficStartDate;
  }

  public DisputeSubrifDTO trafficEndDate(OffsetDateTime trafficEndDate) {
    this.trafficEndDate = trafficEndDate;
    return this;
  }

  /**
   * Get trafficEndDate
   * @return trafficEndDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getTrafficEndDate() {
    return trafficEndDate;
  }

  public void setTrafficEndDate(OffsetDateTime trafficEndDate) {
    this.trafficEndDate = trafficEndDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DisputeSubrifDTO disputeSubrifDTO = (DisputeSubrifDTO) o;
    return Objects.equals(this.istrin, disputeSubrifDTO.istrin) &&
        Objects.equals(this.istrout, disputeSubrifDTO.istrout) &&
        Objects.equals(this.sellingDestination, disputeSubrifDTO.sellingDestination) &&
        Objects.equals(this.rif, disputeSubrifDTO.rif) &&
        Objects.equals(this.subrif, disputeSubrifDTO.subrif) &&
        Objects.equals(this.year, disputeSubrifDTO.year) &&
        Objects.equals(this.month, disputeSubrifDTO.month) &&
        Objects.equals(this.minute, disputeSubrifDTO.minute) &&
        Objects.equals(this.cost, disputeSubrifDTO.cost) &&
        Objects.equals(this.trafficStartDate, disputeSubrifDTO.trafficStartDate) &&
        Objects.equals(this.trafficEndDate, disputeSubrifDTO.trafficEndDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(istrin, istrout, sellingDestination, rif, subrif, year, month, minute, cost, trafficStartDate, trafficEndDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DisputeSubrifDTO {\n");
    
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    istrout: ").append(toIndentedString(istrout)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    rif: ").append(toIndentedString(rif)).append("\n");
    sb.append("    subrif: ").append(toIndentedString(subrif)).append("\n");
    sb.append("    year: ").append(toIndentedString(year)).append("\n");
    sb.append("    month: ").append(toIndentedString(month)).append("\n");
    sb.append("    minute: ").append(toIndentedString(minute)).append("\n");
    sb.append("    cost: ").append(toIndentedString(cost)).append("\n");
    sb.append("    trafficStartDate: ").append(toIndentedString(trafficStartDate)).append("\n");
    sb.append("    trafficEndDate: ").append(toIndentedString(trafficEndDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
