package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * HistoryDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class HistoryDTO   {
  @JsonProperty("startOperation")
  private OffsetDateTime startOperation = null;

  @JsonProperty("assigneeGroup")
  private String assigneeGroup = null;

  @JsonProperty("notes")
  private String notes = null;

  @JsonProperty("operationDate")
  private OffsetDateTime operationDate = null;

  @JsonProperty("operatorUser")
  private String operatorUser = null;

  @JsonProperty("payload")
  private String payload = null;

  @JsonProperty("payloadRequest")
  private String payloadRequest = null;

  @JsonProperty("payloadResponse")
  private String payloadResponse = null;

  @JsonProperty("startOperationTime")
  private Long startOperationTime = null;

  @JsonProperty("operationTime")
  private Long operationTime = null;

  @JsonProperty("fmwsOperation")
  private String fmwsOperation = null;

  @JsonProperty("rifId")
  private String rifId = null;

  @JsonProperty("troubleTicketId")
  private String troubleTicketId = null;

  @JsonProperty("ipAddress")
  private String ipAddress = null;

  @JsonProperty("endOperation")
  private OffsetDateTime endOperation = null;

  public HistoryDTO startOperation(OffsetDateTime startOperation) {
    this.startOperation = startOperation;
    return this;
  }

  /**
   * Get startOperation
   * @return startOperation
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getStartOperation() {
    return startOperation;
  }

  public void setStartOperation(OffsetDateTime startOperation) {
    this.startOperation = startOperation;
  }

  public HistoryDTO assigneeGroup(String assigneeGroup) {
    this.assigneeGroup = assigneeGroup;
    return this;
  }

  /**
   * Get assigneeGroup
   * @return assigneeGroup
   **/
  @Schema(description = "")
  
    public String getAssigneeGroup() {
    return assigneeGroup;
  }

  public void setAssigneeGroup(String assigneeGroup) {
    this.assigneeGroup = assigneeGroup;
  }

  public HistoryDTO notes(String notes) {
    this.notes = notes;
    return this;
  }

  /**
   * Get notes
   * @return notes
   **/
  @Schema(description = "")
  
    public String getNotes() {
    return notes;
  }

  public void setNotes(String notes) {
    this.notes = notes;
  }

  public HistoryDTO operationDate(OffsetDateTime operationDate) {
    this.operationDate = operationDate;
    return this;
  }

  /**
   * Get operationDate
   * @return operationDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOperationDate() {
    return operationDate;
  }

  public void setOperationDate(OffsetDateTime operationDate) {
    this.operationDate = operationDate;
  }

  public HistoryDTO operatorUser(String operatorUser) {
    this.operatorUser = operatorUser;
    return this;
  }

  /**
   * Get operatorUser
   * @return operatorUser
   **/
  @Schema(description = "")
  
    public String getOperatorUser() {
    return operatorUser;
  }

  public void setOperatorUser(String operatorUser) {
    this.operatorUser = operatorUser;
  }

  public HistoryDTO payload(String payload) {
    this.payload = payload;
    return this;
  }

  /**
   * Get payload
   * @return payload
   **/
  @Schema(description = "")
  
    public String getPayload() {
    return payload;
  }

  public void setPayload(String payload) {
    this.payload = payload;
  }

  public HistoryDTO payloadRequest(String payloadRequest) {
    this.payloadRequest = payloadRequest;
    return this;
  }

  /**
   * Get payloadRequest
   * @return payloadRequest
   **/
  @Schema(description = "")
  
    public String getPayloadRequest() {
    return payloadRequest;
  }

  public void setPayloadRequest(String payloadRequest) {
    this.payloadRequest = payloadRequest;
  }

  public HistoryDTO payloadResponse(String payloadResponse) {
    this.payloadResponse = payloadResponse;
    return this;
  }

  /**
   * Get payloadResponse
   * @return payloadResponse
   **/
  @Schema(description = "")
  
    public String getPayloadResponse() {
    return payloadResponse;
  }

  public void setPayloadResponse(String payloadResponse) {
    this.payloadResponse = payloadResponse;
  }

  public HistoryDTO startOperationTime(Long startOperationTime) {
    this.startOperationTime = startOperationTime;
    return this;
  }

  /**
   * Get startOperationTime
   * @return startOperationTime
   **/
  @Schema(description = "")
  
    public Long getStartOperationTime() {
    return startOperationTime;
  }

  public void setStartOperationTime(Long startOperationTime) {
    this.startOperationTime = startOperationTime;
  }

  public HistoryDTO operationTime(Long operationTime) {
    this.operationTime = operationTime;
    return this;
  }

  /**
   * Get operationTime
   * @return operationTime
   **/
  @Schema(description = "")
  
    public Long getOperationTime() {
    return operationTime;
  }

  public void setOperationTime(Long operationTime) {
    this.operationTime = operationTime;
  }

  public HistoryDTO fmwsOperation(String fmwsOperation) {
    this.fmwsOperation = fmwsOperation;
    return this;
  }

  /**
   * Get fmwsOperation
   * @return fmwsOperation
   **/
  @Schema(description = "")
  
    public String getFmwsOperation() {
    return fmwsOperation;
  }

  public void setFmwsOperation(String fmwsOperation) {
    this.fmwsOperation = fmwsOperation;
  }

  public HistoryDTO rifId(String rifId) {
    this.rifId = rifId;
    return this;
  }

  /**
   * Get rifId
   * @return rifId
   **/
  @Schema(description = "")
  
    public String getRifId() {
    return rifId;
  }

  public void setRifId(String rifId) {
    this.rifId = rifId;
  }

  public HistoryDTO troubleTicketId(String troubleTicketId) {
    this.troubleTicketId = troubleTicketId;
    return this;
  }

  /**
   * Get troubleTicketId
   * @return troubleTicketId
   **/
  @Schema(description = "")
  
    public String getTroubleTicketId() {
    return troubleTicketId;
  }

  public void setTroubleTicketId(String troubleTicketId) {
    this.troubleTicketId = troubleTicketId;
  }

  public HistoryDTO ipAddress(String ipAddress) {
    this.ipAddress = ipAddress;
    return this;
  }

  /**
   * Get ipAddress
   * @return ipAddress
   **/
  @Schema(description = "")
  
    public String getIpAddress() {
    return ipAddress;
  }

  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  public HistoryDTO endOperation(OffsetDateTime endOperation) {
    this.endOperation = endOperation;
    return this;
  }

  /**
   * Get endOperation
   * @return endOperation
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getEndOperation() {
    return endOperation;
  }

  public void setEndOperation(OffsetDateTime endOperation) {
    this.endOperation = endOperation;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HistoryDTO historyDTO = (HistoryDTO) o;
    return Objects.equals(this.startOperation, historyDTO.startOperation) &&
        Objects.equals(this.assigneeGroup, historyDTO.assigneeGroup) &&
        Objects.equals(this.notes, historyDTO.notes) &&
        Objects.equals(this.operationDate, historyDTO.operationDate) &&
        Objects.equals(this.operatorUser, historyDTO.operatorUser) &&
        Objects.equals(this.payload, historyDTO.payload) &&
        Objects.equals(this.payloadRequest, historyDTO.payloadRequest) &&
        Objects.equals(this.payloadResponse, historyDTO.payloadResponse) &&
        Objects.equals(this.startOperationTime, historyDTO.startOperationTime) &&
        Objects.equals(this.operationTime, historyDTO.operationTime) &&
        Objects.equals(this.fmwsOperation, historyDTO.fmwsOperation) &&
        Objects.equals(this.rifId, historyDTO.rifId) &&
        Objects.equals(this.troubleTicketId, historyDTO.troubleTicketId) &&
        Objects.equals(this.ipAddress, historyDTO.ipAddress) &&
        Objects.equals(this.endOperation, historyDTO.endOperation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(startOperation, assigneeGroup, notes, operationDate, operatorUser, payload, payloadRequest, payloadResponse, startOperationTime, operationTime, fmwsOperation, rifId, troubleTicketId, ipAddress, endOperation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HistoryDTO {\n");
    
    sb.append("    startOperation: ").append(toIndentedString(startOperation)).append("\n");
    sb.append("    assigneeGroup: ").append(toIndentedString(assigneeGroup)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    operationDate: ").append(toIndentedString(operationDate)).append("\n");
    sb.append("    operatorUser: ").append(toIndentedString(operatorUser)).append("\n");
    sb.append("    payload: ").append(toIndentedString(payload)).append("\n");
    sb.append("    payloadRequest: ").append(toIndentedString(payloadRequest)).append("\n");
    sb.append("    payloadResponse: ").append(toIndentedString(payloadResponse)).append("\n");
    sb.append("    startOperationTime: ").append(toIndentedString(startOperationTime)).append("\n");
    sb.append("    operationTime: ").append(toIndentedString(operationTime)).append("\n");
    sb.append("    fmwsOperation: ").append(toIndentedString(fmwsOperation)).append("\n");
    sb.append("    rifId: ").append(toIndentedString(rifId)).append("\n");
    sb.append("    troubleTicketId: ").append(toIndentedString(troubleTicketId)).append("\n");
    sb.append("    ipAddress: ").append(toIndentedString(ipAddress)).append("\n");
    sb.append("    endOperation: ").append(toIndentedString(endOperation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
