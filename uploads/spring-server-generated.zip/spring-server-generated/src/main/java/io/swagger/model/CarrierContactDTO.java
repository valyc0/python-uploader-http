package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CarrierContactDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class CarrierContactDTO   {
  @JsonProperty("acronym")
  private String acronym = null;

  @JsonProperty("listContact231")
  private String listContact231 = null;

  @JsonProperty("listContactCm")
  private String listContactCm = null;

  @JsonProperty("name")
  private String name = null;

  public CarrierContactDTO acronym(String acronym) {
    this.acronym = acronym;
    return this;
  }

  /**
   * Get acronym
   * @return acronym
   **/
  @Schema(description = "")
  
    public String getAcronym() {
    return acronym;
  }

  public void setAcronym(String acronym) {
    this.acronym = acronym;
  }

  public CarrierContactDTO listContact231(String listContact231) {
    this.listContact231 = listContact231;
    return this;
  }

  /**
   * Get listContact231
   * @return listContact231
   **/
  @Schema(description = "")
  
    public String getListContact231() {
    return listContact231;
  }

  public void setListContact231(String listContact231) {
    this.listContact231 = listContact231;
  }

  public CarrierContactDTO listContactCm(String listContactCm) {
    this.listContactCm = listContactCm;
    return this;
  }

  /**
   * Get listContactCm
   * @return listContactCm
   **/
  @Schema(description = "")
  
    public String getListContactCm() {
    return listContactCm;
  }

  public void setListContactCm(String listContactCm) {
    this.listContactCm = listContactCm;
  }

  public CarrierContactDTO name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   **/
  @Schema(description = "")
  
    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CarrierContactDTO carrierContactDTO = (CarrierContactDTO) o;
    return Objects.equals(this.acronym, carrierContactDTO.acronym) &&
        Objects.equals(this.listContact231, carrierContactDTO.listContact231) &&
        Objects.equals(this.listContactCm, carrierContactDTO.listContactCm) &&
        Objects.equals(this.name, carrierContactDTO.name);
  }

  @Override
  public int hashCode() {
    return Objects.hash(acronym, listContact231, listContactCm, name);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CarrierContactDTO {\n");
    
    sb.append("    acronym: ").append(toIndentedString(acronym)).append("\n");
    sb.append("    listContact231: ").append(toIndentedString(listContact231)).append("\n");
    sb.append("    listContactCm: ").append(toIndentedString(listContactCm)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
