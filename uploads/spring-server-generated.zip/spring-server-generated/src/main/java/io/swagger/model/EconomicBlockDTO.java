package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * EconomicBlockDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class EconomicBlockDTO   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("disputeId")
  private String disputeId = null;

  @JsonProperty("rifId")
  private String rifId = null;

  @JsonProperty("subrifId")
  private String subrifId = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("trafficStartDate")
  private OffsetDateTime trafficStartDate = null;

  @JsonProperty("trafficEndDate")
  private OffsetDateTime trafficEndDate = null;

  @JsonProperty("reportingDate")
  private OffsetDateTime reportingDate = null;

  @JsonProperty("year")
  private String year = null;

  @JsonProperty("month")
  private String month = null;

  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("istrout")
  private String istrout = null;

  @JsonProperty("areaIn")
  private String areaIn = null;

  @JsonProperty("areaOut")
  private String areaOut = null;

  @JsonProperty("entityIn")
  private String entityIn = null;

  @JsonProperty("entityOut")
  private String entityOut = null;

  @JsonProperty("minute")
  private Double minute = null;

  @JsonProperty("debEur")
  private Double debEur = null;

  @JsonProperty("debUsd")
  private Double debUsd = null;

  @JsonProperty("creEur")
  private Double creEur = null;

  @JsonProperty("creUsd")
  private Double creUsd = null;

  @JsonProperty("note")
  private String note = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("blockDate")
  private OffsetDateTime blockDate = null;

  @JsonProperty("creUnblockDate")
  private OffsetDateTime creUnblockDate = null;

  @JsonProperty("debUnblockDate")
  private OffsetDateTime debUnblockDate = null;

  @JsonProperty("createDate")
  private OffsetDateTime createDate = null;

  @JsonProperty("lastUpdateDate")
  private OffsetDateTime lastUpdateDate = null;

  @JsonProperty("currencyDefaultCredit")
  private String currencyDefaultCredit = null;

  @JsonProperty("currencyDefaultDebit")
  private String currencyDefaultDebit = null;

  @JsonProperty("cred")
  private Double cred = null;

  @JsonProperty("deb")
  private Double deb = null;

  @JsonProperty("flagBlockCredit")
  private Boolean flagBlockCredit = null;

  @JsonProperty("flagBlockDebit")
  private Boolean flagBlockDebit = null;

  @JsonProperty("flagDenuncia")
  private Boolean flagDenuncia = null;

  @JsonProperty("flagCIA")
  private Boolean flagCIA = null;

  @JsonProperty("economicType")
  private String economicType = null;

  @JsonProperty("disputaIdCredit")
  private String disputaIdCredit = null;

  @JsonProperty("disputaCreditStatus")
  private String disputaCreditStatus = null;

  @JsonProperty("disputaDebitStatus")
  private String disputaDebitStatus = null;

  @JsonProperty("blockCreditDate")
  private OffsetDateTime blockCreditDate = null;

  @JsonProperty("blockDebitDate")
  private OffsetDateTime blockDebitDate = null;

  public EconomicBlockDTO id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public EconomicBlockDTO disputeId(String disputeId) {
    this.disputeId = disputeId;
    return this;
  }

  /**
   * Get disputeId
   * @return disputeId
   **/
  @Schema(description = "")
  
    public String getDisputeId() {
    return disputeId;
  }

  public void setDisputeId(String disputeId) {
    this.disputeId = disputeId;
  }

  public EconomicBlockDTO rifId(String rifId) {
    this.rifId = rifId;
    return this;
  }

  /**
   * Get rifId
   * @return rifId
   **/
  @Schema(description = "")
  
    public String getRifId() {
    return rifId;
  }

  public void setRifId(String rifId) {
    this.rifId = rifId;
  }

  public EconomicBlockDTO subrifId(String subrifId) {
    this.subrifId = subrifId;
    return this;
  }

  /**
   * Get subrifId
   * @return subrifId
   **/
  @Schema(description = "")
  
    public String getSubrifId() {
    return subrifId;
  }

  public void setSubrifId(String subrifId) {
    this.subrifId = subrifId;
  }

  public EconomicBlockDTO sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public EconomicBlockDTO trafficStartDate(OffsetDateTime trafficStartDate) {
    this.trafficStartDate = trafficStartDate;
    return this;
  }

  /**
   * Get trafficStartDate
   * @return trafficStartDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getTrafficStartDate() {
    return trafficStartDate;
  }

  public void setTrafficStartDate(OffsetDateTime trafficStartDate) {
    this.trafficStartDate = trafficStartDate;
  }

  public EconomicBlockDTO trafficEndDate(OffsetDateTime trafficEndDate) {
    this.trafficEndDate = trafficEndDate;
    return this;
  }

  /**
   * Get trafficEndDate
   * @return trafficEndDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getTrafficEndDate() {
    return trafficEndDate;
  }

  public void setTrafficEndDate(OffsetDateTime trafficEndDate) {
    this.trafficEndDate = trafficEndDate;
  }

  public EconomicBlockDTO reportingDate(OffsetDateTime reportingDate) {
    this.reportingDate = reportingDate;
    return this;
  }

  /**
   * Get reportingDate
   * @return reportingDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getReportingDate() {
    return reportingDate;
  }

  public void setReportingDate(OffsetDateTime reportingDate) {
    this.reportingDate = reportingDate;
  }

  public EconomicBlockDTO year(String year) {
    this.year = year;
    return this;
  }

  /**
   * Get year
   * @return year
   **/
  @Schema(description = "")
  
    public String getYear() {
    return year;
  }

  public void setYear(String year) {
    this.year = year;
  }

  public EconomicBlockDTO month(String month) {
    this.month = month;
    return this;
  }

  /**
   * Get month
   * @return month
   **/
  @Schema(description = "")
  
    public String getMonth() {
    return month;
  }

  public void setMonth(String month) {
    this.month = month;
  }

  public EconomicBlockDTO istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public EconomicBlockDTO istrout(String istrout) {
    this.istrout = istrout;
    return this;
  }

  /**
   * Get istrout
   * @return istrout
   **/
  @Schema(description = "")
  
    public String getIstrout() {
    return istrout;
  }

  public void setIstrout(String istrout) {
    this.istrout = istrout;
  }

  public EconomicBlockDTO areaIn(String areaIn) {
    this.areaIn = areaIn;
    return this;
  }

  /**
   * Get areaIn
   * @return areaIn
   **/
  @Schema(description = "")
  
    public String getAreaIn() {
    return areaIn;
  }

  public void setAreaIn(String areaIn) {
    this.areaIn = areaIn;
  }

  public EconomicBlockDTO areaOut(String areaOut) {
    this.areaOut = areaOut;
    return this;
  }

  /**
   * Get areaOut
   * @return areaOut
   **/
  @Schema(description = "")
  
    public String getAreaOut() {
    return areaOut;
  }

  public void setAreaOut(String areaOut) {
    this.areaOut = areaOut;
  }

  public EconomicBlockDTO entityIn(String entityIn) {
    this.entityIn = entityIn;
    return this;
  }

  /**
   * Get entityIn
   * @return entityIn
   **/
  @Schema(description = "")
  
    public String getEntityIn() {
    return entityIn;
  }

  public void setEntityIn(String entityIn) {
    this.entityIn = entityIn;
  }

  public EconomicBlockDTO entityOut(String entityOut) {
    this.entityOut = entityOut;
    return this;
  }

  /**
   * Get entityOut
   * @return entityOut
   **/
  @Schema(description = "")
  
    public String getEntityOut() {
    return entityOut;
  }

  public void setEntityOut(String entityOut) {
    this.entityOut = entityOut;
  }

  public EconomicBlockDTO minute(Double minute) {
    this.minute = minute;
    return this;
  }

  /**
   * Get minute
   * @return minute
   **/
  @Schema(description = "")
  
    public Double getMinute() {
    return minute;
  }

  public void setMinute(Double minute) {
    this.minute = minute;
  }

  public EconomicBlockDTO debEur(Double debEur) {
    this.debEur = debEur;
    return this;
  }

  /**
   * Get debEur
   * @return debEur
   **/
  @Schema(description = "")
  
    public Double getDebEur() {
    return debEur;
  }

  public void setDebEur(Double debEur) {
    this.debEur = debEur;
  }

  public EconomicBlockDTO debUsd(Double debUsd) {
    this.debUsd = debUsd;
    return this;
  }

  /**
   * Get debUsd
   * @return debUsd
   **/
  @Schema(description = "")
  
    public Double getDebUsd() {
    return debUsd;
  }

  public void setDebUsd(Double debUsd) {
    this.debUsd = debUsd;
  }

  public EconomicBlockDTO creEur(Double creEur) {
    this.creEur = creEur;
    return this;
  }

  /**
   * Get creEur
   * @return creEur
   **/
  @Schema(description = "")
  
    public Double getCreEur() {
    return creEur;
  }

  public void setCreEur(Double creEur) {
    this.creEur = creEur;
  }

  public EconomicBlockDTO creUsd(Double creUsd) {
    this.creUsd = creUsd;
    return this;
  }

  /**
   * Get creUsd
   * @return creUsd
   **/
  @Schema(description = "")
  
    public Double getCreUsd() {
    return creUsd;
  }

  public void setCreUsd(Double creUsd) {
    this.creUsd = creUsd;
  }

  public EconomicBlockDTO note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
   **/
  @Schema(description = "")
  
    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public EconomicBlockDTO status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  @Schema(description = "")
  
    public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public EconomicBlockDTO blockDate(OffsetDateTime blockDate) {
    this.blockDate = blockDate;
    return this;
  }

  /**
   * Get blockDate
   * @return blockDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getBlockDate() {
    return blockDate;
  }

  public void setBlockDate(OffsetDateTime blockDate) {
    this.blockDate = blockDate;
  }

  public EconomicBlockDTO creUnblockDate(OffsetDateTime creUnblockDate) {
    this.creUnblockDate = creUnblockDate;
    return this;
  }

  /**
   * Get creUnblockDate
   * @return creUnblockDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getCreUnblockDate() {
    return creUnblockDate;
  }

  public void setCreUnblockDate(OffsetDateTime creUnblockDate) {
    this.creUnblockDate = creUnblockDate;
  }

  public EconomicBlockDTO debUnblockDate(OffsetDateTime debUnblockDate) {
    this.debUnblockDate = debUnblockDate;
    return this;
  }

  /**
   * Get debUnblockDate
   * @return debUnblockDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDebUnblockDate() {
    return debUnblockDate;
  }

  public void setDebUnblockDate(OffsetDateTime debUnblockDate) {
    this.debUnblockDate = debUnblockDate;
  }

  public EconomicBlockDTO createDate(OffsetDateTime createDate) {
    this.createDate = createDate;
    return this;
  }

  /**
   * Get createDate
   * @return createDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getCreateDate() {
    return createDate;
  }

  public void setCreateDate(OffsetDateTime createDate) {
    this.createDate = createDate;
  }

  public EconomicBlockDTO lastUpdateDate(OffsetDateTime lastUpdateDate) {
    this.lastUpdateDate = lastUpdateDate;
    return this;
  }

  /**
   * Get lastUpdateDate
   * @return lastUpdateDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastUpdateDate() {
    return lastUpdateDate;
  }

  public void setLastUpdateDate(OffsetDateTime lastUpdateDate) {
    this.lastUpdateDate = lastUpdateDate;
  }

  public EconomicBlockDTO currencyDefaultCredit(String currencyDefaultCredit) {
    this.currencyDefaultCredit = currencyDefaultCredit;
    return this;
  }

  /**
   * Get currencyDefaultCredit
   * @return currencyDefaultCredit
   **/
  @Schema(description = "")
  
    public String getCurrencyDefaultCredit() {
    return currencyDefaultCredit;
  }

  public void setCurrencyDefaultCredit(String currencyDefaultCredit) {
    this.currencyDefaultCredit = currencyDefaultCredit;
  }

  public EconomicBlockDTO currencyDefaultDebit(String currencyDefaultDebit) {
    this.currencyDefaultDebit = currencyDefaultDebit;
    return this;
  }

  /**
   * Get currencyDefaultDebit
   * @return currencyDefaultDebit
   **/
  @Schema(description = "")
  
    public String getCurrencyDefaultDebit() {
    return currencyDefaultDebit;
  }

  public void setCurrencyDefaultDebit(String currencyDefaultDebit) {
    this.currencyDefaultDebit = currencyDefaultDebit;
  }

  public EconomicBlockDTO cred(Double cred) {
    this.cred = cred;
    return this;
  }

  /**
   * Get cred
   * @return cred
   **/
  @Schema(description = "")
  
    public Double getCred() {
    return cred;
  }

  public void setCred(Double cred) {
    this.cred = cred;
  }

  public EconomicBlockDTO deb(Double deb) {
    this.deb = deb;
    return this;
  }

  /**
   * Get deb
   * @return deb
   **/
  @Schema(description = "")
  
    public Double getDeb() {
    return deb;
  }

  public void setDeb(Double deb) {
    this.deb = deb;
  }

  public EconomicBlockDTO flagBlockCredit(Boolean flagBlockCredit) {
    this.flagBlockCredit = flagBlockCredit;
    return this;
  }

  /**
   * Get flagBlockCredit
   * @return flagBlockCredit
   **/
  @Schema(description = "")
  
    public Boolean isFlagBlockCredit() {
    return flagBlockCredit;
  }

  public void setFlagBlockCredit(Boolean flagBlockCredit) {
    this.flagBlockCredit = flagBlockCredit;
  }

  public EconomicBlockDTO flagBlockDebit(Boolean flagBlockDebit) {
    this.flagBlockDebit = flagBlockDebit;
    return this;
  }

  /**
   * Get flagBlockDebit
   * @return flagBlockDebit
   **/
  @Schema(description = "")
  
    public Boolean isFlagBlockDebit() {
    return flagBlockDebit;
  }

  public void setFlagBlockDebit(Boolean flagBlockDebit) {
    this.flagBlockDebit = flagBlockDebit;
  }

  public EconomicBlockDTO flagDenuncia(Boolean flagDenuncia) {
    this.flagDenuncia = flagDenuncia;
    return this;
  }

  /**
   * Get flagDenuncia
   * @return flagDenuncia
   **/
  @Schema(description = "")
  
    public Boolean isFlagDenuncia() {
    return flagDenuncia;
  }

  public void setFlagDenuncia(Boolean flagDenuncia) {
    this.flagDenuncia = flagDenuncia;
  }

  public EconomicBlockDTO flagCIA(Boolean flagCIA) {
    this.flagCIA = flagCIA;
    return this;
  }

  /**
   * Get flagCIA
   * @return flagCIA
   **/
  @Schema(description = "")
  
    public Boolean isFlagCIA() {
    return flagCIA;
  }

  public void setFlagCIA(Boolean flagCIA) {
    this.flagCIA = flagCIA;
  }

  public EconomicBlockDTO economicType(String economicType) {
    this.economicType = economicType;
    return this;
  }

  /**
   * Get economicType
   * @return economicType
   **/
  @Schema(description = "")
  
    public String getEconomicType() {
    return economicType;
  }

  public void setEconomicType(String economicType) {
    this.economicType = economicType;
  }

  public EconomicBlockDTO disputaIdCredit(String disputaIdCredit) {
    this.disputaIdCredit = disputaIdCredit;
    return this;
  }

  /**
   * Get disputaIdCredit
   * @return disputaIdCredit
   **/
  @Schema(description = "")
  
    public String getDisputaIdCredit() {
    return disputaIdCredit;
  }

  public void setDisputaIdCredit(String disputaIdCredit) {
    this.disputaIdCredit = disputaIdCredit;
  }

  public EconomicBlockDTO disputaCreditStatus(String disputaCreditStatus) {
    this.disputaCreditStatus = disputaCreditStatus;
    return this;
  }

  /**
   * Get disputaCreditStatus
   * @return disputaCreditStatus
   **/
  @Schema(description = "")
  
    public String getDisputaCreditStatus() {
    return disputaCreditStatus;
  }

  public void setDisputaCreditStatus(String disputaCreditStatus) {
    this.disputaCreditStatus = disputaCreditStatus;
  }

  public EconomicBlockDTO disputaDebitStatus(String disputaDebitStatus) {
    this.disputaDebitStatus = disputaDebitStatus;
    return this;
  }

  /**
   * Get disputaDebitStatus
   * @return disputaDebitStatus
   **/
  @Schema(description = "")
  
    public String getDisputaDebitStatus() {
    return disputaDebitStatus;
  }

  public void setDisputaDebitStatus(String disputaDebitStatus) {
    this.disputaDebitStatus = disputaDebitStatus;
  }

  public EconomicBlockDTO blockCreditDate(OffsetDateTime blockCreditDate) {
    this.blockCreditDate = blockCreditDate;
    return this;
  }

  /**
   * Get blockCreditDate
   * @return blockCreditDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getBlockCreditDate() {
    return blockCreditDate;
  }

  public void setBlockCreditDate(OffsetDateTime blockCreditDate) {
    this.blockCreditDate = blockCreditDate;
  }

  public EconomicBlockDTO blockDebitDate(OffsetDateTime blockDebitDate) {
    this.blockDebitDate = blockDebitDate;
    return this;
  }

  /**
   * Get blockDebitDate
   * @return blockDebitDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getBlockDebitDate() {
    return blockDebitDate;
  }

  public void setBlockDebitDate(OffsetDateTime blockDebitDate) {
    this.blockDebitDate = blockDebitDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EconomicBlockDTO economicBlockDTO = (EconomicBlockDTO) o;
    return Objects.equals(this.id, economicBlockDTO.id) &&
        Objects.equals(this.disputeId, economicBlockDTO.disputeId) &&
        Objects.equals(this.rifId, economicBlockDTO.rifId) &&
        Objects.equals(this.subrifId, economicBlockDTO.subrifId) &&
        Objects.equals(this.sellingDestination, economicBlockDTO.sellingDestination) &&
        Objects.equals(this.trafficStartDate, economicBlockDTO.trafficStartDate) &&
        Objects.equals(this.trafficEndDate, economicBlockDTO.trafficEndDate) &&
        Objects.equals(this.reportingDate, economicBlockDTO.reportingDate) &&
        Objects.equals(this.year, economicBlockDTO.year) &&
        Objects.equals(this.month, economicBlockDTO.month) &&
        Objects.equals(this.istrin, economicBlockDTO.istrin) &&
        Objects.equals(this.istrout, economicBlockDTO.istrout) &&
        Objects.equals(this.areaIn, economicBlockDTO.areaIn) &&
        Objects.equals(this.areaOut, economicBlockDTO.areaOut) &&
        Objects.equals(this.entityIn, economicBlockDTO.entityIn) &&
        Objects.equals(this.entityOut, economicBlockDTO.entityOut) &&
        Objects.equals(this.minute, economicBlockDTO.minute) &&
        Objects.equals(this.debEur, economicBlockDTO.debEur) &&
        Objects.equals(this.debUsd, economicBlockDTO.debUsd) &&
        Objects.equals(this.creEur, economicBlockDTO.creEur) &&
        Objects.equals(this.creUsd, economicBlockDTO.creUsd) &&
        Objects.equals(this.note, economicBlockDTO.note) &&
        Objects.equals(this.status, economicBlockDTO.status) &&
        Objects.equals(this.blockDate, economicBlockDTO.blockDate) &&
        Objects.equals(this.creUnblockDate, economicBlockDTO.creUnblockDate) &&
        Objects.equals(this.debUnblockDate, economicBlockDTO.debUnblockDate) &&
        Objects.equals(this.createDate, economicBlockDTO.createDate) &&
        Objects.equals(this.lastUpdateDate, economicBlockDTO.lastUpdateDate) &&
        Objects.equals(this.currencyDefaultCredit, economicBlockDTO.currencyDefaultCredit) &&
        Objects.equals(this.currencyDefaultDebit, economicBlockDTO.currencyDefaultDebit) &&
        Objects.equals(this.cred, economicBlockDTO.cred) &&
        Objects.equals(this.deb, economicBlockDTO.deb) &&
        Objects.equals(this.flagBlockCredit, economicBlockDTO.flagBlockCredit) &&
        Objects.equals(this.flagBlockDebit, economicBlockDTO.flagBlockDebit) &&
        Objects.equals(this.flagDenuncia, economicBlockDTO.flagDenuncia) &&
        Objects.equals(this.flagCIA, economicBlockDTO.flagCIA) &&
        Objects.equals(this.economicType, economicBlockDTO.economicType) &&
        Objects.equals(this.disputaIdCredit, economicBlockDTO.disputaIdCredit) &&
        Objects.equals(this.disputaCreditStatus, economicBlockDTO.disputaCreditStatus) &&
        Objects.equals(this.disputaDebitStatus, economicBlockDTO.disputaDebitStatus) &&
        Objects.equals(this.blockCreditDate, economicBlockDTO.blockCreditDate) &&
        Objects.equals(this.blockDebitDate, economicBlockDTO.blockDebitDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, disputeId, rifId, subrifId, sellingDestination, trafficStartDate, trafficEndDate, reportingDate, year, month, istrin, istrout, areaIn, areaOut, entityIn, entityOut, minute, debEur, debUsd, creEur, creUsd, note, status, blockDate, creUnblockDate, debUnblockDate, createDate, lastUpdateDate, currencyDefaultCredit, currencyDefaultDebit, cred, deb, flagBlockCredit, flagBlockDebit, flagDenuncia, flagCIA, economicType, disputaIdCredit, disputaCreditStatus, disputaDebitStatus, blockCreditDate, blockDebitDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EconomicBlockDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    disputeId: ").append(toIndentedString(disputeId)).append("\n");
    sb.append("    rifId: ").append(toIndentedString(rifId)).append("\n");
    sb.append("    subrifId: ").append(toIndentedString(subrifId)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    trafficStartDate: ").append(toIndentedString(trafficStartDate)).append("\n");
    sb.append("    trafficEndDate: ").append(toIndentedString(trafficEndDate)).append("\n");
    sb.append("    reportingDate: ").append(toIndentedString(reportingDate)).append("\n");
    sb.append("    year: ").append(toIndentedString(year)).append("\n");
    sb.append("    month: ").append(toIndentedString(month)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    istrout: ").append(toIndentedString(istrout)).append("\n");
    sb.append("    areaIn: ").append(toIndentedString(areaIn)).append("\n");
    sb.append("    areaOut: ").append(toIndentedString(areaOut)).append("\n");
    sb.append("    entityIn: ").append(toIndentedString(entityIn)).append("\n");
    sb.append("    entityOut: ").append(toIndentedString(entityOut)).append("\n");
    sb.append("    minute: ").append(toIndentedString(minute)).append("\n");
    sb.append("    debEur: ").append(toIndentedString(debEur)).append("\n");
    sb.append("    debUsd: ").append(toIndentedString(debUsd)).append("\n");
    sb.append("    creEur: ").append(toIndentedString(creEur)).append("\n");
    sb.append("    creUsd: ").append(toIndentedString(creUsd)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    blockDate: ").append(toIndentedString(blockDate)).append("\n");
    sb.append("    creUnblockDate: ").append(toIndentedString(creUnblockDate)).append("\n");
    sb.append("    debUnblockDate: ").append(toIndentedString(debUnblockDate)).append("\n");
    sb.append("    createDate: ").append(toIndentedString(createDate)).append("\n");
    sb.append("    lastUpdateDate: ").append(toIndentedString(lastUpdateDate)).append("\n");
    sb.append("    currencyDefaultCredit: ").append(toIndentedString(currencyDefaultCredit)).append("\n");
    sb.append("    currencyDefaultDebit: ").append(toIndentedString(currencyDefaultDebit)).append("\n");
    sb.append("    cred: ").append(toIndentedString(cred)).append("\n");
    sb.append("    deb: ").append(toIndentedString(deb)).append("\n");
    sb.append("    flagBlockCredit: ").append(toIndentedString(flagBlockCredit)).append("\n");
    sb.append("    flagBlockDebit: ").append(toIndentedString(flagBlockDebit)).append("\n");
    sb.append("    flagDenuncia: ").append(toIndentedString(flagDenuncia)).append("\n");
    sb.append("    flagCIA: ").append(toIndentedString(flagCIA)).append("\n");
    sb.append("    economicType: ").append(toIndentedString(economicType)).append("\n");
    sb.append("    disputaIdCredit: ").append(toIndentedString(disputaIdCredit)).append("\n");
    sb.append("    disputaCreditStatus: ").append(toIndentedString(disputaCreditStatus)).append("\n");
    sb.append("    disputaDebitStatus: ").append(toIndentedString(disputaDebitStatus)).append("\n");
    sb.append("    blockCreditDate: ").append(toIndentedString(blockCreditDate)).append("\n");
    sb.append("    blockDebitDate: ").append(toIndentedString(blockDebitDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
