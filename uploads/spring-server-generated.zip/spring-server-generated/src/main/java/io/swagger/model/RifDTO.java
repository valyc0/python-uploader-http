package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.DenunciaDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RifDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class RifDTO   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("rif")
  private String rif = null;

  @JsonProperty("fonte")
  private String fonte = null;

  @JsonProperty("manual")
  private Boolean manual = null;

  @JsonProperty("dataRilevamento")
  private String dataRilevamento = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("istrout")
  private String istrout = null;

  @JsonProperty("istrin_id")
  private String istrinId = null;

  @JsonProperty("istrout_id")
  private String istroutId = null;

  @JsonProperty("minuti")
  private BigDecimal minuti = null;

  @JsonProperty("valorizzazione")
  private BigDecimal valorizzazione = null;

  @JsonProperty("risultanzeAnalisi")
  private String risultanzeAnalisi = null;

  @JsonProperty("azioniAmministr")
  private String azioniAmministr = null;

  @JsonProperty("denunciaAutorita")
  private String denunciaAutorita = null;

  @JsonProperty("note")
  private String note = null;

  @JsonProperty("dataComplIntervento")
  private OffsetDateTime dataComplIntervento = null;

  @JsonProperty("dataCreazione")
  private OffsetDateTime dataCreazione = null;

  @JsonProperty("risultato")
  private String risultato = null;

  @JsonProperty("detection")
  private String detection = null;

  @JsonProperty("denunciaDTOs")
  @Valid
  private List<DenunciaDTO> denunciaDTOs = null;

  public RifDTO id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public RifDTO rif(String rif) {
    this.rif = rif;
    return this;
  }

  /**
   * Get rif
   * @return rif
   **/
  @Schema(description = "")
  
    public String getRif() {
    return rif;
  }

  public void setRif(String rif) {
    this.rif = rif;
  }

  public RifDTO fonte(String fonte) {
    this.fonte = fonte;
    return this;
  }

  /**
   * Get fonte
   * @return fonte
   **/
  @Schema(description = "")
  
    public String getFonte() {
    return fonte;
  }

  public void setFonte(String fonte) {
    this.fonte = fonte;
  }

  public RifDTO manual(Boolean manual) {
    this.manual = manual;
    return this;
  }

  /**
   * Get manual
   * @return manual
   **/
  @Schema(description = "")
  
    public Boolean isManual() {
    return manual;
  }

  public void setManual(Boolean manual) {
    this.manual = manual;
  }

  public RifDTO dataRilevamento(String dataRilevamento) {
    this.dataRilevamento = dataRilevamento;
    return this;
  }

  /**
   * Get dataRilevamento
   * @return dataRilevamento
   **/
  @Schema(description = "")
  
    public String getDataRilevamento() {
    return dataRilevamento;
  }

  public void setDataRilevamento(String dataRilevamento) {
    this.dataRilevamento = dataRilevamento;
  }

  public RifDTO sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public RifDTO istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public RifDTO istrout(String istrout) {
    this.istrout = istrout;
    return this;
  }

  /**
   * Get istrout
   * @return istrout
   **/
  @Schema(description = "")
  
    public String getIstrout() {
    return istrout;
  }

  public void setIstrout(String istrout) {
    this.istrout = istrout;
  }

  public RifDTO istrinId(String istrinId) {
    this.istrinId = istrinId;
    return this;
  }

  /**
   * Get istrinId
   * @return istrinId
   **/
  @Schema(description = "")
  
    public String getIstrinId() {
    return istrinId;
  }

  public void setIstrinId(String istrinId) {
    this.istrinId = istrinId;
  }

  public RifDTO istroutId(String istroutId) {
    this.istroutId = istroutId;
    return this;
  }

  /**
   * Get istroutId
   * @return istroutId
   **/
  @Schema(description = "")
  
    public String getIstroutId() {
    return istroutId;
  }

  public void setIstroutId(String istroutId) {
    this.istroutId = istroutId;
  }

  public RifDTO minuti(BigDecimal minuti) {
    this.minuti = minuti;
    return this;
  }

  /**
   * Get minuti
   * @return minuti
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getMinuti() {
    return minuti;
  }

  public void setMinuti(BigDecimal minuti) {
    this.minuti = minuti;
  }

  public RifDTO valorizzazione(BigDecimal valorizzazione) {
    this.valorizzazione = valorizzazione;
    return this;
  }

  /**
   * Get valorizzazione
   * @return valorizzazione
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getValorizzazione() {
    return valorizzazione;
  }

  public void setValorizzazione(BigDecimal valorizzazione) {
    this.valorizzazione = valorizzazione;
  }

  public RifDTO risultanzeAnalisi(String risultanzeAnalisi) {
    this.risultanzeAnalisi = risultanzeAnalisi;
    return this;
  }

  /**
   * Get risultanzeAnalisi
   * @return risultanzeAnalisi
   **/
  @Schema(description = "")
  
    public String getRisultanzeAnalisi() {
    return risultanzeAnalisi;
  }

  public void setRisultanzeAnalisi(String risultanzeAnalisi) {
    this.risultanzeAnalisi = risultanzeAnalisi;
  }

  public RifDTO azioniAmministr(String azioniAmministr) {
    this.azioniAmministr = azioniAmministr;
    return this;
  }

  /**
   * Get azioniAmministr
   * @return azioniAmministr
   **/
  @Schema(description = "")
  
    public String getAzioniAmministr() {
    return azioniAmministr;
  }

  public void setAzioniAmministr(String azioniAmministr) {
    this.azioniAmministr = azioniAmministr;
  }

  public RifDTO denunciaAutorita(String denunciaAutorita) {
    this.denunciaAutorita = denunciaAutorita;
    return this;
  }

  /**
   * Get denunciaAutorita
   * @return denunciaAutorita
   **/
  @Schema(description = "")
  
    public String getDenunciaAutorita() {
    return denunciaAutorita;
  }

  public void setDenunciaAutorita(String denunciaAutorita) {
    this.denunciaAutorita = denunciaAutorita;
  }

  public RifDTO note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
   **/
  @Schema(description = "")
  
    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public RifDTO dataComplIntervento(OffsetDateTime dataComplIntervento) {
    this.dataComplIntervento = dataComplIntervento;
    return this;
  }

  /**
   * Get dataComplIntervento
   * @return dataComplIntervento
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDataComplIntervento() {
    return dataComplIntervento;
  }

  public void setDataComplIntervento(OffsetDateTime dataComplIntervento) {
    this.dataComplIntervento = dataComplIntervento;
  }

  public RifDTO dataCreazione(OffsetDateTime dataCreazione) {
    this.dataCreazione = dataCreazione;
    return this;
  }

  /**
   * Get dataCreazione
   * @return dataCreazione
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDataCreazione() {
    return dataCreazione;
  }

  public void setDataCreazione(OffsetDateTime dataCreazione) {
    this.dataCreazione = dataCreazione;
  }

  public RifDTO risultato(String risultato) {
    this.risultato = risultato;
    return this;
  }

  /**
   * Get risultato
   * @return risultato
   **/
  @Schema(description = "")
  
    public String getRisultato() {
    return risultato;
  }

  public void setRisultato(String risultato) {
    this.risultato = risultato;
  }

  public RifDTO detection(String detection) {
    this.detection = detection;
    return this;
  }

  /**
   * Get detection
   * @return detection
   **/
  @Schema(description = "")
  
    public String getDetection() {
    return detection;
  }

  public void setDetection(String detection) {
    this.detection = detection;
  }

  public RifDTO denunciaDTOs(List<DenunciaDTO> denunciaDTOs) {
    this.denunciaDTOs = denunciaDTOs;
    return this;
  }

  public RifDTO addDenunciaDTOsItem(DenunciaDTO denunciaDTOsItem) {
    if (this.denunciaDTOs == null) {
      this.denunciaDTOs = new ArrayList<DenunciaDTO>();
    }
    this.denunciaDTOs.add(denunciaDTOsItem);
    return this;
  }

  /**
   * Get denunciaDTOs
   * @return denunciaDTOs
   **/
  @Schema(description = "")
      @Valid
    public List<DenunciaDTO> getDenunciaDTOs() {
    return denunciaDTOs;
  }

  public void setDenunciaDTOs(List<DenunciaDTO> denunciaDTOs) {
    this.denunciaDTOs = denunciaDTOs;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RifDTO rifDTO = (RifDTO) o;
    return Objects.equals(this.id, rifDTO.id) &&
        Objects.equals(this.rif, rifDTO.rif) &&
        Objects.equals(this.fonte, rifDTO.fonte) &&
        Objects.equals(this.manual, rifDTO.manual) &&
        Objects.equals(this.dataRilevamento, rifDTO.dataRilevamento) &&
        Objects.equals(this.sellingDestination, rifDTO.sellingDestination) &&
        Objects.equals(this.istrin, rifDTO.istrin) &&
        Objects.equals(this.istrout, rifDTO.istrout) &&
        Objects.equals(this.istrinId, rifDTO.istrinId) &&
        Objects.equals(this.istroutId, rifDTO.istroutId) &&
        Objects.equals(this.minuti, rifDTO.minuti) &&
        Objects.equals(this.valorizzazione, rifDTO.valorizzazione) &&
        Objects.equals(this.risultanzeAnalisi, rifDTO.risultanzeAnalisi) &&
        Objects.equals(this.azioniAmministr, rifDTO.azioniAmministr) &&
        Objects.equals(this.denunciaAutorita, rifDTO.denunciaAutorita) &&
        Objects.equals(this.note, rifDTO.note) &&
        Objects.equals(this.dataComplIntervento, rifDTO.dataComplIntervento) &&
        Objects.equals(this.dataCreazione, rifDTO.dataCreazione) &&
        Objects.equals(this.risultato, rifDTO.risultato) &&
        Objects.equals(this.detection, rifDTO.detection) &&
        Objects.equals(this.denunciaDTOs, rifDTO.denunciaDTOs);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, rif, fonte, manual, dataRilevamento, sellingDestination, istrin, istrout, istrinId, istroutId, minuti, valorizzazione, risultanzeAnalisi, azioniAmministr, denunciaAutorita, note, dataComplIntervento, dataCreazione, risultato, detection, denunciaDTOs);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RifDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    rif: ").append(toIndentedString(rif)).append("\n");
    sb.append("    fonte: ").append(toIndentedString(fonte)).append("\n");
    sb.append("    manual: ").append(toIndentedString(manual)).append("\n");
    sb.append("    dataRilevamento: ").append(toIndentedString(dataRilevamento)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    istrout: ").append(toIndentedString(istrout)).append("\n");
    sb.append("    istrinId: ").append(toIndentedString(istrinId)).append("\n");
    sb.append("    istroutId: ").append(toIndentedString(istroutId)).append("\n");
    sb.append("    minuti: ").append(toIndentedString(minuti)).append("\n");
    sb.append("    valorizzazione: ").append(toIndentedString(valorizzazione)).append("\n");
    sb.append("    risultanzeAnalisi: ").append(toIndentedString(risultanzeAnalisi)).append("\n");
    sb.append("    azioniAmministr: ").append(toIndentedString(azioniAmministr)).append("\n");
    sb.append("    denunciaAutorita: ").append(toIndentedString(denunciaAutorita)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    dataComplIntervento: ").append(toIndentedString(dataComplIntervento)).append("\n");
    sb.append("    dataCreazione: ").append(toIndentedString(dataCreazione)).append("\n");
    sb.append("    risultato: ").append(toIndentedString(risultato)).append("\n");
    sb.append("    detection: ").append(toIndentedString(detection)).append("\n");
    sb.append("    denunciaDTOs: ").append(toIndentedString(denunciaDTOs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
