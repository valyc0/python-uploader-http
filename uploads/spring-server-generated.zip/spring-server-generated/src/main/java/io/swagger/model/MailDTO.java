package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * MailDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class MailDTO   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("category")
  private String category = null;

  @JsonProperty("cc")
  private String cc = null;

  @JsonProperty("content")
  private String content = null;

  @JsonProperty("from")
  private String from = null;

  @JsonProperty("sendDate")
  private OffsetDateTime sendDate = null;

  @JsonProperty("subject")
  private String subject = null;

  @JsonProperty("to")
  private String to = null;

  @JsonProperty("carrier")
  private String carrier = null;

  @JsonProperty("contactManager")
  private String contactManager = null;

  @JsonProperty("carrierType")
  private String carrierType = null;

  public MailDTO id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public MailDTO category(String category) {
    this.category = category;
    return this;
  }

  /**
   * Get category
   * @return category
   **/
  @Schema(description = "")
  
    public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public MailDTO cc(String cc) {
    this.cc = cc;
    return this;
  }

  /**
   * Get cc
   * @return cc
   **/
  @Schema(description = "")
  
    public String getCc() {
    return cc;
  }

  public void setCc(String cc) {
    this.cc = cc;
  }

  public MailDTO content(String content) {
    this.content = content;
    return this;
  }

  /**
   * Get content
   * @return content
   **/
  @Schema(description = "")
  
    public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public MailDTO from(String from) {
    this.from = from;
    return this;
  }

  /**
   * Get from
   * @return from
   **/
  @Schema(description = "")
  
    public String getFrom() {
    return from;
  }

  public void setFrom(String from) {
    this.from = from;
  }

  public MailDTO sendDate(OffsetDateTime sendDate) {
    this.sendDate = sendDate;
    return this;
  }

  /**
   * Get sendDate
   * @return sendDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getSendDate() {
    return sendDate;
  }

  public void setSendDate(OffsetDateTime sendDate) {
    this.sendDate = sendDate;
  }

  public MailDTO subject(String subject) {
    this.subject = subject;
    return this;
  }

  /**
   * Get subject
   * @return subject
   **/
  @Schema(description = "")
  
    public String getSubject() {
    return subject;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

  public MailDTO to(String to) {
    this.to = to;
    return this;
  }

  /**
   * Get to
   * @return to
   **/
  @Schema(description = "")
  
    public String getTo() {
    return to;
  }

  public void setTo(String to) {
    this.to = to;
  }

  public MailDTO carrier(String carrier) {
    this.carrier = carrier;
    return this;
  }

  /**
   * Get carrier
   * @return carrier
   **/
  @Schema(description = "")
  
    public String getCarrier() {
    return carrier;
  }

  public void setCarrier(String carrier) {
    this.carrier = carrier;
  }

  public MailDTO contactManager(String contactManager) {
    this.contactManager = contactManager;
    return this;
  }

  /**
   * Get contactManager
   * @return contactManager
   **/
  @Schema(description = "")
  
    public String getContactManager() {
    return contactManager;
  }

  public void setContactManager(String contactManager) {
    this.contactManager = contactManager;
  }

  public MailDTO carrierType(String carrierType) {
    this.carrierType = carrierType;
    return this;
  }

  /**
   * Get carrierType
   * @return carrierType
   **/
  @Schema(description = "")
  
    public String getCarrierType() {
    return carrierType;
  }

  public void setCarrierType(String carrierType) {
    this.carrierType = carrierType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MailDTO mailDTO = (MailDTO) o;
    return Objects.equals(this.id, mailDTO.id) &&
        Objects.equals(this.category, mailDTO.category) &&
        Objects.equals(this.cc, mailDTO.cc) &&
        Objects.equals(this.content, mailDTO.content) &&
        Objects.equals(this.from, mailDTO.from) &&
        Objects.equals(this.sendDate, mailDTO.sendDate) &&
        Objects.equals(this.subject, mailDTO.subject) &&
        Objects.equals(this.to, mailDTO.to) &&
        Objects.equals(this.carrier, mailDTO.carrier) &&
        Objects.equals(this.contactManager, mailDTO.contactManager) &&
        Objects.equals(this.carrierType, mailDTO.carrierType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, category, cc, content, from, sendDate, subject, to, carrier, contactManager, carrierType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MailDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    cc: ").append(toIndentedString(cc)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    from: ").append(toIndentedString(from)).append("\n");
    sb.append("    sendDate: ").append(toIndentedString(sendDate)).append("\n");
    sb.append("    subject: ").append(toIndentedString(subject)).append("\n");
    sb.append("    to: ").append(toIndentedString(to)).append("\n");
    sb.append("    carrier: ").append(toIndentedString(carrier)).append("\n");
    sb.append("    contactManager: ").append(toIndentedString(contactManager)).append("\n");
    sb.append("    carrierType: ").append(toIndentedString(carrierType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
