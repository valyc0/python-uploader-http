package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TicketCostDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class TicketCostDTO   {
  @JsonProperty("ticketId")
  private String ticketId = null;

  @JsonProperty("oldValue")
  private BigDecimal oldValue = null;

  @JsonProperty("newValue")
  private BigDecimal newValue = null;

  public TicketCostDTO ticketId(String ticketId) {
    this.ticketId = ticketId;
    return this;
  }

  /**
   * Get ticketId
   * @return ticketId
   **/
  @Schema(description = "")
  
    public String getTicketId() {
    return ticketId;
  }

  public void setTicketId(String ticketId) {
    this.ticketId = ticketId;
  }

  public TicketCostDTO oldValue(BigDecimal oldValue) {
    this.oldValue = oldValue;
    return this;
  }

  /**
   * Get oldValue
   * @return oldValue
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getOldValue() {
    return oldValue;
  }

  public void setOldValue(BigDecimal oldValue) {
    this.oldValue = oldValue;
  }

  public TicketCostDTO newValue(BigDecimal newValue) {
    this.newValue = newValue;
    return this;
  }

  /**
   * Get newValue
   * @return newValue
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getNewValue() {
    return newValue;
  }

  public void setNewValue(BigDecimal newValue) {
    this.newValue = newValue;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TicketCostDTO ticketCostDTO = (TicketCostDTO) o;
    return Objects.equals(this.ticketId, ticketCostDTO.ticketId) &&
        Objects.equals(this.oldValue, ticketCostDTO.oldValue) &&
        Objects.equals(this.newValue, ticketCostDTO.newValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ticketId, oldValue, newValue);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TicketCostDTO {\n");
    
    sb.append("    ticketId: ").append(toIndentedString(ticketId)).append("\n");
    sb.append("    oldValue: ").append(toIndentedString(oldValue)).append("\n");
    sb.append("    newValue: ").append(toIndentedString(newValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
