package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.RifDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RIfResponseDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class RIfResponseDTO   {
  @JsonProperty("page")
  private Integer page = null;

  @JsonProperty("size")
  private Integer size = null;

  @JsonProperty("totalrecord")
  private Long totalrecord = null;

  @JsonProperty("rifDTOs")
  @Valid
  private List<RifDTO> rifDTOs = null;

  public RIfResponseDTO page(Integer page) {
    this.page = page;
    return this;
  }

  /**
   * Get page
   * @return page
   **/
  @Schema(description = "")
  
    public Integer getPage() {
    return page;
  }

  public void setPage(Integer page) {
    this.page = page;
  }

  public RIfResponseDTO size(Integer size) {
    this.size = size;
    return this;
  }

  /**
   * Get size
   * @return size
   **/
  @Schema(description = "")
  
    public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public RIfResponseDTO totalrecord(Long totalrecord) {
    this.totalrecord = totalrecord;
    return this;
  }

  /**
   * Get totalrecord
   * @return totalrecord
   **/
  @Schema(description = "")
  
    public Long getTotalrecord() {
    return totalrecord;
  }

  public void setTotalrecord(Long totalrecord) {
    this.totalrecord = totalrecord;
  }

  public RIfResponseDTO rifDTOs(List<RifDTO> rifDTOs) {
    this.rifDTOs = rifDTOs;
    return this;
  }

  public RIfResponseDTO addRifDTOsItem(RifDTO rifDTOsItem) {
    if (this.rifDTOs == null) {
      this.rifDTOs = new ArrayList<RifDTO>();
    }
    this.rifDTOs.add(rifDTOsItem);
    return this;
  }

  /**
   * Get rifDTOs
   * @return rifDTOs
   **/
  @Schema(description = "")
      @Valid
    public List<RifDTO> getRifDTOs() {
    return rifDTOs;
  }

  public void setRifDTOs(List<RifDTO> rifDTOs) {
    this.rifDTOs = rifDTOs;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RIfResponseDTO rifResponseDTO = (RIfResponseDTO) o;
    return Objects.equals(this.page, rifResponseDTO.page) &&
        Objects.equals(this.size, rifResponseDTO.size) &&
        Objects.equals(this.totalrecord, rifResponseDTO.totalrecord) &&
        Objects.equals(this.rifDTOs, rifResponseDTO.rifDTOs);
  }

  @Override
  public int hashCode() {
    return Objects.hash(page, size, totalrecord, rifDTOs);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RIfResponseDTO {\n");
    
    sb.append("    page: ").append(toIndentedString(page)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    totalrecord: ").append(toIndentedString(totalrecord)).append("\n");
    sb.append("    rifDTOs: ").append(toIndentedString(rifDTOs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
