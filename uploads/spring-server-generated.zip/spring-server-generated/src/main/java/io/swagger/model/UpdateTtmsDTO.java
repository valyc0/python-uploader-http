package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.CarrierBlockDTO;
import io.swagger.model.PhoneNumberBlockDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * UpdateTtmsDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class UpdateTtmsDTO   {
  @JsonProperty("ticketId")
  private String ticketId = null;

  @JsonProperty("operation")
  private String operation = null;

  @JsonProperty("note")
  private String note = null;

  @JsonProperty("operator")
  private String operator = null;

  @JsonProperty("blockByWorkOrderDate")
  private OffsetDateTime blockByWorkOrderDate = null;

  @JsonProperty("phoneNumberBlockDTO")
  @Valid
  private List<PhoneNumberBlockDTO> phoneNumberBlockDTO = null;

  @JsonProperty("carrierBlockDTO")
  @Valid
  private List<CarrierBlockDTO> carrierBlockDTO = null;

  public UpdateTtmsDTO ticketId(String ticketId) {
    this.ticketId = ticketId;
    return this;
  }

  /**
   * Get ticketId
   * @return ticketId
   **/
  @Schema(description = "")
  
    public String getTicketId() {
    return ticketId;
  }

  public void setTicketId(String ticketId) {
    this.ticketId = ticketId;
  }

  public UpdateTtmsDTO operation(String operation) {
    this.operation = operation;
    return this;
  }

  /**
   * Get operation
   * @return operation
   **/
  @Schema(description = "")
  
    public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }

  public UpdateTtmsDTO note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
   **/
  @Schema(description = "")
  
    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public UpdateTtmsDTO operator(String operator) {
    this.operator = operator;
    return this;
  }

  /**
   * Get operator
   * @return operator
   **/
  @Schema(description = "")
  
    public String getOperator() {
    return operator;
  }

  public void setOperator(String operator) {
    this.operator = operator;
  }

  public UpdateTtmsDTO blockByWorkOrderDate(OffsetDateTime blockByWorkOrderDate) {
    this.blockByWorkOrderDate = blockByWorkOrderDate;
    return this;
  }

  /**
   * Get blockByWorkOrderDate
   * @return blockByWorkOrderDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getBlockByWorkOrderDate() {
    return blockByWorkOrderDate;
  }

  public void setBlockByWorkOrderDate(OffsetDateTime blockByWorkOrderDate) {
    this.blockByWorkOrderDate = blockByWorkOrderDate;
  }

  public UpdateTtmsDTO phoneNumberBlockDTO(List<PhoneNumberBlockDTO> phoneNumberBlockDTO) {
    this.phoneNumberBlockDTO = phoneNumberBlockDTO;
    return this;
  }

  public UpdateTtmsDTO addPhoneNumberBlockDTOItem(PhoneNumberBlockDTO phoneNumberBlockDTOItem) {
    if (this.phoneNumberBlockDTO == null) {
      this.phoneNumberBlockDTO = new ArrayList<PhoneNumberBlockDTO>();
    }
    this.phoneNumberBlockDTO.add(phoneNumberBlockDTOItem);
    return this;
  }

  /**
   * Get phoneNumberBlockDTO
   * @return phoneNumberBlockDTO
   **/
  @Schema(description = "")
      @Valid
    public List<PhoneNumberBlockDTO> getPhoneNumberBlockDTO() {
    return phoneNumberBlockDTO;
  }

  public void setPhoneNumberBlockDTO(List<PhoneNumberBlockDTO> phoneNumberBlockDTO) {
    this.phoneNumberBlockDTO = phoneNumberBlockDTO;
  }

  public UpdateTtmsDTO carrierBlockDTO(List<CarrierBlockDTO> carrierBlockDTO) {
    this.carrierBlockDTO = carrierBlockDTO;
    return this;
  }

  public UpdateTtmsDTO addCarrierBlockDTOItem(CarrierBlockDTO carrierBlockDTOItem) {
    if (this.carrierBlockDTO == null) {
      this.carrierBlockDTO = new ArrayList<CarrierBlockDTO>();
    }
    this.carrierBlockDTO.add(carrierBlockDTOItem);
    return this;
  }

  /**
   * Get carrierBlockDTO
   * @return carrierBlockDTO
   **/
  @Schema(description = "")
      @Valid
    public List<CarrierBlockDTO> getCarrierBlockDTO() {
    return carrierBlockDTO;
  }

  public void setCarrierBlockDTO(List<CarrierBlockDTO> carrierBlockDTO) {
    this.carrierBlockDTO = carrierBlockDTO;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UpdateTtmsDTO updateTtmsDTO = (UpdateTtmsDTO) o;
    return Objects.equals(this.ticketId, updateTtmsDTO.ticketId) &&
        Objects.equals(this.operation, updateTtmsDTO.operation) &&
        Objects.equals(this.note, updateTtmsDTO.note) &&
        Objects.equals(this.operator, updateTtmsDTO.operator) &&
        Objects.equals(this.blockByWorkOrderDate, updateTtmsDTO.blockByWorkOrderDate) &&
        Objects.equals(this.phoneNumberBlockDTO, updateTtmsDTO.phoneNumberBlockDTO) &&
        Objects.equals(this.carrierBlockDTO, updateTtmsDTO.carrierBlockDTO);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ticketId, operation, note, operator, blockByWorkOrderDate, phoneNumberBlockDTO, carrierBlockDTO);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UpdateTtmsDTO {\n");
    
    sb.append("    ticketId: ").append(toIndentedString(ticketId)).append("\n");
    sb.append("    operation: ").append(toIndentedString(operation)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    operator: ").append(toIndentedString(operator)).append("\n");
    sb.append("    blockByWorkOrderDate: ").append(toIndentedString(blockByWorkOrderDate)).append("\n");
    sb.append("    phoneNumberBlockDTO: ").append(toIndentedString(phoneNumberBlockDTO)).append("\n");
    sb.append("    carrierBlockDTO: ").append(toIndentedString(carrierBlockDTO)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
