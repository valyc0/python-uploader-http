package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * FmwsSubRif
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class FmwsSubRif   {
  @JsonProperty("subrifId")
  private String subrifId = null;

  @JsonProperty("rifId")
  private String rifId = null;

  @JsonProperty("sequenceNumber")
  private Long sequenceNumber = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("istrout")
  private String istrout = null;

  @JsonProperty("creationDate")
  private OffsetDateTime creationDate = null;

  @JsonProperty("istrinDesc")
  private String istrinDesc = null;

  @JsonProperty("istroutDesc")
  private String istroutDesc = null;

  @JsonProperty("lastModifiedDate")
  private OffsetDateTime lastModifiedDate = null;

  public FmwsSubRif subrifId(String subrifId) {
    this.subrifId = subrifId;
    return this;
  }

  /**
   * Get subrifId
   * @return subrifId
   **/
  @Schema(description = "")
  
    public String getSubrifId() {
    return subrifId;
  }

  public void setSubrifId(String subrifId) {
    this.subrifId = subrifId;
  }

  public FmwsSubRif rifId(String rifId) {
    this.rifId = rifId;
    return this;
  }

  /**
   * Get rifId
   * @return rifId
   **/
  @Schema(description = "")
  
    public String getRifId() {
    return rifId;
  }

  public void setRifId(String rifId) {
    this.rifId = rifId;
  }

  public FmwsSubRif sequenceNumber(Long sequenceNumber) {
    this.sequenceNumber = sequenceNumber;
    return this;
  }

  /**
   * Get sequenceNumber
   * @return sequenceNumber
   **/
  @Schema(description = "")
  
    public Long getSequenceNumber() {
    return sequenceNumber;
  }

  public void setSequenceNumber(Long sequenceNumber) {
    this.sequenceNumber = sequenceNumber;
  }

  public FmwsSubRif sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public FmwsSubRif istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public FmwsSubRif istrout(String istrout) {
    this.istrout = istrout;
    return this;
  }

  /**
   * Get istrout
   * @return istrout
   **/
  @Schema(description = "")
  
    public String getIstrout() {
    return istrout;
  }

  public void setIstrout(String istrout) {
    this.istrout = istrout;
  }

  public FmwsSubRif creationDate(OffsetDateTime creationDate) {
    this.creationDate = creationDate;
    return this;
  }

  /**
   * Get creationDate
   * @return creationDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(OffsetDateTime creationDate) {
    this.creationDate = creationDate;
  }

  public FmwsSubRif istrinDesc(String istrinDesc) {
    this.istrinDesc = istrinDesc;
    return this;
  }

  /**
   * Get istrinDesc
   * @return istrinDesc
   **/
  @Schema(description = "")
  
    public String getIstrinDesc() {
    return istrinDesc;
  }

  public void setIstrinDesc(String istrinDesc) {
    this.istrinDesc = istrinDesc;
  }

  public FmwsSubRif istroutDesc(String istroutDesc) {
    this.istroutDesc = istroutDesc;
    return this;
  }

  /**
   * Get istroutDesc
   * @return istroutDesc
   **/
  @Schema(description = "")
  
    public String getIstroutDesc() {
    return istroutDesc;
  }

  public void setIstroutDesc(String istroutDesc) {
    this.istroutDesc = istroutDesc;
  }

  public FmwsSubRif lastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FmwsSubRif fmwsSubRif = (FmwsSubRif) o;
    return Objects.equals(this.subrifId, fmwsSubRif.subrifId) &&
        Objects.equals(this.rifId, fmwsSubRif.rifId) &&
        Objects.equals(this.sequenceNumber, fmwsSubRif.sequenceNumber) &&
        Objects.equals(this.sellingDestination, fmwsSubRif.sellingDestination) &&
        Objects.equals(this.istrin, fmwsSubRif.istrin) &&
        Objects.equals(this.istrout, fmwsSubRif.istrout) &&
        Objects.equals(this.creationDate, fmwsSubRif.creationDate) &&
        Objects.equals(this.istrinDesc, fmwsSubRif.istrinDesc) &&
        Objects.equals(this.istroutDesc, fmwsSubRif.istroutDesc) &&
        Objects.equals(this.lastModifiedDate, fmwsSubRif.lastModifiedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subrifId, rifId, sequenceNumber, sellingDestination, istrin, istrout, creationDate, istrinDesc, istroutDesc, lastModifiedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FmwsSubRif {\n");
    
    sb.append("    subrifId: ").append(toIndentedString(subrifId)).append("\n");
    sb.append("    rifId: ").append(toIndentedString(rifId)).append("\n");
    sb.append("    sequenceNumber: ").append(toIndentedString(sequenceNumber)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    istrout: ").append(toIndentedString(istrout)).append("\n");
    sb.append("    creationDate: ").append(toIndentedString(creationDate)).append("\n");
    sb.append("    istrinDesc: ").append(toIndentedString(istrinDesc)).append("\n");
    sb.append("    istroutDesc: ").append(toIndentedString(istroutDesc)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
