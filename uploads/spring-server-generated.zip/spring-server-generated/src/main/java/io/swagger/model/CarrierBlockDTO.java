package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CarrierBlockDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class CarrierBlockDTO   {
  @JsonProperty("codiceCarrCommer")
  private String codiceCarrCommer = null;

  @JsonProperty("ragioneSocCommer")
  private String ragioneSocCommer = null;

  public CarrierBlockDTO codiceCarrCommer(String codiceCarrCommer) {
    this.codiceCarrCommer = codiceCarrCommer;
    return this;
  }

  /**
   * Get codiceCarrCommer
   * @return codiceCarrCommer
   **/
  @Schema(description = "")
  
    public String getCodiceCarrCommer() {
    return codiceCarrCommer;
  }

  public void setCodiceCarrCommer(String codiceCarrCommer) {
    this.codiceCarrCommer = codiceCarrCommer;
  }

  public CarrierBlockDTO ragioneSocCommer(String ragioneSocCommer) {
    this.ragioneSocCommer = ragioneSocCommer;
    return this;
  }

  /**
   * Get ragioneSocCommer
   * @return ragioneSocCommer
   **/
  @Schema(description = "")
  
    public String getRagioneSocCommer() {
    return ragioneSocCommer;
  }

  public void setRagioneSocCommer(String ragioneSocCommer) {
    this.ragioneSocCommer = ragioneSocCommer;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CarrierBlockDTO carrierBlockDTO = (CarrierBlockDTO) o;
    return Objects.equals(this.codiceCarrCommer, carrierBlockDTO.codiceCarrCommer) &&
        Objects.equals(this.ragioneSocCommer, carrierBlockDTO.ragioneSocCommer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(codiceCarrCommer, ragioneSocCommer);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CarrierBlockDTO {\n");
    
    sb.append("    codiceCarrCommer: ").append(toIndentedString(codiceCarrCommer)).append("\n");
    sb.append("    ragioneSocCommer: ").append(toIndentedString(ragioneSocCommer)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
