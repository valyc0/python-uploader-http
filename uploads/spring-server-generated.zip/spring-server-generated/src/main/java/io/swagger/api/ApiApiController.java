package io.swagger.api;

import io.swagger.model.ArchiveDTO;
import io.swagger.model.CarrierContactDTO;
import io.swagger.model.ComboDTO;
import io.swagger.model.DenunciaDTO;
import io.swagger.model.DisputeCdrFileResponseDTO;
import io.swagger.model.DisputeSubrifAddDTO;
import io.swagger.model.DisputeSubrifDTO;
import io.swagger.model.DisputeSubrifSearchDTO;
import io.swagger.model.DisputeUploadCdrFileBody;
import io.swagger.model.EconomicBlockDTO;
import io.swagger.model.EventiAzioniResponseDTO;
import io.swagger.model.HistoryResponseDTO;
import io.swagger.model.HistorySearchDTO;
import io.swagger.model.RIfResponseDTO;
import io.swagger.model.ReportSearchDTO;
import org.springframework.core.io.Resource;
import io.swagger.model.RifAlarmDTO;
import io.swagger.model.RifDTO;
import io.swagger.model.SellingDestinationDTO;
import io.swagger.model.TicketCostDTO;
import io.swagger.model.TicketResponseDTO;
import io.swagger.model.TicketSearchDTO;
import io.swagger.model.TtHistoryDTO;
import io.swagger.model.UpdateTtmsDTO;
import io.swagger.model.UploadattachRifBody;
import io.swagger.model.UploadattachTicketIdBody;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")
@RestController
public class ApiApiController implements ApiApi {

    private static final Logger log = LoggerFactory.getLogger(ApiApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public ApiApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<DenunciaDTO> addDenuncia(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody DenunciaDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<DenunciaDTO>(objectMapper.readValue("{\n  \"result\" : \"result\",\n  \"note\" : \"note\",\n  \"titolo\" : \"titolo\",\n  \"minuti\" : 2.3021358869347655,\n  \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"subRif\" : \"subRif\",\n  \"id\" : \"id\",\n  \"valorizzazione\" : 7.061401241503109,\n  \"rifId\" : \"rifId\"\n}", DenunciaDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<DenunciaDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<DenunciaDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> changeCost(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TicketCostDTO body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> checkCdrFile(@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "owner", required = true) String owner,@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "istrin", required = true) String istrin,@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "filename", required = true) String filename,@Parameter(in = ParameterIn.QUERY, description = "" ,schema=@Schema()) @Valid @RequestParam(value = "disputeName", required = false) String disputeName) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> clearCache(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("namecache") String namecache) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> closeAlarm(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("month") String month,@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("year") String year) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> createCia(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("dateStr") String dateStr) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<EconomicBlockDTO> createEconomicBlock(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody EconomicBlockDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<EconomicBlockDTO>(objectMapper.readValue("{\n  \"areaOut\" : \"areaOut\",\n  \"deb\" : 9.301444243932576,\n  \"note\" : \"note\",\n  \"currencyDefaultDebit\" : \"currencyDefaultDebit\",\n  \"blockDebitDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"year\" : \"year\",\n  \"lastUpdateDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"creUnblockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"currencyDefaultCredit\" : \"currencyDefaultCredit\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"flagBlockCredit\" : true,\n  \"subrifId\" : \"subrifId\",\n  \"id\" : 0,\n  \"disputaDebitStatus\" : \"disputaDebitStatus\",\n  \"entityIn\" : \"entityIn\",\n  \"flagBlockDebit\" : true,\n  \"createDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"debEur\" : 1.4658129805029452,\n  \"cred\" : 7.061401241503109,\n  \"blockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"flagCIA\" : true,\n  \"debUsd\" : 5.962133916683182,\n  \"blockCreditDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istrout\" : \"istrout\",\n  \"areaIn\" : \"areaIn\",\n  \"creEur\" : 5.637376656633329,\n  \"debUnblockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"minute\" : 6.027456183070403,\n  \"entityOut\" : \"entityOut\",\n  \"disputaCreditStatus\" : \"disputaCreditStatus\",\n  \"month\" : \"month\",\n  \"creUsd\" : 2.3021358869347655,\n  \"disputeId\" : \"disputeId\",\n  \"economicType\" : \"economicType\",\n  \"trafficEndDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"disputaIdCredit\" : \"disputaIdCredit\",\n  \"reportingDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istrin\" : \"istrin\",\n  \"trafficStartDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"rifId\" : \"rifId\",\n  \"status\" : \"status\",\n  \"flagDenuncia\" : true\n}", EconomicBlockDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<EconomicBlockDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<EconomicBlockDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> createOdv(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("dateStr") String dateStr) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<RifDTO> createReport(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody RifDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<RifDTO>(objectMapper.readValue("{\n  \"note\" : \"note\",\n  \"istrin_id\" : \"istrin_id\",\n  \"detection\" : \"detection\",\n  \"minuti\" : 5.962133916683182,\n  \"risultanzeAnalisi\" : \"risultanzeAnalisi\",\n  \"dataCreazione\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istrout\" : \"istrout\",\n  \"azioniAmministr\" : \"azioniAmministr\",\n  \"dataComplIntervento\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"fonte\" : \"fonte\",\n  \"istrout_id\" : \"istrout_id\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"risultato\" : \"risultato\",\n  \"denunciaDTOs\" : [ {\n    \"result\" : \"result\",\n    \"note\" : \"note\",\n    \"titolo\" : \"titolo\",\n    \"minuti\" : 2.3021358869347655,\n    \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"subRif\" : \"subRif\",\n    \"id\" : \"id\",\n    \"valorizzazione\" : 7.061401241503109,\n    \"rifId\" : \"rifId\"\n  }, {\n    \"result\" : \"result\",\n    \"note\" : \"note\",\n    \"titolo\" : \"titolo\",\n    \"minuti\" : 2.3021358869347655,\n    \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"subRif\" : \"subRif\",\n    \"id\" : \"id\",\n    \"valorizzazione\" : 7.061401241503109,\n    \"rifId\" : \"rifId\"\n  } ],\n  \"manual\" : true,\n  \"valorizzazione\" : 5.637376656633329,\n  \"rif\" : \"rif\",\n  \"dataRilevamento\" : \"dataRilevamento\",\n  \"istrin\" : \"istrin\",\n  \"id\" : \"id\",\n  \"denunciaAutorita\" : \"denunciaAutorita\"\n}", RifDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<RifDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<RifDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> deleteCdrFile(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("fileId") Long fileId) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> deleteDenuncia(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("id") String id) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> deleteEconomicBlock(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("economicBlockId") Long economicBlockId) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> deleteReport(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody RifDTO body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadAttach(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("id") Long id) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadAttach1(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("id") Long id) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadCia(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody ReportSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadCia1(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody ReportSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadEventi(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TicketSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadEventiLight(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TicketSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadOdv(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody ReportSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Resource> downloadOdv1(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody ReportSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Resource>(objectMapper.readValue("\"\"", Resource.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Resource>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Resource>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TicketResponseDTO> findTicket(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("ticketId") String ticketId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TicketResponseDTO>(objectMapper.readValue("{\n  \"carrierInfoInDTOs\" : [ {\n    \"id\" : \"id\",\n    \"desc\" : \"desc\"\n  }, {\n    \"id\" : \"id\",\n    \"desc\" : \"desc\"\n  } ],\n  \"ticket\" : {\n    \"notes\" : \"notes\",\n    \"marketingRequestDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"creatorGroup\" : \"creatorGroup\",\n    \"dtblockByWorkOrder\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"endDateOccurs\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"reasonForClosure\" : \"reasonForClosure\",\n    \"reportedByCategory\" : \"reportedByCategory\",\n    \"reportedBySubcategory\" : \"reportedBySubcategory\",\n    \"routingDestination\" : \"routingDestination\",\n    \"reopenTrafficDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"sellingDestination\" : \"sellingDestination\",\n    \"nmNumberingRange\" : \"nmNumberingRange\",\n    \"blkWorkOrderNumber2\" : \"blkWorkOrderNumber2\",\n    \"blkWorkOrderNumber3\" : \"blkWorkOrderNumber3\",\n    \"statusReason\" : \"statusReason\",\n    \"nmBlockType\" : \"nmBlockType\",\n    \"id\" : \"id\",\n    \"verificationAction\" : \"verificationAction\",\n    \"createDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"carrierBlock\" : \"carrierBlock\",\n    \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"ownerGroup\" : \"ownerGroup\",\n    \"blkWorkOrderNumber\" : \"blkWorkOrderNumber\",\n    \"nmBlockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"holdMkvnResponse\" : \"holdMkvnResponse\",\n    \"creatorUser\" : \"creatorUser\",\n    \"sourceType\" : \"sourceType\",\n    \"totalMinutes\" : 5,\n    \"marketingRequestType\" : \"marketingRequestType\",\n    \"ticketClosureDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"reportedDatetime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"phoneNumberBlock\" : \"phoneNumberBlock\",\n    \"status\" : \"status\"\n  },\n  \"azioni\" : [ {\n    \"azione\" : \"azione\"\n  }, {\n    \"azione\" : \"azione\"\n  } ],\n  \"carrierInfoOutDTOs\" : [ null, null ],\n  \"referenceDTOs\" : [ {\n    \"alarmReferenceType\" : \"alarmReferenceType\",\n    \"alarmReferenceValue\" : \"alarmReferenceValue\"\n  }, {\n    \"alarmReferenceType\" : \"alarmReferenceType\",\n    \"alarmReferenceValue\" : \"alarmReferenceValue\"\n  } ]\n}", TicketResponseDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TicketResponseDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TicketResponseDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> generaRif(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("ticketId") String ticketId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<CarrierContactDTO>> getCarrierContacts() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<CarrierContactDTO>>(objectMapper.readValue("[ {\n  \"acronym\" : \"acronym\",\n  \"name\" : \"name\",\n  \"listContact231\" : \"listContact231\",\n  \"listContactCm\" : \"listContactCm\"\n}, {\n  \"acronym\" : \"acronym\",\n  \"name\" : \"name\",\n  \"listContact231\" : \"listContact231\",\n  \"listContactCm\" : \"listContactCm\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<CarrierContactDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<CarrierContactDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> getFonte() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<TtHistoryDTO>> getHistory(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("ticketId") String ticketId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<TtHistoryDTO>>(objectMapper.readValue("[ {\n  \"operationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"notes\" : \"notes\",\n  \"statusReason\" : \"statusReason\",\n  \"assigneeGroup\" : \"assigneeGroup\",\n  \"payload\" : \"payload\",\n  \"ttmsOperation\" : \"ttmsOperation\",\n  \"operatorUser\" : \"operatorUser\",\n  \"id\" : 0,\n  \"source\" : \"source\",\n  \"ticketId\" : \"ticketId\",\n  \"status\" : \"status\"\n}, {\n  \"operationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"notes\" : \"notes\",\n  \"statusReason\" : \"statusReason\",\n  \"assigneeGroup\" : \"assigneeGroup\",\n  \"payload\" : \"payload\",\n  \"ttmsOperation\" : \"ttmsOperation\",\n  \"operatorUser\" : \"operatorUser\",\n  \"id\" : 0,\n  \"source\" : \"source\",\n  \"ticketId\" : \"ticketId\",\n  \"status\" : \"status\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<TtHistoryDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<TtHistoryDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> getReasonCode() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<SellingDestinationDTO>> getSellingDest() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<SellingDestinationDTO>>(objectMapper.readValue("[ {\n  \"descr\" : \"descr\",\n  \"country\" : \"country\",\n  \"id\" : \"id\"\n}, {\n  \"descr\" : \"descr\",\n  \"country\" : \"country\",\n  \"id\" : \"id\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<SellingDestinationDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<SellingDestinationDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> getStato() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> getTickets() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> listaAnno() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ArchiveDTO>> listaAttach(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("ticketId") String ticketId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ArchiveDTO>>(objectMapper.readValue("[ {\n  \"utente\" : \"utente\",\n  \"tipo\" : \"tipo\",\n  \"filename\" : \"filename\",\n  \"size\" : \"size\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"id\" : 0,\n  \"troubleTicket\" : \"troubleTicket\",\n  \"contentType\" : \"contentType\",\n  \"nota\" : \"nota\",\n  \"rif\" : \"rif\",\n  \"mailDTO\" : {\n    \"cc\" : \"cc\",\n    \"carrier\" : \"carrier\",\n    \"contactManager\" : \"contactManager\",\n    \"sendDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"subject\" : \"subject\",\n    \"carrierType\" : \"carrierType\",\n    \"from\" : \"from\",\n    \"id\" : \"id\",\n    \"to\" : \"to\",\n    \"category\" : \"category\",\n    \"content\" : \"content\"\n  }\n}, {\n  \"utente\" : \"utente\",\n  \"tipo\" : \"tipo\",\n  \"filename\" : \"filename\",\n  \"size\" : \"size\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"id\" : 0,\n  \"troubleTicket\" : \"troubleTicket\",\n  \"contentType\" : \"contentType\",\n  \"nota\" : \"nota\",\n  \"rif\" : \"rif\",\n  \"mailDTO\" : {\n    \"cc\" : \"cc\",\n    \"carrier\" : \"carrier\",\n    \"contactManager\" : \"contactManager\",\n    \"sendDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"subject\" : \"subject\",\n    \"carrierType\" : \"carrierType\",\n    \"from\" : \"from\",\n    \"id\" : \"id\",\n    \"to\" : \"to\",\n    \"category\" : \"category\",\n    \"content\" : \"content\"\n  }\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ArchiveDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ArchiveDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ArchiveDTO>> listaAttach1(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("subRifId") String subRifId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ArchiveDTO>>(objectMapper.readValue("[ {\n  \"utente\" : \"utente\",\n  \"tipo\" : \"tipo\",\n  \"filename\" : \"filename\",\n  \"size\" : \"size\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"id\" : 0,\n  \"troubleTicket\" : \"troubleTicket\",\n  \"contentType\" : \"contentType\",\n  \"nota\" : \"nota\",\n  \"rif\" : \"rif\",\n  \"mailDTO\" : {\n    \"cc\" : \"cc\",\n    \"carrier\" : \"carrier\",\n    \"contactManager\" : \"contactManager\",\n    \"sendDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"subject\" : \"subject\",\n    \"carrierType\" : \"carrierType\",\n    \"from\" : \"from\",\n    \"id\" : \"id\",\n    \"to\" : \"to\",\n    \"category\" : \"category\",\n    \"content\" : \"content\"\n  }\n}, {\n  \"utente\" : \"utente\",\n  \"tipo\" : \"tipo\",\n  \"filename\" : \"filename\",\n  \"size\" : \"size\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"id\" : 0,\n  \"troubleTicket\" : \"troubleTicket\",\n  \"contentType\" : \"contentType\",\n  \"nota\" : \"nota\",\n  \"rif\" : \"rif\",\n  \"mailDTO\" : {\n    \"cc\" : \"cc\",\n    \"carrier\" : \"carrier\",\n    \"contactManager\" : \"contactManager\",\n    \"sendDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"subject\" : \"subject\",\n    \"carrierType\" : \"carrierType\",\n    \"from\" : \"from\",\n    \"id\" : \"id\",\n    \"to\" : \"to\",\n    \"category\" : \"category\",\n    \"content\" : \"content\"\n  }\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ArchiveDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ArchiveDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> listaDataTraffico() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> listaMese() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> listaRif() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> modifyAlarmRIf(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("rifId") String rifId,@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody RifAlarmDTO body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> modifyDenuncia(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody DenunciaDTO body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> modifyReport(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody RifDTO body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> removeAttach(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("id") Long id) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> removeAttach1(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("id") Long id) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> ricalcolaCosti(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TicketSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<ComboDTO>> risultanzeAnalisi() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<ComboDTO>>(objectMapper.readValue("[ {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n}, {\n  \"id\" : \"id\",\n  \"desc\" : \"desc\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<ComboDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<ComboDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<EventiAzioniResponseDTO> search(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TicketSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<EventiAzioniResponseDTO>(objectMapper.readValue("{\n  \"totalrecord\" : 1,\n  \"size\" : 6,\n  \"eventiAzioni\" : [ {\n    \"dataTraffico\" : \"dataTraffico\",\n    \"minuti\" : \"minuti\",\n    \"ticket\" : {\n      \"notes\" : \"notes\",\n      \"marketingRequestDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"creatorGroup\" : \"creatorGroup\",\n      \"dtblockByWorkOrder\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"endDateOccurs\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"reasonForClosure\" : \"reasonForClosure\",\n      \"reportedByCategory\" : \"reportedByCategory\",\n      \"reportedBySubcategory\" : \"reportedBySubcategory\",\n      \"routingDestination\" : \"routingDestination\",\n      \"reopenTrafficDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"sellingDestination\" : \"sellingDestination\",\n      \"nmNumberingRange\" : \"nmNumberingRange\",\n      \"blkWorkOrderNumber2\" : \"blkWorkOrderNumber2\",\n      \"blkWorkOrderNumber3\" : \"blkWorkOrderNumber3\",\n      \"statusReason\" : \"statusReason\",\n      \"nmBlockType\" : \"nmBlockType\",\n      \"id\" : \"id\",\n      \"verificationAction\" : \"verificationAction\",\n      \"createDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"carrierBlock\" : \"carrierBlock\",\n      \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"ownerGroup\" : \"ownerGroup\",\n      \"blkWorkOrderNumber\" : \"blkWorkOrderNumber\",\n      \"nmBlockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"holdMkvnResponse\" : \"holdMkvnResponse\",\n      \"creatorUser\" : \"creatorUser\",\n      \"sourceType\" : \"sourceType\",\n      \"totalMinutes\" : 5,\n      \"marketingRequestType\" : \"marketingRequestType\",\n      \"ticketClosureDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"reportedDatetime\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"phoneNumberBlock\" : \"phoneNumberBlock\",\n      \"status\" : \"status\"\n    },\n    \"rifNumerico\" : \"rifNumerico\",\n    \"istrout\" : \"istrout\",\n    \"richiestaBarraggio\" : \"richiestaBarraggio\",\n    \"fonte\" : \"fonte\",\n    \"destination\" : \"destination\",\n    \"rifCompleto\" : \"rifCompleto\",\n    \"eventi\" : [ {\n      \"asr\" : \"asr\",\n      \"data\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"retroDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"routingDestination\" : \"routingDestination\",\n      \"retroMinutes\" : \"retroMinutes\",\n      \"sellingDestination\" : \"sellingDestination\",\n      \"troubleTicketBlock\" : \"troubleTicketBlock\",\n      \"aloc\" : \"aloc\",\n      \"countryCode\" : \"countryCode\",\n      \"id\" : 5,\n      \"seized\" : \"seized\",\n      \"calledNumber\" : \"calledNumber\",\n      \"firstDetection\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"cost\" : \"cost\",\n      \"answered\" : \"answered\",\n      \"carrierOut\" : [ null, null ],\n      \"minutes\" : \"minutes\",\n      \"verified\" : \"verified\",\n      \"troubleTicketReopen\" : \"troubleTicketReopen\",\n      \"carrierIn\" : [ {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      }, {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      } ],\n      \"blockedAgain\" : \"blockedAgain\",\n      \"routeClass\" : \"routeClass\",\n      \"replyDelay\" : \"replyDelay\",\n      \"clis\" : \"clis\",\n      \"totalCost\" : \"totalCost\"\n    }, {\n      \"asr\" : \"asr\",\n      \"data\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"retroDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"routingDestination\" : \"routingDestination\",\n      \"retroMinutes\" : \"retroMinutes\",\n      \"sellingDestination\" : \"sellingDestination\",\n      \"troubleTicketBlock\" : \"troubleTicketBlock\",\n      \"aloc\" : \"aloc\",\n      \"countryCode\" : \"countryCode\",\n      \"id\" : 5,\n      \"seized\" : \"seized\",\n      \"calledNumber\" : \"calledNumber\",\n      \"firstDetection\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"cost\" : \"cost\",\n      \"answered\" : \"answered\",\n      \"carrierOut\" : [ null, null ],\n      \"minutes\" : \"minutes\",\n      \"verified\" : \"verified\",\n      \"troubleTicketReopen\" : \"troubleTicketReopen\",\n      \"carrierIn\" : [ {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      }, {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      } ],\n      \"blockedAgain\" : \"blockedAgain\",\n      \"routeClass\" : \"routeClass\",\n      \"replyDelay\" : \"replyDelay\",\n      \"clis\" : \"clis\",\n      \"totalCost\" : \"totalCost\"\n    } ],\n    \"troubleTicket\" : \"troubleTicket\",\n    \"costoMin\" : \"costoMin\",\n    \"valorizzazione\" : \"valorizzazione\",\n    \"richiestaBarraggioCompact\" : \"richiestaBarraggioCompact\",\n    \"costoDanger\" : true,\n    \"azioni\" : [ {\n      \"azione\" : \"azione\"\n    }, {\n      \"azione\" : \"azione\"\n    } ],\n    \"troubleTicketSenzaZeri\" : \"troubleTicketSenzaZeri\",\n    \"rifSequence\" : \"rifSequence\",\n    \"testAttivitaDetectionNoc\" : \"testAttivitaDetectionNoc\",\n    \"mese\" : \"mese\",\n    \"istrin\" : \"istrin\",\n    \"costoManual\" : true,\n    \"percentInstradamento\" : \"percentInstradamento\"\n  }, {\n    \"dataTraffico\" : \"dataTraffico\",\n    \"minuti\" : \"minuti\",\n    \"ticket\" : {\n      \"notes\" : \"notes\",\n      \"marketingRequestDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"creatorGroup\" : \"creatorGroup\",\n      \"dtblockByWorkOrder\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"endDateOccurs\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"reasonForClosure\" : \"reasonForClosure\",\n      \"reportedByCategory\" : \"reportedByCategory\",\n      \"reportedBySubcategory\" : \"reportedBySubcategory\",\n      \"routingDestination\" : \"routingDestination\",\n      \"reopenTrafficDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"sellingDestination\" : \"sellingDestination\",\n      \"nmNumberingRange\" : \"nmNumberingRange\",\n      \"blkWorkOrderNumber2\" : \"blkWorkOrderNumber2\",\n      \"blkWorkOrderNumber3\" : \"blkWorkOrderNumber3\",\n      \"statusReason\" : \"statusReason\",\n      \"nmBlockType\" : \"nmBlockType\",\n      \"id\" : \"id\",\n      \"verificationAction\" : \"verificationAction\",\n      \"createDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"carrierBlock\" : \"carrierBlock\",\n      \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"ownerGroup\" : \"ownerGroup\",\n      \"blkWorkOrderNumber\" : \"blkWorkOrderNumber\",\n      \"nmBlockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"holdMkvnResponse\" : \"holdMkvnResponse\",\n      \"creatorUser\" : \"creatorUser\",\n      \"sourceType\" : \"sourceType\",\n      \"totalMinutes\" : 5,\n      \"marketingRequestType\" : \"marketingRequestType\",\n      \"ticketClosureDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"reportedDatetime\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"phoneNumberBlock\" : \"phoneNumberBlock\",\n      \"status\" : \"status\"\n    },\n    \"rifNumerico\" : \"rifNumerico\",\n    \"istrout\" : \"istrout\",\n    \"richiestaBarraggio\" : \"richiestaBarraggio\",\n    \"fonte\" : \"fonte\",\n    \"destination\" : \"destination\",\n    \"rifCompleto\" : \"rifCompleto\",\n    \"eventi\" : [ {\n      \"asr\" : \"asr\",\n      \"data\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"retroDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"routingDestination\" : \"routingDestination\",\n      \"retroMinutes\" : \"retroMinutes\",\n      \"sellingDestination\" : \"sellingDestination\",\n      \"troubleTicketBlock\" : \"troubleTicketBlock\",\n      \"aloc\" : \"aloc\",\n      \"countryCode\" : \"countryCode\",\n      \"id\" : 5,\n      \"seized\" : \"seized\",\n      \"calledNumber\" : \"calledNumber\",\n      \"firstDetection\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"cost\" : \"cost\",\n      \"answered\" : \"answered\",\n      \"carrierOut\" : [ null, null ],\n      \"minutes\" : \"minutes\",\n      \"verified\" : \"verified\",\n      \"troubleTicketReopen\" : \"troubleTicketReopen\",\n      \"carrierIn\" : [ {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      }, {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      } ],\n      \"blockedAgain\" : \"blockedAgain\",\n      \"routeClass\" : \"routeClass\",\n      \"replyDelay\" : \"replyDelay\",\n      \"clis\" : \"clis\",\n      \"totalCost\" : \"totalCost\"\n    }, {\n      \"asr\" : \"asr\",\n      \"data\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"retroDate\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"routingDestination\" : \"routingDestination\",\n      \"retroMinutes\" : \"retroMinutes\",\n      \"sellingDestination\" : \"sellingDestination\",\n      \"troubleTicketBlock\" : \"troubleTicketBlock\",\n      \"aloc\" : \"aloc\",\n      \"countryCode\" : \"countryCode\",\n      \"id\" : 5,\n      \"seized\" : \"seized\",\n      \"calledNumber\" : \"calledNumber\",\n      \"firstDetection\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"cost\" : \"cost\",\n      \"answered\" : \"answered\",\n      \"carrierOut\" : [ null, null ],\n      \"minutes\" : \"minutes\",\n      \"verified\" : \"verified\",\n      \"troubleTicketReopen\" : \"troubleTicketReopen\",\n      \"carrierIn\" : [ {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      }, {\n        \"percentuale\" : \"percentuale\",\n        \"acronym\" : \"acronym\",\n        \"roundMinutes\" : \"roundMinutes\",\n        \"countryCode\" : \"countryCode\",\n        \"minutes\" : 9.301444243932576,\n        \"name\" : \"name\",\n        \"listContact231\" : \"listContact231\",\n        \"id\" : 2,\n        \"listContactCm\" : \"listContactCm\",\n        \"type\" : \"inbound\",\n        \"attempts\" : 7\n      } ],\n      \"blockedAgain\" : \"blockedAgain\",\n      \"routeClass\" : \"routeClass\",\n      \"replyDelay\" : \"replyDelay\",\n      \"clis\" : \"clis\",\n      \"totalCost\" : \"totalCost\"\n    } ],\n    \"troubleTicket\" : \"troubleTicket\",\n    \"costoMin\" : \"costoMin\",\n    \"valorizzazione\" : \"valorizzazione\",\n    \"richiestaBarraggioCompact\" : \"richiestaBarraggioCompact\",\n    \"costoDanger\" : true,\n    \"azioni\" : [ {\n      \"azione\" : \"azione\"\n    }, {\n      \"azione\" : \"azione\"\n    } ],\n    \"troubleTicketSenzaZeri\" : \"troubleTicketSenzaZeri\",\n    \"rifSequence\" : \"rifSequence\",\n    \"testAttivitaDetectionNoc\" : \"testAttivitaDetectionNoc\",\n    \"mese\" : \"mese\",\n    \"istrin\" : \"istrin\",\n    \"costoManual\" : true,\n    \"percentInstradamento\" : \"percentInstradamento\"\n  } ],\n  \"page\" : 0\n}", EventiAzioniResponseDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<EventiAzioniResponseDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<EventiAzioniResponseDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<RIfResponseDTO> search1(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody ReportSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<RIfResponseDTO>(objectMapper.readValue("{\n  \"totalrecord\" : 1,\n  \"rifDTOs\" : [ {\n    \"note\" : \"note\",\n    \"istrin_id\" : \"istrin_id\",\n    \"detection\" : \"detection\",\n    \"minuti\" : 5.962133916683182,\n    \"risultanzeAnalisi\" : \"risultanzeAnalisi\",\n    \"dataCreazione\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"istrout\" : \"istrout\",\n    \"azioniAmministr\" : \"azioniAmministr\",\n    \"dataComplIntervento\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"fonte\" : \"fonte\",\n    \"istrout_id\" : \"istrout_id\",\n    \"sellingDestination\" : \"sellingDestination\",\n    \"risultato\" : \"risultato\",\n    \"denunciaDTOs\" : [ {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    }, {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    } ],\n    \"manual\" : true,\n    \"valorizzazione\" : 5.637376656633329,\n    \"rif\" : \"rif\",\n    \"dataRilevamento\" : \"dataRilevamento\",\n    \"istrin\" : \"istrin\",\n    \"id\" : \"id\",\n    \"denunciaAutorita\" : \"denunciaAutorita\"\n  }, {\n    \"note\" : \"note\",\n    \"istrin_id\" : \"istrin_id\",\n    \"detection\" : \"detection\",\n    \"minuti\" : 5.962133916683182,\n    \"risultanzeAnalisi\" : \"risultanzeAnalisi\",\n    \"dataCreazione\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"istrout\" : \"istrout\",\n    \"azioniAmministr\" : \"azioniAmministr\",\n    \"dataComplIntervento\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"fonte\" : \"fonte\",\n    \"istrout_id\" : \"istrout_id\",\n    \"sellingDestination\" : \"sellingDestination\",\n    \"risultato\" : \"risultato\",\n    \"denunciaDTOs\" : [ {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    }, {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    } ],\n    \"manual\" : true,\n    \"valorizzazione\" : 5.637376656633329,\n    \"rif\" : \"rif\",\n    \"dataRilevamento\" : \"dataRilevamento\",\n    \"istrin\" : \"istrin\",\n    \"id\" : \"id\",\n    \"denunciaAutorita\" : \"denunciaAutorita\"\n  } ],\n  \"size\" : 6,\n  \"page\" : 0\n}", RIfResponseDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<RIfResponseDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<RIfResponseDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<HistoryResponseDTO> search2(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody HistorySearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HistoryResponseDTO>(objectMapper.readValue("{\n  \"totalrecord\" : 1,\n  \"size\" : 6,\n  \"page\" : 0,\n  \"historyDTOs\" : [ {\n    \"operationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"payloadRequest\" : \"payloadRequest\",\n    \"notes\" : \"notes\",\n    \"startOperationTime\" : 5,\n    \"ipAddress\" : \"ipAddress\",\n    \"operatorUser\" : \"operatorUser\",\n    \"operationTime\" : 5,\n    \"troubleTicketId\" : \"troubleTicketId\",\n    \"endOperation\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"assigneeGroup\" : \"assigneeGroup\",\n    \"payload\" : \"payload\",\n    \"fmwsOperation\" : \"fmwsOperation\",\n    \"rifId\" : \"rifId\",\n    \"startOperation\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"payloadResponse\" : \"payloadResponse\"\n  }, {\n    \"operationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"payloadRequest\" : \"payloadRequest\",\n    \"notes\" : \"notes\",\n    \"startOperationTime\" : 5,\n    \"ipAddress\" : \"ipAddress\",\n    \"operatorUser\" : \"operatorUser\",\n    \"operationTime\" : 5,\n    \"troubleTicketId\" : \"troubleTicketId\",\n    \"endOperation\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"assigneeGroup\" : \"assigneeGroup\",\n    \"payload\" : \"payload\",\n    \"fmwsOperation\" : \"fmwsOperation\",\n    \"rifId\" : \"rifId\",\n    \"startOperation\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"payloadResponse\" : \"payloadResponse\"\n  } ]\n}", HistoryResponseDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HistoryResponseDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HistoryResponseDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<RIfResponseDTO> searchRif(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody ReportSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<RIfResponseDTO>(objectMapper.readValue("{\n  \"totalrecord\" : 1,\n  \"rifDTOs\" : [ {\n    \"note\" : \"note\",\n    \"istrin_id\" : \"istrin_id\",\n    \"detection\" : \"detection\",\n    \"minuti\" : 5.962133916683182,\n    \"risultanzeAnalisi\" : \"risultanzeAnalisi\",\n    \"dataCreazione\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"istrout\" : \"istrout\",\n    \"azioniAmministr\" : \"azioniAmministr\",\n    \"dataComplIntervento\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"fonte\" : \"fonte\",\n    \"istrout_id\" : \"istrout_id\",\n    \"sellingDestination\" : \"sellingDestination\",\n    \"risultato\" : \"risultato\",\n    \"denunciaDTOs\" : [ {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    }, {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    } ],\n    \"manual\" : true,\n    \"valorizzazione\" : 5.637376656633329,\n    \"rif\" : \"rif\",\n    \"dataRilevamento\" : \"dataRilevamento\",\n    \"istrin\" : \"istrin\",\n    \"id\" : \"id\",\n    \"denunciaAutorita\" : \"denunciaAutorita\"\n  }, {\n    \"note\" : \"note\",\n    \"istrin_id\" : \"istrin_id\",\n    \"detection\" : \"detection\",\n    \"minuti\" : 5.962133916683182,\n    \"risultanzeAnalisi\" : \"risultanzeAnalisi\",\n    \"dataCreazione\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"istrout\" : \"istrout\",\n    \"azioniAmministr\" : \"azioniAmministr\",\n    \"dataComplIntervento\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"fonte\" : \"fonte\",\n    \"istrout_id\" : \"istrout_id\",\n    \"sellingDestination\" : \"sellingDestination\",\n    \"risultato\" : \"risultato\",\n    \"denunciaDTOs\" : [ {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    }, {\n      \"result\" : \"result\",\n      \"note\" : \"note\",\n      \"titolo\" : \"titolo\",\n      \"minuti\" : 2.3021358869347655,\n      \"dataRilevamento\" : \"2000-01-23T04:56:07.000+00:00\",\n      \"subRif\" : \"subRif\",\n      \"id\" : \"id\",\n      \"valorizzazione\" : 7.061401241503109,\n      \"rifId\" : \"rifId\"\n    } ],\n    \"manual\" : true,\n    \"valorizzazione\" : 5.637376656633329,\n    \"rif\" : \"rif\",\n    \"dataRilevamento\" : \"dataRilevamento\",\n    \"istrin\" : \"istrin\",\n    \"id\" : \"id\",\n    \"denunciaAutorita\" : \"denunciaAutorita\"\n  } ],\n  \"size\" : 6,\n  \"page\" : 0\n}", RIfResponseDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<RIfResponseDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<RIfResponseDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> subrifAdd(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody DisputeSubrifAddDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<DisputeSubrifDTO>> subrifSearch(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody DisputeSubrifSearchDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<DisputeSubrifDTO>>(objectMapper.readValue("[ {\n  \"subrif\" : \"subrif\",\n  \"cost\" : 6.027456183070403,\n  \"month\" : \"month\",\n  \"istrout\" : \"istrout\",\n  \"year\" : \"year\",\n  \"trafficEndDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istrin\" : \"istrin\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"trafficStartDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"rif\" : \"rif\",\n  \"minute\" : 0.8008281904610115\n}, {\n  \"subrif\" : \"subrif\",\n  \"cost\" : 6.027456183070403,\n  \"month\" : \"month\",\n  \"istrout\" : \"istrout\",\n  \"year\" : \"year\",\n  \"trafficEndDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istrin\" : \"istrin\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"trafficStartDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"rif\" : \"rif\",\n  \"minute\" : 0.8008281904610115\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<DisputeSubrifDTO>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<DisputeSubrifDTO>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<EconomicBlockDTO> updateEconomicBlock(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("economicBlockId") Long economicBlockId,@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody EconomicBlockDTO body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<EconomicBlockDTO>(objectMapper.readValue("{\n  \"areaOut\" : \"areaOut\",\n  \"deb\" : 9.301444243932576,\n  \"note\" : \"note\",\n  \"currencyDefaultDebit\" : \"currencyDefaultDebit\",\n  \"blockDebitDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"year\" : \"year\",\n  \"lastUpdateDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"creUnblockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"currencyDefaultCredit\" : \"currencyDefaultCredit\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"flagBlockCredit\" : true,\n  \"subrifId\" : \"subrifId\",\n  \"id\" : 0,\n  \"disputaDebitStatus\" : \"disputaDebitStatus\",\n  \"entityIn\" : \"entityIn\",\n  \"flagBlockDebit\" : true,\n  \"createDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"debEur\" : 1.4658129805029452,\n  \"cred\" : 7.061401241503109,\n  \"blockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"flagCIA\" : true,\n  \"debUsd\" : 5.962133916683182,\n  \"blockCreditDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istrout\" : \"istrout\",\n  \"areaIn\" : \"areaIn\",\n  \"creEur\" : 5.637376656633329,\n  \"debUnblockDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"minute\" : 6.027456183070403,\n  \"entityOut\" : \"entityOut\",\n  \"disputaCreditStatus\" : \"disputaCreditStatus\",\n  \"month\" : \"month\",\n  \"creUsd\" : 2.3021358869347655,\n  \"disputeId\" : \"disputeId\",\n  \"economicType\" : \"economicType\",\n  \"trafficEndDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"disputaIdCredit\" : \"disputaIdCredit\",\n  \"reportingDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istrin\" : \"istrin\",\n  \"trafficStartDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"rifId\" : \"rifId\",\n  \"status\" : \"status\",\n  \"flagDenuncia\" : true\n}", EconomicBlockDTO.class), HttpStatus.OK);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<EconomicBlockDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<EconomicBlockDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> updateTtms(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody UpdateTtmsDTO body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<DisputeCdrFileResponseDTO> uploadCdrFile(@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "owner", required = true) String owner,@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "istrin", required = true) String istrin,@Parameter(in = ParameterIn.QUERY, description = "" ,schema=@Schema()) @Valid @RequestParam(value = "mapping", required = false) String mapping,@Parameter(in = ParameterIn.QUERY, description = "" ,schema=@Schema()) @Valid @RequestParam(value = "disputeId", required = false) String disputeId,@Parameter(in = ParameterIn.QUERY, description = "" ,schema=@Schema()) @Valid @RequestParam(value = "disputeName", required = false) String disputeName,@Parameter(in = ParameterIn.QUERY, description = "" ,schema=@Schema()) @Valid @RequestParam(value = "fileId", required = false) String fileId,@Parameter(in = ParameterIn.DEFAULT, description = "", schema=@Schema()) @Valid @RequestBody DisputeUploadCdrFileBody body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<DisputeCdrFileResponseDTO>(objectMapper.readValue("{\n  \"result\" : \"result\",\n  \"fileId\" : \"fileId\"\n}", DisputeCdrFileResponseDTO.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<DisputeCdrFileResponseDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<DisputeCdrFileResponseDTO>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> uploadFile(@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "utente", required = true) String utente,@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "tipo", required = true) String tipo,@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("ticketId") String ticketId,@Parameter(in = ParameterIn.QUERY, description = "" ,schema=@Schema()) @Valid @RequestParam(value = "nota", required = false) String nota,@Parameter(in = ParameterIn.DEFAULT, description = "", schema=@Schema()) @Valid @RequestBody UploadattachTicketIdBody body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> uploadFile1(@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "utente", required = true) String utente,@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "tipo", required = true) String tipo,@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("rif") String rif,@Parameter(in = ParameterIn.QUERY, description = "" ,schema=@Schema()) @Valid @RequestParam(value = "nota", required = false) String nota,@Parameter(in = ParameterIn.DEFAULT, description = "", schema=@Schema()) @Valid @RequestBody UploadattachRifBody body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

}
