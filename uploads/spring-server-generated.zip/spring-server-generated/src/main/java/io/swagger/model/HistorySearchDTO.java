package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.FieldSearch;
import io.swagger.model.SearchPageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * HistorySearchDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class HistorySearchDTO   {
  @JsonProperty("troubleTicketID")
  private String troubleTicketID = null;

  @JsonProperty("rif")
  private String rif = null;

  @JsonProperty("assigneeGroup")
  private String assigneeGroup = null;

  @JsonProperty("operatorUser")
  private String operatorUser = null;

  @JsonProperty("fmwsOperation")
  private String fmwsOperation = null;

  @JsonProperty("ipAddress")
  private String ipAddress = null;

  @JsonProperty("dataFrom")
  private OffsetDateTime dataFrom = null;

  @JsonProperty("dataTo")
  private OffsetDateTime dataTo = null;

  @JsonProperty("fieldSearchs")
  @Valid
  private List<FieldSearch> fieldSearchs = null;

  @JsonProperty("pageable")
  private SearchPageDTO pageable = null;

  public HistorySearchDTO troubleTicketID(String troubleTicketID) {
    this.troubleTicketID = troubleTicketID;
    return this;
  }

  /**
   * Get troubleTicketID
   * @return troubleTicketID
   **/
  @Schema(description = "")
  
    public String getTroubleTicketID() {
    return troubleTicketID;
  }

  public void setTroubleTicketID(String troubleTicketID) {
    this.troubleTicketID = troubleTicketID;
  }

  public HistorySearchDTO rif(String rif) {
    this.rif = rif;
    return this;
  }

  /**
   * Get rif
   * @return rif
   **/
  @Schema(description = "")
  
    public String getRif() {
    return rif;
  }

  public void setRif(String rif) {
    this.rif = rif;
  }

  public HistorySearchDTO assigneeGroup(String assigneeGroup) {
    this.assigneeGroup = assigneeGroup;
    return this;
  }

  /**
   * Get assigneeGroup
   * @return assigneeGroup
   **/
  @Schema(description = "")
  
    public String getAssigneeGroup() {
    return assigneeGroup;
  }

  public void setAssigneeGroup(String assigneeGroup) {
    this.assigneeGroup = assigneeGroup;
  }

  public HistorySearchDTO operatorUser(String operatorUser) {
    this.operatorUser = operatorUser;
    return this;
  }

  /**
   * Get operatorUser
   * @return operatorUser
   **/
  @Schema(description = "")
  
    public String getOperatorUser() {
    return operatorUser;
  }

  public void setOperatorUser(String operatorUser) {
    this.operatorUser = operatorUser;
  }

  public HistorySearchDTO fmwsOperation(String fmwsOperation) {
    this.fmwsOperation = fmwsOperation;
    return this;
  }

  /**
   * Get fmwsOperation
   * @return fmwsOperation
   **/
  @Schema(description = "")
  
    public String getFmwsOperation() {
    return fmwsOperation;
  }

  public void setFmwsOperation(String fmwsOperation) {
    this.fmwsOperation = fmwsOperation;
  }

  public HistorySearchDTO ipAddress(String ipAddress) {
    this.ipAddress = ipAddress;
    return this;
  }

  /**
   * Get ipAddress
   * @return ipAddress
   **/
  @Schema(description = "")
  
    public String getIpAddress() {
    return ipAddress;
  }

  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  public HistorySearchDTO dataFrom(OffsetDateTime dataFrom) {
    this.dataFrom = dataFrom;
    return this;
  }

  /**
   * Get dataFrom
   * @return dataFrom
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDataFrom() {
    return dataFrom;
  }

  public void setDataFrom(OffsetDateTime dataFrom) {
    this.dataFrom = dataFrom;
  }

  public HistorySearchDTO dataTo(OffsetDateTime dataTo) {
    this.dataTo = dataTo;
    return this;
  }

  /**
   * Get dataTo
   * @return dataTo
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDataTo() {
    return dataTo;
  }

  public void setDataTo(OffsetDateTime dataTo) {
    this.dataTo = dataTo;
  }

  public HistorySearchDTO fieldSearchs(List<FieldSearch> fieldSearchs) {
    this.fieldSearchs = fieldSearchs;
    return this;
  }

  public HistorySearchDTO addFieldSearchsItem(FieldSearch fieldSearchsItem) {
    if (this.fieldSearchs == null) {
      this.fieldSearchs = new ArrayList<FieldSearch>();
    }
    this.fieldSearchs.add(fieldSearchsItem);
    return this;
  }

  /**
   * Get fieldSearchs
   * @return fieldSearchs
   **/
  @Schema(description = "")
      @Valid
    public List<FieldSearch> getFieldSearchs() {
    return fieldSearchs;
  }

  public void setFieldSearchs(List<FieldSearch> fieldSearchs) {
    this.fieldSearchs = fieldSearchs;
  }

  public HistorySearchDTO pageable(SearchPageDTO pageable) {
    this.pageable = pageable;
    return this;
  }

  /**
   * Get pageable
   * @return pageable
   **/
  @Schema(description = "")
  
    @Valid
    public SearchPageDTO getPageable() {
    return pageable;
  }

  public void setPageable(SearchPageDTO pageable) {
    this.pageable = pageable;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HistorySearchDTO historySearchDTO = (HistorySearchDTO) o;
    return Objects.equals(this.troubleTicketID, historySearchDTO.troubleTicketID) &&
        Objects.equals(this.rif, historySearchDTO.rif) &&
        Objects.equals(this.assigneeGroup, historySearchDTO.assigneeGroup) &&
        Objects.equals(this.operatorUser, historySearchDTO.operatorUser) &&
        Objects.equals(this.fmwsOperation, historySearchDTO.fmwsOperation) &&
        Objects.equals(this.ipAddress, historySearchDTO.ipAddress) &&
        Objects.equals(this.dataFrom, historySearchDTO.dataFrom) &&
        Objects.equals(this.dataTo, historySearchDTO.dataTo) &&
        Objects.equals(this.fieldSearchs, historySearchDTO.fieldSearchs) &&
        Objects.equals(this.pageable, historySearchDTO.pageable);
  }

  @Override
  public int hashCode() {
    return Objects.hash(troubleTicketID, rif, assigneeGroup, operatorUser, fmwsOperation, ipAddress, dataFrom, dataTo, fieldSearchs, pageable);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HistorySearchDTO {\n");
    
    sb.append("    troubleTicketID: ").append(toIndentedString(troubleTicketID)).append("\n");
    sb.append("    rif: ").append(toIndentedString(rif)).append("\n");
    sb.append("    assigneeGroup: ").append(toIndentedString(assigneeGroup)).append("\n");
    sb.append("    operatorUser: ").append(toIndentedString(operatorUser)).append("\n");
    sb.append("    fmwsOperation: ").append(toIndentedString(fmwsOperation)).append("\n");
    sb.append("    ipAddress: ").append(toIndentedString(ipAddress)).append("\n");
    sb.append("    dataFrom: ").append(toIndentedString(dataFrom)).append("\n");
    sb.append("    dataTo: ").append(toIndentedString(dataTo)).append("\n");
    sb.append("    fieldSearchs: ").append(toIndentedString(fieldSearchs)).append("\n");
    sb.append("    pageable: ").append(toIndentedString(pageable)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
