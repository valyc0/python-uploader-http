package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RifAlarmDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class RifAlarmDTO   {
  @JsonProperty("rifId")
  private String rifId = null;

  @JsonProperty("rif_action")
  private String rifAction = null;

  @JsonProperty("rif_result")
  private String rifResult = null;

  @JsonProperty("rif_complaint")
  private String rifComplaint = null;

  @JsonProperty("closureDate")
  private OffsetDateTime closureDate = null;

  public RifAlarmDTO rifId(String rifId) {
    this.rifId = rifId;
    return this;
  }

  /**
   * Get rifId
   * @return rifId
   **/
  @Schema(description = "")
  
    public String getRifId() {
    return rifId;
  }

  public void setRifId(String rifId) {
    this.rifId = rifId;
  }

  public RifAlarmDTO rifAction(String rifAction) {
    this.rifAction = rifAction;
    return this;
  }

  /**
   * Get rifAction
   * @return rifAction
   **/
  @Schema(description = "")
  
    public String getRifAction() {
    return rifAction;
  }

  public void setRifAction(String rifAction) {
    this.rifAction = rifAction;
  }

  public RifAlarmDTO rifResult(String rifResult) {
    this.rifResult = rifResult;
    return this;
  }

  /**
   * Get rifResult
   * @return rifResult
   **/
  @Schema(description = "")
  
    public String getRifResult() {
    return rifResult;
  }

  public void setRifResult(String rifResult) {
    this.rifResult = rifResult;
  }

  public RifAlarmDTO rifComplaint(String rifComplaint) {
    this.rifComplaint = rifComplaint;
    return this;
  }

  /**
   * Get rifComplaint
   * @return rifComplaint
   **/
  @Schema(description = "")
  
    public String getRifComplaint() {
    return rifComplaint;
  }

  public void setRifComplaint(String rifComplaint) {
    this.rifComplaint = rifComplaint;
  }

  public RifAlarmDTO closureDate(OffsetDateTime closureDate) {
    this.closureDate = closureDate;
    return this;
  }

  /**
   * Get closureDate
   * @return closureDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getClosureDate() {
    return closureDate;
  }

  public void setClosureDate(OffsetDateTime closureDate) {
    this.closureDate = closureDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RifAlarmDTO rifAlarmDTO = (RifAlarmDTO) o;
    return Objects.equals(this.rifId, rifAlarmDTO.rifId) &&
        Objects.equals(this.rifAction, rifAlarmDTO.rifAction) &&
        Objects.equals(this.rifResult, rifAlarmDTO.rifResult) &&
        Objects.equals(this.rifComplaint, rifAlarmDTO.rifComplaint) &&
        Objects.equals(this.closureDate, rifAlarmDTO.closureDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(rifId, rifAction, rifResult, rifComplaint, closureDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RifAlarmDTO {\n");
    
    sb.append("    rifId: ").append(toIndentedString(rifId)).append("\n");
    sb.append("    rifAction: ").append(toIndentedString(rifAction)).append("\n");
    sb.append("    rifResult: ").append(toIndentedString(rifResult)).append("\n");
    sb.append("    rifComplaint: ").append(toIndentedString(rifComplaint)).append("\n");
    sb.append("    closureDate: ").append(toIndentedString(closureDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
