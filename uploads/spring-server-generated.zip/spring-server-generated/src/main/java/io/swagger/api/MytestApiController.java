package io.swagger.api;

import io.swagger.model.FmwsRifAlarms;
import io.swagger.model.FmwsSubRif;
import io.swagger.model.FmwsSubRifAlarms;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")
@RestController
public class MytestApiController implements MytestApi {

    private static final Logger log = LoggerFactory.getLogger(MytestApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public MytestApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<String> index() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<String>> para(@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "group", required = true) String group,@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "key", required = true) String key) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<String>>(objectMapper.readValue("[ \"\", \"\" ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<String>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<String>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<FmwsRifAlarms>> rif2() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<FmwsRifAlarms>>(objectMapper.readValue("[ {\n  \"sequenceNumber\" : 1,\n  \"detection\" : \"detection\",\n  \"istrout\" : \"istrout\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"year\" : \"year\",\n  \"cdfSequenceNumber\" : 5,\n  \"istroutDesc\" : \"istroutDesc\",\n  \"rifHashKey\" : \"rifHashKey\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"creationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"manual\" : true,\n  \"reportedOdvDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"result\" : \"result\",\n  \"month\" : 0,\n  \"complaint\" : true,\n  \"closureDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"action\" : true,\n  \"istrinDesc\" : \"istrinDesc\",\n  \"istrin\" : \"istrin\",\n  \"resultDescription\" : \"resultDescription\",\n  \"ticketNumbers\" : \"ticketNumbers\",\n  \"rifId\" : \"rifId\",\n  \"quarter\" : 6,\n  \"reportedCiaDate\" : \"2000-01-23T04:56:07.000+00:00\"\n}, {\n  \"sequenceNumber\" : 1,\n  \"detection\" : \"detection\",\n  \"istrout\" : \"istrout\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"year\" : \"year\",\n  \"cdfSequenceNumber\" : 5,\n  \"istroutDesc\" : \"istroutDesc\",\n  \"rifHashKey\" : \"rifHashKey\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"creationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"manual\" : true,\n  \"reportedOdvDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"result\" : \"result\",\n  \"month\" : 0,\n  \"complaint\" : true,\n  \"closureDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"action\" : true,\n  \"istrinDesc\" : \"istrinDesc\",\n  \"istrin\" : \"istrin\",\n  \"resultDescription\" : \"resultDescription\",\n  \"ticketNumbers\" : \"ticketNumbers\",\n  \"rifId\" : \"rifId\",\n  \"quarter\" : 6,\n  \"reportedCiaDate\" : \"2000-01-23T04:56:07.000+00:00\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<FmwsRifAlarms>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<FmwsRifAlarms>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<FmwsSubRif>> subrif() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<FmwsSubRif>>(objectMapper.readValue("[ {\n  \"sequenceNumber\" : 0,\n  \"istrout\" : \"istrout\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istroutDesc\" : \"istroutDesc\",\n  \"subrifId\" : \"subrifId\",\n  \"istrinDesc\" : \"istrinDesc\",\n  \"istrin\" : \"istrin\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"creationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"rifId\" : \"rifId\"\n}, {\n  \"sequenceNumber\" : 0,\n  \"istrout\" : \"istrout\",\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"istroutDesc\" : \"istroutDesc\",\n  \"subrifId\" : \"subrifId\",\n  \"istrinDesc\" : \"istrinDesc\",\n  \"istrin\" : \"istrin\",\n  \"sellingDestination\" : \"sellingDestination\",\n  \"creationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"rifId\" : \"rifId\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<FmwsSubRif>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<FmwsSubRif>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<FmwsSubRifAlarms>> subrifAlarm() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<FmwsSubRifAlarms>>(objectMapper.readValue("[ {\n  \"cdf\" : \"cdf\",\n  \"answered\" : 1,\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"alarmFraudCategory\" : \"alarmFraudCategory\",\n  \"creationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"alarmReferenceValue\" : \"alarmReferenceValue\",\n  \"alarmReferenceType\" : \"alarmReferenceType\",\n  \"totalMinutes\" : 5,\n  \"subrifId\" : \"subrifId\",\n  \"alarmId\" : \"alarmId\",\n  \"id\" : 0,\n  \"rifId\" : \"rifId\",\n  \"ticketId\" : \"ticketId\",\n  \"totalCost\" : 5,\n  \"attempts\" : 6\n}, {\n  \"cdf\" : \"cdf\",\n  \"answered\" : 1,\n  \"lastModifiedDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"alarmFraudCategory\" : \"alarmFraudCategory\",\n  \"creationDate\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"alarmReferenceValue\" : \"alarmReferenceValue\",\n  \"alarmReferenceType\" : \"alarmReferenceType\",\n  \"totalMinutes\" : 5,\n  \"subrifId\" : \"subrifId\",\n  \"alarmId\" : \"alarmId\",\n  \"id\" : 0,\n  \"rifId\" : \"rifId\",\n  \"ticketId\" : \"ticketId\",\n  \"totalCost\" : 5,\n  \"attempts\" : 6\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<FmwsSubRifAlarms>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<FmwsSubRifAlarms>>(HttpStatus.NOT_IMPLEMENTED);
    }

}
