package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * DisputeSubrifSearchDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class DisputeSubrifSearchDTO   {
  @JsonProperty("owner")
  private String owner = null;

  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("year")
  private String year = null;

  @JsonProperty("month")
  private String month = null;

  public DisputeSubrifSearchDTO owner(String owner) {
    this.owner = owner;
    return this;
  }

  /**
   * Get owner
   * @return owner
   **/
  @Schema(description = "")
  
    public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public DisputeSubrifSearchDTO istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public DisputeSubrifSearchDTO year(String year) {
    this.year = year;
    return this;
  }

  /**
   * Get year
   * @return year
   **/
  @Schema(description = "")
  
    public String getYear() {
    return year;
  }

  public void setYear(String year) {
    this.year = year;
  }

  public DisputeSubrifSearchDTO month(String month) {
    this.month = month;
    return this;
  }

  /**
   * Get month
   * @return month
   **/
  @Schema(description = "")
  
    public String getMonth() {
    return month;
  }

  public void setMonth(String month) {
    this.month = month;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DisputeSubrifSearchDTO disputeSubrifSearchDTO = (DisputeSubrifSearchDTO) o;
    return Objects.equals(this.owner, disputeSubrifSearchDTO.owner) &&
        Objects.equals(this.istrin, disputeSubrifSearchDTO.istrin) &&
        Objects.equals(this.year, disputeSubrifSearchDTO.year) &&
        Objects.equals(this.month, disputeSubrifSearchDTO.month);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, istrin, year, month);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DisputeSubrifSearchDTO {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    year: ").append(toIndentedString(year)).append("\n");
    sb.append("    month: ").append(toIndentedString(month)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
