package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.model.FieldSearch;
import io.swagger.model.SearchPageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TicketSearchDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class TicketSearchDTO   {
  @JsonProperty("troubleTicketID")
  private String troubleTicketID = null;

  @JsonProperty("rif")
  private String rif = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("istrin")
  private String istrin = null;

  /**
   * fonte: FDR,PDT,MAN
   */
  public enum FonteEnum {
    FDR("FDR"),
    
    PDT("PDT"),
    
    MAN("MAN"),
    
    ROP("ROP"),
    
    ALM("ALM");

    private String value;

    FonteEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static FonteEnum fromValue(String text) {
      for (FonteEnum b : FonteEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("fonte")
  private FonteEnum fonte = null;

  @JsonProperty("stato")
  private String stato = null;

  @JsonProperty("reasonForClosure")
  private String reasonForClosure = null;

  @JsonProperty("dataFrom")
  private OffsetDateTime dataFrom = null;

  @JsonProperty("dataTo")
  private OffsetDateTime dataTo = null;

  @JsonProperty("fieldSearchs")
  @Valid
  private List<FieldSearch> fieldSearchs = null;

  @JsonProperty("pageable")
  private SearchPageDTO pageable = null;

  public TicketSearchDTO troubleTicketID(String troubleTicketID) {
    this.troubleTicketID = troubleTicketID;
    return this;
  }

  /**
   * trouble Ticket ID
   * @return troubleTicketID
   **/
  @Schema(description = "trouble Ticket ID")
  
    public String getTroubleTicketID() {
    return troubleTicketID;
  }

  public void setTroubleTicketID(String troubleTicketID) {
    this.troubleTicketID = troubleTicketID;
  }

  public TicketSearchDTO rif(String rif) {
    this.rif = rif;
    return this;
  }

  /**
   * RIF collegato al ticket
   * @return rif
   **/
  @Schema(description = "RIF collegato al ticket")
  
    public String getRif() {
    return rif;
  }

  public void setRif(String rif) {
    this.rif = rif;
  }

  public TicketSearchDTO sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * selling Destination
   * @return sellingDestination
   **/
  @Schema(description = "selling Destination")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public TicketSearchDTO istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * carrier in
   * @return istrin
   **/
  @Schema(description = "carrier in")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public TicketSearchDTO fonte(FonteEnum fonte) {
    this.fonte = fonte;
    return this;
  }

  /**
   * fonte: FDR,PDT,MAN
   * @return fonte
   **/
  @Schema(description = "fonte: FDR,PDT,MAN")
  
    public FonteEnum getFonte() {
    return fonte;
  }

  public void setFonte(FonteEnum fonte) {
    this.fonte = fonte;
  }

  public TicketSearchDTO stato(String stato) {
    this.stato = stato;
    return this;
  }

  /**
   * stato
   * @return stato
   **/
  @Schema(description = "stato")
  
    public String getStato() {
    return stato;
  }

  public void setStato(String stato) {
    this.stato = stato;
  }

  public TicketSearchDTO reasonForClosure(String reasonForClosure) {
    this.reasonForClosure = reasonForClosure;
    return this;
  }

  /**
   * Reason code
   * @return reasonForClosure
   **/
  @Schema(description = "Reason code")
  
    public String getReasonForClosure() {
    return reasonForClosure;
  }

  public void setReasonForClosure(String reasonForClosure) {
    this.reasonForClosure = reasonForClosure;
  }

  public TicketSearchDTO dataFrom(OffsetDateTime dataFrom) {
    this.dataFrom = dataFrom;
    return this;
  }

  /**
   * data dal
   * @return dataFrom
   **/
  @Schema(description = "data dal")
  
    @Valid
    public OffsetDateTime getDataFrom() {
    return dataFrom;
  }

  public void setDataFrom(OffsetDateTime dataFrom) {
    this.dataFrom = dataFrom;
  }

  public TicketSearchDTO dataTo(OffsetDateTime dataTo) {
    this.dataTo = dataTo;
    return this;
  }

  /**
   * data al
   * @return dataTo
   **/
  @Schema(description = "data al")
  
    @Valid
    public OffsetDateTime getDataTo() {
    return dataTo;
  }

  public void setDataTo(OffsetDateTime dataTo) {
    this.dataTo = dataTo;
  }

  public TicketSearchDTO fieldSearchs(List<FieldSearch> fieldSearchs) {
    this.fieldSearchs = fieldSearchs;
    return this;
  }

  public TicketSearchDTO addFieldSearchsItem(FieldSearch fieldSearchsItem) {
    if (this.fieldSearchs == null) {
      this.fieldSearchs = new ArrayList<FieldSearch>();
    }
    this.fieldSearchs.add(fieldSearchsItem);
    return this;
  }

  /**
   * oggetto per l'ordinamento dei campi
   * @return fieldSearchs
   **/
  @Schema(description = "oggetto per l'ordinamento dei campi")
      @Valid
    public List<FieldSearch> getFieldSearchs() {
    return fieldSearchs;
  }

  public void setFieldSearchs(List<FieldSearch> fieldSearchs) {
    this.fieldSearchs = fieldSearchs;
  }

  public TicketSearchDTO pageable(SearchPageDTO pageable) {
    this.pageable = pageable;
    return this;
  }

  /**
   * Get pageable
   * @return pageable
   **/
  @Schema(description = "")
  
    @Valid
    public SearchPageDTO getPageable() {
    return pageable;
  }

  public void setPageable(SearchPageDTO pageable) {
    this.pageable = pageable;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TicketSearchDTO ticketSearchDTO = (TicketSearchDTO) o;
    return Objects.equals(this.troubleTicketID, ticketSearchDTO.troubleTicketID) &&
        Objects.equals(this.rif, ticketSearchDTO.rif) &&
        Objects.equals(this.sellingDestination, ticketSearchDTO.sellingDestination) &&
        Objects.equals(this.istrin, ticketSearchDTO.istrin) &&
        Objects.equals(this.fonte, ticketSearchDTO.fonte) &&
        Objects.equals(this.stato, ticketSearchDTO.stato) &&
        Objects.equals(this.reasonForClosure, ticketSearchDTO.reasonForClosure) &&
        Objects.equals(this.dataFrom, ticketSearchDTO.dataFrom) &&
        Objects.equals(this.dataTo, ticketSearchDTO.dataTo) &&
        Objects.equals(this.fieldSearchs, ticketSearchDTO.fieldSearchs) &&
        Objects.equals(this.pageable, ticketSearchDTO.pageable);
  }

  @Override
  public int hashCode() {
    return Objects.hash(troubleTicketID, rif, sellingDestination, istrin, fonte, stato, reasonForClosure, dataFrom, dataTo, fieldSearchs, pageable);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TicketSearchDTO {\n");
    
    sb.append("    troubleTicketID: ").append(toIndentedString(troubleTicketID)).append("\n");
    sb.append("    rif: ").append(toIndentedString(rif)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    fonte: ").append(toIndentedString(fonte)).append("\n");
    sb.append("    stato: ").append(toIndentedString(stato)).append("\n");
    sb.append("    reasonForClosure: ").append(toIndentedString(reasonForClosure)).append("\n");
    sb.append("    dataFrom: ").append(toIndentedString(dataFrom)).append("\n");
    sb.append("    dataTo: ").append(toIndentedString(dataTo)).append("\n");
    sb.append("    fieldSearchs: ").append(toIndentedString(fieldSearchs)).append("\n");
    sb.append("    pageable: ").append(toIndentedString(pageable)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
