package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * FmwsRifAlarms
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class FmwsRifAlarms   {
  @JsonProperty("rifId")
  private String rifId = null;

  @JsonProperty("rifHashKey")
  private String rifHashKey = null;

  @JsonProperty("action")
  private Boolean action = null;

  @JsonProperty("closureDate")
  private OffsetDateTime closureDate = null;

  @JsonProperty("complaint")
  private Boolean complaint = null;

  @JsonProperty("creationDate")
  private OffsetDateTime creationDate = null;

  @JsonProperty("manual")
  private Boolean manual = null;

  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("istrout")
  private String istrout = null;

  @JsonProperty("lastModifiedDate")
  private OffsetDateTime lastModifiedDate = null;

  @JsonProperty("month")
  private Long month = null;

  @JsonProperty("quarter")
  private Long quarter = null;

  @JsonProperty("reportedCiaDate")
  private OffsetDateTime reportedCiaDate = null;

  @JsonProperty("reportedOdvDate")
  private OffsetDateTime reportedOdvDate = null;

  @JsonProperty("result")
  private String result = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("sequenceNumber")
  private Long sequenceNumber = null;

  @JsonProperty("year")
  private String year = null;

  @JsonProperty("detection")
  private String detection = null;

  @JsonProperty("resultDescription")
  private String resultDescription = null;

  @JsonProperty("ticketNumbers")
  private String ticketNumbers = null;

  @JsonProperty("istrinDesc")
  private String istrinDesc = null;

  @JsonProperty("istroutDesc")
  private String istroutDesc = null;

  @JsonProperty("cdfSequenceNumber")
  private Long cdfSequenceNumber = null;

  public FmwsRifAlarms rifId(String rifId) {
    this.rifId = rifId;
    return this;
  }

  /**
   * Get rifId
   * @return rifId
   **/
  @Schema(description = "")
  
    public String getRifId() {
    return rifId;
  }

  public void setRifId(String rifId) {
    this.rifId = rifId;
  }

  public FmwsRifAlarms rifHashKey(String rifHashKey) {
    this.rifHashKey = rifHashKey;
    return this;
  }

  /**
   * Get rifHashKey
   * @return rifHashKey
   **/
  @Schema(description = "")
  
    public String getRifHashKey() {
    return rifHashKey;
  }

  public void setRifHashKey(String rifHashKey) {
    this.rifHashKey = rifHashKey;
  }

  public FmwsRifAlarms action(Boolean action) {
    this.action = action;
    return this;
  }

  /**
   * Get action
   * @return action
   **/
  @Schema(description = "")
  
    public Boolean isAction() {
    return action;
  }

  public void setAction(Boolean action) {
    this.action = action;
  }

  public FmwsRifAlarms closureDate(OffsetDateTime closureDate) {
    this.closureDate = closureDate;
    return this;
  }

  /**
   * Get closureDate
   * @return closureDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getClosureDate() {
    return closureDate;
  }

  public void setClosureDate(OffsetDateTime closureDate) {
    this.closureDate = closureDate;
  }

  public FmwsRifAlarms complaint(Boolean complaint) {
    this.complaint = complaint;
    return this;
  }

  /**
   * Get complaint
   * @return complaint
   **/
  @Schema(description = "")
  
    public Boolean isComplaint() {
    return complaint;
  }

  public void setComplaint(Boolean complaint) {
    this.complaint = complaint;
  }

  public FmwsRifAlarms creationDate(OffsetDateTime creationDate) {
    this.creationDate = creationDate;
    return this;
  }

  /**
   * Get creationDate
   * @return creationDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(OffsetDateTime creationDate) {
    this.creationDate = creationDate;
  }

  public FmwsRifAlarms manual(Boolean manual) {
    this.manual = manual;
    return this;
  }

  /**
   * Get manual
   * @return manual
   **/
  @Schema(description = "")
  
    public Boolean isManual() {
    return manual;
  }

  public void setManual(Boolean manual) {
    this.manual = manual;
  }

  public FmwsRifAlarms istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public FmwsRifAlarms istrout(String istrout) {
    this.istrout = istrout;
    return this;
  }

  /**
   * Get istrout
   * @return istrout
   **/
  @Schema(description = "")
  
    public String getIstrout() {
    return istrout;
  }

  public void setIstrout(String istrout) {
    this.istrout = istrout;
  }

  public FmwsRifAlarms lastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(OffsetDateTime lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public FmwsRifAlarms month(Long month) {
    this.month = month;
    return this;
  }

  /**
   * Get month
   * @return month
   **/
  @Schema(description = "")
  
    public Long getMonth() {
    return month;
  }

  public void setMonth(Long month) {
    this.month = month;
  }

  public FmwsRifAlarms quarter(Long quarter) {
    this.quarter = quarter;
    return this;
  }

  /**
   * Get quarter
   * @return quarter
   **/
  @Schema(description = "")
  
    public Long getQuarter() {
    return quarter;
  }

  public void setQuarter(Long quarter) {
    this.quarter = quarter;
  }

  public FmwsRifAlarms reportedCiaDate(OffsetDateTime reportedCiaDate) {
    this.reportedCiaDate = reportedCiaDate;
    return this;
  }

  /**
   * Get reportedCiaDate
   * @return reportedCiaDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getReportedCiaDate() {
    return reportedCiaDate;
  }

  public void setReportedCiaDate(OffsetDateTime reportedCiaDate) {
    this.reportedCiaDate = reportedCiaDate;
  }

  public FmwsRifAlarms reportedOdvDate(OffsetDateTime reportedOdvDate) {
    this.reportedOdvDate = reportedOdvDate;
    return this;
  }

  /**
   * Get reportedOdvDate
   * @return reportedOdvDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getReportedOdvDate() {
    return reportedOdvDate;
  }

  public void setReportedOdvDate(OffsetDateTime reportedOdvDate) {
    this.reportedOdvDate = reportedOdvDate;
  }

  public FmwsRifAlarms result(String result) {
    this.result = result;
    return this;
  }

  /**
   * Get result
   * @return result
   **/
  @Schema(description = "")
  
    public String getResult() {
    return result;
  }

  public void setResult(String result) {
    this.result = result;
  }

  public FmwsRifAlarms sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public FmwsRifAlarms sequenceNumber(Long sequenceNumber) {
    this.sequenceNumber = sequenceNumber;
    return this;
  }

  /**
   * Get sequenceNumber
   * @return sequenceNumber
   **/
  @Schema(description = "")
  
    public Long getSequenceNumber() {
    return sequenceNumber;
  }

  public void setSequenceNumber(Long sequenceNumber) {
    this.sequenceNumber = sequenceNumber;
  }

  public FmwsRifAlarms year(String year) {
    this.year = year;
    return this;
  }

  /**
   * Get year
   * @return year
   **/
  @Schema(description = "")
  
    public String getYear() {
    return year;
  }

  public void setYear(String year) {
    this.year = year;
  }

  public FmwsRifAlarms detection(String detection) {
    this.detection = detection;
    return this;
  }

  /**
   * Get detection
   * @return detection
   **/
  @Schema(description = "")
  
    public String getDetection() {
    return detection;
  }

  public void setDetection(String detection) {
    this.detection = detection;
  }

  public FmwsRifAlarms resultDescription(String resultDescription) {
    this.resultDescription = resultDescription;
    return this;
  }

  /**
   * Get resultDescription
   * @return resultDescription
   **/
  @Schema(description = "")
  
    public String getResultDescription() {
    return resultDescription;
  }

  public void setResultDescription(String resultDescription) {
    this.resultDescription = resultDescription;
  }

  public FmwsRifAlarms ticketNumbers(String ticketNumbers) {
    this.ticketNumbers = ticketNumbers;
    return this;
  }

  /**
   * Get ticketNumbers
   * @return ticketNumbers
   **/
  @Schema(description = "")
  
    public String getTicketNumbers() {
    return ticketNumbers;
  }

  public void setTicketNumbers(String ticketNumbers) {
    this.ticketNumbers = ticketNumbers;
  }

  public FmwsRifAlarms istrinDesc(String istrinDesc) {
    this.istrinDesc = istrinDesc;
    return this;
  }

  /**
   * Get istrinDesc
   * @return istrinDesc
   **/
  @Schema(description = "")
  
    public String getIstrinDesc() {
    return istrinDesc;
  }

  public void setIstrinDesc(String istrinDesc) {
    this.istrinDesc = istrinDesc;
  }

  public FmwsRifAlarms istroutDesc(String istroutDesc) {
    this.istroutDesc = istroutDesc;
    return this;
  }

  /**
   * Get istroutDesc
   * @return istroutDesc
   **/
  @Schema(description = "")
  
    public String getIstroutDesc() {
    return istroutDesc;
  }

  public void setIstroutDesc(String istroutDesc) {
    this.istroutDesc = istroutDesc;
  }

  public FmwsRifAlarms cdfSequenceNumber(Long cdfSequenceNumber) {
    this.cdfSequenceNumber = cdfSequenceNumber;
    return this;
  }

  /**
   * Get cdfSequenceNumber
   * @return cdfSequenceNumber
   **/
  @Schema(description = "")
  
    public Long getCdfSequenceNumber() {
    return cdfSequenceNumber;
  }

  public void setCdfSequenceNumber(Long cdfSequenceNumber) {
    this.cdfSequenceNumber = cdfSequenceNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FmwsRifAlarms fmwsRifAlarms = (FmwsRifAlarms) o;
    return Objects.equals(this.rifId, fmwsRifAlarms.rifId) &&
        Objects.equals(this.rifHashKey, fmwsRifAlarms.rifHashKey) &&
        Objects.equals(this.action, fmwsRifAlarms.action) &&
        Objects.equals(this.closureDate, fmwsRifAlarms.closureDate) &&
        Objects.equals(this.complaint, fmwsRifAlarms.complaint) &&
        Objects.equals(this.creationDate, fmwsRifAlarms.creationDate) &&
        Objects.equals(this.manual, fmwsRifAlarms.manual) &&
        Objects.equals(this.istrin, fmwsRifAlarms.istrin) &&
        Objects.equals(this.istrout, fmwsRifAlarms.istrout) &&
        Objects.equals(this.lastModifiedDate, fmwsRifAlarms.lastModifiedDate) &&
        Objects.equals(this.month, fmwsRifAlarms.month) &&
        Objects.equals(this.quarter, fmwsRifAlarms.quarter) &&
        Objects.equals(this.reportedCiaDate, fmwsRifAlarms.reportedCiaDate) &&
        Objects.equals(this.reportedOdvDate, fmwsRifAlarms.reportedOdvDate) &&
        Objects.equals(this.result, fmwsRifAlarms.result) &&
        Objects.equals(this.sellingDestination, fmwsRifAlarms.sellingDestination) &&
        Objects.equals(this.sequenceNumber, fmwsRifAlarms.sequenceNumber) &&
        Objects.equals(this.year, fmwsRifAlarms.year) &&
        Objects.equals(this.detection, fmwsRifAlarms.detection) &&
        Objects.equals(this.resultDescription, fmwsRifAlarms.resultDescription) &&
        Objects.equals(this.ticketNumbers, fmwsRifAlarms.ticketNumbers) &&
        Objects.equals(this.istrinDesc, fmwsRifAlarms.istrinDesc) &&
        Objects.equals(this.istroutDesc, fmwsRifAlarms.istroutDesc) &&
        Objects.equals(this.cdfSequenceNumber, fmwsRifAlarms.cdfSequenceNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(rifId, rifHashKey, action, closureDate, complaint, creationDate, manual, istrin, istrout, lastModifiedDate, month, quarter, reportedCiaDate, reportedOdvDate, result, sellingDestination, sequenceNumber, year, detection, resultDescription, ticketNumbers, istrinDesc, istroutDesc, cdfSequenceNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FmwsRifAlarms {\n");
    
    sb.append("    rifId: ").append(toIndentedString(rifId)).append("\n");
    sb.append("    rifHashKey: ").append(toIndentedString(rifHashKey)).append("\n");
    sb.append("    action: ").append(toIndentedString(action)).append("\n");
    sb.append("    closureDate: ").append(toIndentedString(closureDate)).append("\n");
    sb.append("    complaint: ").append(toIndentedString(complaint)).append("\n");
    sb.append("    creationDate: ").append(toIndentedString(creationDate)).append("\n");
    sb.append("    manual: ").append(toIndentedString(manual)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    istrout: ").append(toIndentedString(istrout)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("    month: ").append(toIndentedString(month)).append("\n");
    sb.append("    quarter: ").append(toIndentedString(quarter)).append("\n");
    sb.append("    reportedCiaDate: ").append(toIndentedString(reportedCiaDate)).append("\n");
    sb.append("    reportedOdvDate: ").append(toIndentedString(reportedOdvDate)).append("\n");
    sb.append("    result: ").append(toIndentedString(result)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    sequenceNumber: ").append(toIndentedString(sequenceNumber)).append("\n");
    sb.append("    year: ").append(toIndentedString(year)).append("\n");
    sb.append("    detection: ").append(toIndentedString(detection)).append("\n");
    sb.append("    resultDescription: ").append(toIndentedString(resultDescription)).append("\n");
    sb.append("    ticketNumbers: ").append(toIndentedString(ticketNumbers)).append("\n");
    sb.append("    istrinDesc: ").append(toIndentedString(istrinDesc)).append("\n");
    sb.append("    istroutDesc: ").append(toIndentedString(istroutDesc)).append("\n");
    sb.append("    cdfSequenceNumber: ").append(toIndentedString(cdfSequenceNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
