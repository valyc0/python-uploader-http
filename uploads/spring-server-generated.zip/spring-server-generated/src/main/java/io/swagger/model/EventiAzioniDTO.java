package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.EventiDTO;
import io.swagger.model.TicketAzioniDTO;
import io.swagger.model.TicketDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * EventiAzioniDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class EventiAzioniDTO   {
  @JsonProperty("ticket")
  private TicketDTO ticket = null;

  @JsonProperty("rifNumerico")
  private String rifNumerico = null;

  @JsonProperty("dataTraffico")
  private String dataTraffico = null;

  @JsonProperty("mese")
  private String mese = null;

  @JsonProperty("fonte")
  private String fonte = null;

  @JsonProperty("troubleTicket")
  private String troubleTicket = null;

  @JsonProperty("destination")
  private String destination = null;

  @JsonProperty("istrin")
  private String istrin = null;

  @JsonProperty("percentInstradamento")
  private String percentInstradamento = null;

  @JsonProperty("istrout")
  private String istrout = null;

  @JsonProperty("minuti")
  private String minuti = null;

  @JsonProperty("costoMin")
  private String costoMin = null;

  @JsonProperty("costoManual")
  private Boolean costoManual = null;

  @JsonProperty("costoDanger")
  private Boolean costoDanger = null;

  @JsonProperty("valorizzazione")
  private String valorizzazione = null;

  @JsonProperty("testAttivitaDetectionNoc")
  private String testAttivitaDetectionNoc = null;

  @JsonProperty("richiestaBarraggio")
  private String richiestaBarraggio = null;

  @JsonProperty("richiestaBarraggioCompact")
  private String richiestaBarraggioCompact = null;

  @JsonProperty("rifCompleto")
  private String rifCompleto = null;

  @JsonProperty("rifSequence")
  private String rifSequence = null;

  @JsonProperty("troubleTicketSenzaZeri")
  private String troubleTicketSenzaZeri = null;

  @JsonProperty("eventi")
  @Valid
  private List<EventiDTO> eventi = null;

  @JsonProperty("azioni")
  @Valid
  private List<TicketAzioniDTO> azioni = null;

  public EventiAzioniDTO ticket(TicketDTO ticket) {
    this.ticket = ticket;
    return this;
  }

  /**
   * Get ticket
   * @return ticket
   **/
  @Schema(description = "")
  
    @Valid
    public TicketDTO getTicket() {
    return ticket;
  }

  public void setTicket(TicketDTO ticket) {
    this.ticket = ticket;
  }

  public EventiAzioniDTO rifNumerico(String rifNumerico) {
    this.rifNumerico = rifNumerico;
    return this;
  }

  /**
   * Get rifNumerico
   * @return rifNumerico
   **/
  @Schema(description = "")
  
    public String getRifNumerico() {
    return rifNumerico;
  }

  public void setRifNumerico(String rifNumerico) {
    this.rifNumerico = rifNumerico;
  }

  public EventiAzioniDTO dataTraffico(String dataTraffico) {
    this.dataTraffico = dataTraffico;
    return this;
  }

  /**
   * Get dataTraffico
   * @return dataTraffico
   **/
  @Schema(description = "")
  
    public String getDataTraffico() {
    return dataTraffico;
  }

  public void setDataTraffico(String dataTraffico) {
    this.dataTraffico = dataTraffico;
  }

  public EventiAzioniDTO mese(String mese) {
    this.mese = mese;
    return this;
  }

  /**
   * Get mese
   * @return mese
   **/
  @Schema(description = "")
  
    public String getMese() {
    return mese;
  }

  public void setMese(String mese) {
    this.mese = mese;
  }

  public EventiAzioniDTO fonte(String fonte) {
    this.fonte = fonte;
    return this;
  }

  /**
   * Get fonte
   * @return fonte
   **/
  @Schema(description = "")
  
    public String getFonte() {
    return fonte;
  }

  public void setFonte(String fonte) {
    this.fonte = fonte;
  }

  public EventiAzioniDTO troubleTicket(String troubleTicket) {
    this.troubleTicket = troubleTicket;
    return this;
  }

  /**
   * Get troubleTicket
   * @return troubleTicket
   **/
  @Schema(description = "")
  
    public String getTroubleTicket() {
    return troubleTicket;
  }

  public void setTroubleTicket(String troubleTicket) {
    this.troubleTicket = troubleTicket;
  }

  public EventiAzioniDTO destination(String destination) {
    this.destination = destination;
    return this;
  }

  /**
   * Get destination
   * @return destination
   **/
  @Schema(description = "")
  
    public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
  }

  public EventiAzioniDTO istrin(String istrin) {
    this.istrin = istrin;
    return this;
  }

  /**
   * Get istrin
   * @return istrin
   **/
  @Schema(description = "")
  
    public String getIstrin() {
    return istrin;
  }

  public void setIstrin(String istrin) {
    this.istrin = istrin;
  }

  public EventiAzioniDTO percentInstradamento(String percentInstradamento) {
    this.percentInstradamento = percentInstradamento;
    return this;
  }

  /**
   * Get percentInstradamento
   * @return percentInstradamento
   **/
  @Schema(description = "")
  
    public String getPercentInstradamento() {
    return percentInstradamento;
  }

  public void setPercentInstradamento(String percentInstradamento) {
    this.percentInstradamento = percentInstradamento;
  }

  public EventiAzioniDTO istrout(String istrout) {
    this.istrout = istrout;
    return this;
  }

  /**
   * Get istrout
   * @return istrout
   **/
  @Schema(description = "")
  
    public String getIstrout() {
    return istrout;
  }

  public void setIstrout(String istrout) {
    this.istrout = istrout;
  }

  public EventiAzioniDTO minuti(String minuti) {
    this.minuti = minuti;
    return this;
  }

  /**
   * Get minuti
   * @return minuti
   **/
  @Schema(description = "")
  
    public String getMinuti() {
    return minuti;
  }

  public void setMinuti(String minuti) {
    this.minuti = minuti;
  }

  public EventiAzioniDTO costoMin(String costoMin) {
    this.costoMin = costoMin;
    return this;
  }

  /**
   * Get costoMin
   * @return costoMin
   **/
  @Schema(description = "")
  
    public String getCostoMin() {
    return costoMin;
  }

  public void setCostoMin(String costoMin) {
    this.costoMin = costoMin;
  }

  public EventiAzioniDTO costoManual(Boolean costoManual) {
    this.costoManual = costoManual;
    return this;
  }

  /**
   * Get costoManual
   * @return costoManual
   **/
  @Schema(description = "")
  
    public Boolean isCostoManual() {
    return costoManual;
  }

  public void setCostoManual(Boolean costoManual) {
    this.costoManual = costoManual;
  }

  public EventiAzioniDTO costoDanger(Boolean costoDanger) {
    this.costoDanger = costoDanger;
    return this;
  }

  /**
   * Get costoDanger
   * @return costoDanger
   **/
  @Schema(description = "")
  
    public Boolean isCostoDanger() {
    return costoDanger;
  }

  public void setCostoDanger(Boolean costoDanger) {
    this.costoDanger = costoDanger;
  }

  public EventiAzioniDTO valorizzazione(String valorizzazione) {
    this.valorizzazione = valorizzazione;
    return this;
  }

  /**
   * Get valorizzazione
   * @return valorizzazione
   **/
  @Schema(description = "")
  
    public String getValorizzazione() {
    return valorizzazione;
  }

  public void setValorizzazione(String valorizzazione) {
    this.valorizzazione = valorizzazione;
  }

  public EventiAzioniDTO testAttivitaDetectionNoc(String testAttivitaDetectionNoc) {
    this.testAttivitaDetectionNoc = testAttivitaDetectionNoc;
    return this;
  }

  /**
   * Get testAttivitaDetectionNoc
   * @return testAttivitaDetectionNoc
   **/
  @Schema(description = "")
  
    public String getTestAttivitaDetectionNoc() {
    return testAttivitaDetectionNoc;
  }

  public void setTestAttivitaDetectionNoc(String testAttivitaDetectionNoc) {
    this.testAttivitaDetectionNoc = testAttivitaDetectionNoc;
  }

  public EventiAzioniDTO richiestaBarraggio(String richiestaBarraggio) {
    this.richiestaBarraggio = richiestaBarraggio;
    return this;
  }

  /**
   * Get richiestaBarraggio
   * @return richiestaBarraggio
   **/
  @Schema(description = "")
  
    public String getRichiestaBarraggio() {
    return richiestaBarraggio;
  }

  public void setRichiestaBarraggio(String richiestaBarraggio) {
    this.richiestaBarraggio = richiestaBarraggio;
  }

  public EventiAzioniDTO richiestaBarraggioCompact(String richiestaBarraggioCompact) {
    this.richiestaBarraggioCompact = richiestaBarraggioCompact;
    return this;
  }

  /**
   * Get richiestaBarraggioCompact
   * @return richiestaBarraggioCompact
   **/
  @Schema(description = "")
  
    public String getRichiestaBarraggioCompact() {
    return richiestaBarraggioCompact;
  }

  public void setRichiestaBarraggioCompact(String richiestaBarraggioCompact) {
    this.richiestaBarraggioCompact = richiestaBarraggioCompact;
  }

  public EventiAzioniDTO rifCompleto(String rifCompleto) {
    this.rifCompleto = rifCompleto;
    return this;
  }

  /**
   * Get rifCompleto
   * @return rifCompleto
   **/
  @Schema(description = "")
  
    public String getRifCompleto() {
    return rifCompleto;
  }

  public void setRifCompleto(String rifCompleto) {
    this.rifCompleto = rifCompleto;
  }

  public EventiAzioniDTO rifSequence(String rifSequence) {
    this.rifSequence = rifSequence;
    return this;
  }

  /**
   * Get rifSequence
   * @return rifSequence
   **/
  @Schema(description = "")
  
    public String getRifSequence() {
    return rifSequence;
  }

  public void setRifSequence(String rifSequence) {
    this.rifSequence = rifSequence;
  }

  public EventiAzioniDTO troubleTicketSenzaZeri(String troubleTicketSenzaZeri) {
    this.troubleTicketSenzaZeri = troubleTicketSenzaZeri;
    return this;
  }

  /**
   * Get troubleTicketSenzaZeri
   * @return troubleTicketSenzaZeri
   **/
  @Schema(description = "")
  
    public String getTroubleTicketSenzaZeri() {
    return troubleTicketSenzaZeri;
  }

  public void setTroubleTicketSenzaZeri(String troubleTicketSenzaZeri) {
    this.troubleTicketSenzaZeri = troubleTicketSenzaZeri;
  }

  public EventiAzioniDTO eventi(List<EventiDTO> eventi) {
    this.eventi = eventi;
    return this;
  }

  public EventiAzioniDTO addEventiItem(EventiDTO eventiItem) {
    if (this.eventi == null) {
      this.eventi = new ArrayList<EventiDTO>();
    }
    this.eventi.add(eventiItem);
    return this;
  }

  /**
   * Get eventi
   * @return eventi
   **/
  @Schema(description = "")
      @Valid
    public List<EventiDTO> getEventi() {
    return eventi;
  }

  public void setEventi(List<EventiDTO> eventi) {
    this.eventi = eventi;
  }

  public EventiAzioniDTO azioni(List<TicketAzioniDTO> azioni) {
    this.azioni = azioni;
    return this;
  }

  public EventiAzioniDTO addAzioniItem(TicketAzioniDTO azioniItem) {
    if (this.azioni == null) {
      this.azioni = new ArrayList<TicketAzioniDTO>();
    }
    this.azioni.add(azioniItem);
    return this;
  }

  /**
   * Get azioni
   * @return azioni
   **/
  @Schema(description = "")
      @Valid
    public List<TicketAzioniDTO> getAzioni() {
    return azioni;
  }

  public void setAzioni(List<TicketAzioniDTO> azioni) {
    this.azioni = azioni;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EventiAzioniDTO eventiAzioniDTO = (EventiAzioniDTO) o;
    return Objects.equals(this.ticket, eventiAzioniDTO.ticket) &&
        Objects.equals(this.rifNumerico, eventiAzioniDTO.rifNumerico) &&
        Objects.equals(this.dataTraffico, eventiAzioniDTO.dataTraffico) &&
        Objects.equals(this.mese, eventiAzioniDTO.mese) &&
        Objects.equals(this.fonte, eventiAzioniDTO.fonte) &&
        Objects.equals(this.troubleTicket, eventiAzioniDTO.troubleTicket) &&
        Objects.equals(this.destination, eventiAzioniDTO.destination) &&
        Objects.equals(this.istrin, eventiAzioniDTO.istrin) &&
        Objects.equals(this.percentInstradamento, eventiAzioniDTO.percentInstradamento) &&
        Objects.equals(this.istrout, eventiAzioniDTO.istrout) &&
        Objects.equals(this.minuti, eventiAzioniDTO.minuti) &&
        Objects.equals(this.costoMin, eventiAzioniDTO.costoMin) &&
        Objects.equals(this.costoManual, eventiAzioniDTO.costoManual) &&
        Objects.equals(this.costoDanger, eventiAzioniDTO.costoDanger) &&
        Objects.equals(this.valorizzazione, eventiAzioniDTO.valorizzazione) &&
        Objects.equals(this.testAttivitaDetectionNoc, eventiAzioniDTO.testAttivitaDetectionNoc) &&
        Objects.equals(this.richiestaBarraggio, eventiAzioniDTO.richiestaBarraggio) &&
        Objects.equals(this.richiestaBarraggioCompact, eventiAzioniDTO.richiestaBarraggioCompact) &&
        Objects.equals(this.rifCompleto, eventiAzioniDTO.rifCompleto) &&
        Objects.equals(this.rifSequence, eventiAzioniDTO.rifSequence) &&
        Objects.equals(this.troubleTicketSenzaZeri, eventiAzioniDTO.troubleTicketSenzaZeri) &&
        Objects.equals(this.eventi, eventiAzioniDTO.eventi) &&
        Objects.equals(this.azioni, eventiAzioniDTO.azioni);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ticket, rifNumerico, dataTraffico, mese, fonte, troubleTicket, destination, istrin, percentInstradamento, istrout, minuti, costoMin, costoManual, costoDanger, valorizzazione, testAttivitaDetectionNoc, richiestaBarraggio, richiestaBarraggioCompact, rifCompleto, rifSequence, troubleTicketSenzaZeri, eventi, azioni);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EventiAzioniDTO {\n");
    
    sb.append("    ticket: ").append(toIndentedString(ticket)).append("\n");
    sb.append("    rifNumerico: ").append(toIndentedString(rifNumerico)).append("\n");
    sb.append("    dataTraffico: ").append(toIndentedString(dataTraffico)).append("\n");
    sb.append("    mese: ").append(toIndentedString(mese)).append("\n");
    sb.append("    fonte: ").append(toIndentedString(fonte)).append("\n");
    sb.append("    troubleTicket: ").append(toIndentedString(troubleTicket)).append("\n");
    sb.append("    destination: ").append(toIndentedString(destination)).append("\n");
    sb.append("    istrin: ").append(toIndentedString(istrin)).append("\n");
    sb.append("    percentInstradamento: ").append(toIndentedString(percentInstradamento)).append("\n");
    sb.append("    istrout: ").append(toIndentedString(istrout)).append("\n");
    sb.append("    minuti: ").append(toIndentedString(minuti)).append("\n");
    sb.append("    costoMin: ").append(toIndentedString(costoMin)).append("\n");
    sb.append("    costoManual: ").append(toIndentedString(costoManual)).append("\n");
    sb.append("    costoDanger: ").append(toIndentedString(costoDanger)).append("\n");
    sb.append("    valorizzazione: ").append(toIndentedString(valorizzazione)).append("\n");
    sb.append("    testAttivitaDetectionNoc: ").append(toIndentedString(testAttivitaDetectionNoc)).append("\n");
    sb.append("    richiestaBarraggio: ").append(toIndentedString(richiestaBarraggio)).append("\n");
    sb.append("    richiestaBarraggioCompact: ").append(toIndentedString(richiestaBarraggioCompact)).append("\n");
    sb.append("    rifCompleto: ").append(toIndentedString(rifCompleto)).append("\n");
    sb.append("    rifSequence: ").append(toIndentedString(rifSequence)).append("\n");
    sb.append("    troubleTicketSenzaZeri: ").append(toIndentedString(troubleTicketSenzaZeri)).append("\n");
    sb.append("    eventi: ").append(toIndentedString(eventi)).append("\n");
    sb.append("    azioni: ").append(toIndentedString(azioni)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
