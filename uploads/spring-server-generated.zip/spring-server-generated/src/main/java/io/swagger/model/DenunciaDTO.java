package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * DenunciaDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class DenunciaDTO   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("rifId")
  private String rifId = null;

  @JsonProperty("dataRilevamento")
  private OffsetDateTime dataRilevamento = null;

  @JsonProperty("subRif")
  private String subRif = null;

  @JsonProperty("titolo")
  private String titolo = null;

  @JsonProperty("minuti")
  private BigDecimal minuti = null;

  @JsonProperty("valorizzazione")
  private BigDecimal valorizzazione = null;

  @JsonProperty("note")
  private String note = null;

  @JsonProperty("result")
  private String result = null;

  public DenunciaDTO id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public DenunciaDTO rifId(String rifId) {
    this.rifId = rifId;
    return this;
  }

  /**
   * Get rifId
   * @return rifId
   **/
  @Schema(description = "")
  
    public String getRifId() {
    return rifId;
  }

  public void setRifId(String rifId) {
    this.rifId = rifId;
  }

  public DenunciaDTO dataRilevamento(OffsetDateTime dataRilevamento) {
    this.dataRilevamento = dataRilevamento;
    return this;
  }

  /**
   * Get dataRilevamento
   * @return dataRilevamento
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDataRilevamento() {
    return dataRilevamento;
  }

  public void setDataRilevamento(OffsetDateTime dataRilevamento) {
    this.dataRilevamento = dataRilevamento;
  }

  public DenunciaDTO subRif(String subRif) {
    this.subRif = subRif;
    return this;
  }

  /**
   * Get subRif
   * @return subRif
   **/
  @Schema(description = "")
  
    public String getSubRif() {
    return subRif;
  }

  public void setSubRif(String subRif) {
    this.subRif = subRif;
  }

  public DenunciaDTO titolo(String titolo) {
    this.titolo = titolo;
    return this;
  }

  /**
   * Get titolo
   * @return titolo
   **/
  @Schema(description = "")
  
    public String getTitolo() {
    return titolo;
  }

  public void setTitolo(String titolo) {
    this.titolo = titolo;
  }

  public DenunciaDTO minuti(BigDecimal minuti) {
    this.minuti = minuti;
    return this;
  }

  /**
   * Get minuti
   * @return minuti
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getMinuti() {
    return minuti;
  }

  public void setMinuti(BigDecimal minuti) {
    this.minuti = minuti;
  }

  public DenunciaDTO valorizzazione(BigDecimal valorizzazione) {
    this.valorizzazione = valorizzazione;
    return this;
  }

  /**
   * Get valorizzazione
   * @return valorizzazione
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getValorizzazione() {
    return valorizzazione;
  }

  public void setValorizzazione(BigDecimal valorizzazione) {
    this.valorizzazione = valorizzazione;
  }

  public DenunciaDTO note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
   **/
  @Schema(description = "")
  
    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public DenunciaDTO result(String result) {
    this.result = result;
    return this;
  }

  /**
   * Get result
   * @return result
   **/
  @Schema(description = "")
  
    public String getResult() {
    return result;
  }

  public void setResult(String result) {
    this.result = result;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DenunciaDTO denunciaDTO = (DenunciaDTO) o;
    return Objects.equals(this.id, denunciaDTO.id) &&
        Objects.equals(this.rifId, denunciaDTO.rifId) &&
        Objects.equals(this.dataRilevamento, denunciaDTO.dataRilevamento) &&
        Objects.equals(this.subRif, denunciaDTO.subRif) &&
        Objects.equals(this.titolo, denunciaDTO.titolo) &&
        Objects.equals(this.minuti, denunciaDTO.minuti) &&
        Objects.equals(this.valorizzazione, denunciaDTO.valorizzazione) &&
        Objects.equals(this.note, denunciaDTO.note) &&
        Objects.equals(this.result, denunciaDTO.result);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, rifId, dataRilevamento, subRif, titolo, minuti, valorizzazione, note, result);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DenunciaDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    rifId: ").append(toIndentedString(rifId)).append("\n");
    sb.append("    dataRilevamento: ").append(toIndentedString(dataRilevamento)).append("\n");
    sb.append("    subRif: ").append(toIndentedString(subRif)).append("\n");
    sb.append("    titolo: ").append(toIndentedString(titolo)).append("\n");
    sb.append("    minuti: ").append(toIndentedString(minuti)).append("\n");
    sb.append("    valorizzazione: ").append(toIndentedString(valorizzazione)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    result: ").append(toIndentedString(result)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
