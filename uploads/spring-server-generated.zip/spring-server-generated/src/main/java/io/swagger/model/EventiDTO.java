package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.CarrierDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * EventiDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class EventiDTO   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("calledNumber")
  private String calledNumber = null;

  @JsonProperty("data")
  private OffsetDateTime data = null;

  @JsonProperty("troubleTicketBlock")
  private String troubleTicketBlock = null;

  @JsonProperty("troubleTicketReopen")
  private String troubleTicketReopen = null;

  @JsonProperty("blockedAgain")
  private String blockedAgain = null;

  @JsonProperty("verified")
  private String verified = null;

  @JsonProperty("firstDetection")
  private OffsetDateTime firstDetection = null;

  @JsonProperty("sellingDestination")
  private String sellingDestination = null;

  @JsonProperty("routingDestination")
  private String routingDestination = null;

  @JsonProperty("routeClass")
  private String routeClass = null;

  @JsonProperty("seized")
  private String seized = null;

  @JsonProperty("answered")
  private String answered = null;

  @JsonProperty("asr")
  private String asr = null;

  @JsonProperty("aloc")
  private String aloc = null;

  @JsonProperty("replyDelay")
  private String replyDelay = null;

  @JsonProperty("minutes")
  private String minutes = null;

  @JsonProperty("cost")
  private String cost = null;

  @JsonProperty("countryCode")
  private String countryCode = null;

  @JsonProperty("totalCost")
  private String totalCost = null;

  @JsonProperty("retroDate")
  private OffsetDateTime retroDate = null;

  @JsonProperty("retroMinutes")
  private String retroMinutes = null;

  @JsonProperty("clis")
  private String clis = null;

  @JsonProperty("carrierIn")
  @Valid
  private List<CarrierDTO> carrierIn = null;

  @JsonProperty("carrierOut")
  @Valid
  private List<CarrierDTO> carrierOut = null;

  public EventiDTO id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public EventiDTO calledNumber(String calledNumber) {
    this.calledNumber = calledNumber;
    return this;
  }

  /**
   * Get calledNumber
   * @return calledNumber
   **/
  @Schema(description = "")
  
    public String getCalledNumber() {
    return calledNumber;
  }

  public void setCalledNumber(String calledNumber) {
    this.calledNumber = calledNumber;
  }

  public EventiDTO data(OffsetDateTime data) {
    this.data = data;
    return this;
  }

  /**
   * Get data
   * @return data
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getData() {
    return data;
  }

  public void setData(OffsetDateTime data) {
    this.data = data;
  }

  public EventiDTO troubleTicketBlock(String troubleTicketBlock) {
    this.troubleTicketBlock = troubleTicketBlock;
    return this;
  }

  /**
   * Get troubleTicketBlock
   * @return troubleTicketBlock
   **/
  @Schema(description = "")
  
    public String getTroubleTicketBlock() {
    return troubleTicketBlock;
  }

  public void setTroubleTicketBlock(String troubleTicketBlock) {
    this.troubleTicketBlock = troubleTicketBlock;
  }

  public EventiDTO troubleTicketReopen(String troubleTicketReopen) {
    this.troubleTicketReopen = troubleTicketReopen;
    return this;
  }

  /**
   * Get troubleTicketReopen
   * @return troubleTicketReopen
   **/
  @Schema(description = "")
  
    public String getTroubleTicketReopen() {
    return troubleTicketReopen;
  }

  public void setTroubleTicketReopen(String troubleTicketReopen) {
    this.troubleTicketReopen = troubleTicketReopen;
  }

  public EventiDTO blockedAgain(String blockedAgain) {
    this.blockedAgain = blockedAgain;
    return this;
  }

  /**
   * Get blockedAgain
   * @return blockedAgain
   **/
  @Schema(description = "")
  
    public String getBlockedAgain() {
    return blockedAgain;
  }

  public void setBlockedAgain(String blockedAgain) {
    this.blockedAgain = blockedAgain;
  }

  public EventiDTO verified(String verified) {
    this.verified = verified;
    return this;
  }

  /**
   * Get verified
   * @return verified
   **/
  @Schema(description = "")
  
    public String getVerified() {
    return verified;
  }

  public void setVerified(String verified) {
    this.verified = verified;
  }

  public EventiDTO firstDetection(OffsetDateTime firstDetection) {
    this.firstDetection = firstDetection;
    return this;
  }

  /**
   * Get firstDetection
   * @return firstDetection
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getFirstDetection() {
    return firstDetection;
  }

  public void setFirstDetection(OffsetDateTime firstDetection) {
    this.firstDetection = firstDetection;
  }

  public EventiDTO sellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
    return this;
  }

  /**
   * Get sellingDestination
   * @return sellingDestination
   **/
  @Schema(description = "")
  
    public String getSellingDestination() {
    return sellingDestination;
  }

  public void setSellingDestination(String sellingDestination) {
    this.sellingDestination = sellingDestination;
  }

  public EventiDTO routingDestination(String routingDestination) {
    this.routingDestination = routingDestination;
    return this;
  }

  /**
   * Get routingDestination
   * @return routingDestination
   **/
  @Schema(description = "")
  
    public String getRoutingDestination() {
    return routingDestination;
  }

  public void setRoutingDestination(String routingDestination) {
    this.routingDestination = routingDestination;
  }

  public EventiDTO routeClass(String routeClass) {
    this.routeClass = routeClass;
    return this;
  }

  /**
   * Get routeClass
   * @return routeClass
   **/
  @Schema(description = "")
  
    public String getRouteClass() {
    return routeClass;
  }

  public void setRouteClass(String routeClass) {
    this.routeClass = routeClass;
  }

  public EventiDTO seized(String seized) {
    this.seized = seized;
    return this;
  }

  /**
   * Get seized
   * @return seized
   **/
  @Schema(description = "")
  
    public String getSeized() {
    return seized;
  }

  public void setSeized(String seized) {
    this.seized = seized;
  }

  public EventiDTO answered(String answered) {
    this.answered = answered;
    return this;
  }

  /**
   * Get answered
   * @return answered
   **/
  @Schema(description = "")
  
    public String getAnswered() {
    return answered;
  }

  public void setAnswered(String answered) {
    this.answered = answered;
  }

  public EventiDTO asr(String asr) {
    this.asr = asr;
    return this;
  }

  /**
   * Get asr
   * @return asr
   **/
  @Schema(description = "")
  
    public String getAsr() {
    return asr;
  }

  public void setAsr(String asr) {
    this.asr = asr;
  }

  public EventiDTO aloc(String aloc) {
    this.aloc = aloc;
    return this;
  }

  /**
   * Get aloc
   * @return aloc
   **/
  @Schema(description = "")
  
    public String getAloc() {
    return aloc;
  }

  public void setAloc(String aloc) {
    this.aloc = aloc;
  }

  public EventiDTO replyDelay(String replyDelay) {
    this.replyDelay = replyDelay;
    return this;
  }

  /**
   * Get replyDelay
   * @return replyDelay
   **/
  @Schema(description = "")
  
    public String getReplyDelay() {
    return replyDelay;
  }

  public void setReplyDelay(String replyDelay) {
    this.replyDelay = replyDelay;
  }

  public EventiDTO minutes(String minutes) {
    this.minutes = minutes;
    return this;
  }

  /**
   * Get minutes
   * @return minutes
   **/
  @Schema(description = "")
  
    public String getMinutes() {
    return minutes;
  }

  public void setMinutes(String minutes) {
    this.minutes = minutes;
  }

  public EventiDTO cost(String cost) {
    this.cost = cost;
    return this;
  }

  /**
   * Get cost
   * @return cost
   **/
  @Schema(description = "")
  
    public String getCost() {
    return cost;
  }

  public void setCost(String cost) {
    this.cost = cost;
  }

  public EventiDTO countryCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Get countryCode
   * @return countryCode
   **/
  @Schema(description = "")
  
    public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public EventiDTO totalCost(String totalCost) {
    this.totalCost = totalCost;
    return this;
  }

  /**
   * Get totalCost
   * @return totalCost
   **/
  @Schema(description = "")
  
    public String getTotalCost() {
    return totalCost;
  }

  public void setTotalCost(String totalCost) {
    this.totalCost = totalCost;
  }

  public EventiDTO retroDate(OffsetDateTime retroDate) {
    this.retroDate = retroDate;
    return this;
  }

  /**
   * Get retroDate
   * @return retroDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getRetroDate() {
    return retroDate;
  }

  public void setRetroDate(OffsetDateTime retroDate) {
    this.retroDate = retroDate;
  }

  public EventiDTO retroMinutes(String retroMinutes) {
    this.retroMinutes = retroMinutes;
    return this;
  }

  /**
   * Get retroMinutes
   * @return retroMinutes
   **/
  @Schema(description = "")
  
    public String getRetroMinutes() {
    return retroMinutes;
  }

  public void setRetroMinutes(String retroMinutes) {
    this.retroMinutes = retroMinutes;
  }

  public EventiDTO clis(String clis) {
    this.clis = clis;
    return this;
  }

  /**
   * Get clis
   * @return clis
   **/
  @Schema(description = "")
  
    public String getClis() {
    return clis;
  }

  public void setClis(String clis) {
    this.clis = clis;
  }

  public EventiDTO carrierIn(List<CarrierDTO> carrierIn) {
    this.carrierIn = carrierIn;
    return this;
  }

  public EventiDTO addCarrierInItem(CarrierDTO carrierInItem) {
    if (this.carrierIn == null) {
      this.carrierIn = new ArrayList<CarrierDTO>();
    }
    this.carrierIn.add(carrierInItem);
    return this;
  }

  /**
   * Get carrierIn
   * @return carrierIn
   **/
  @Schema(description = "")
      @Valid
    public List<CarrierDTO> getCarrierIn() {
    return carrierIn;
  }

  public void setCarrierIn(List<CarrierDTO> carrierIn) {
    this.carrierIn = carrierIn;
  }

  public EventiDTO carrierOut(List<CarrierDTO> carrierOut) {
    this.carrierOut = carrierOut;
    return this;
  }

  public EventiDTO addCarrierOutItem(CarrierDTO carrierOutItem) {
    if (this.carrierOut == null) {
      this.carrierOut = new ArrayList<CarrierDTO>();
    }
    this.carrierOut.add(carrierOutItem);
    return this;
  }

  /**
   * Get carrierOut
   * @return carrierOut
   **/
  @Schema(description = "")
      @Valid
    public List<CarrierDTO> getCarrierOut() {
    return carrierOut;
  }

  public void setCarrierOut(List<CarrierDTO> carrierOut) {
    this.carrierOut = carrierOut;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EventiDTO eventiDTO = (EventiDTO) o;
    return Objects.equals(this.id, eventiDTO.id) &&
        Objects.equals(this.calledNumber, eventiDTO.calledNumber) &&
        Objects.equals(this.data, eventiDTO.data) &&
        Objects.equals(this.troubleTicketBlock, eventiDTO.troubleTicketBlock) &&
        Objects.equals(this.troubleTicketReopen, eventiDTO.troubleTicketReopen) &&
        Objects.equals(this.blockedAgain, eventiDTO.blockedAgain) &&
        Objects.equals(this.verified, eventiDTO.verified) &&
        Objects.equals(this.firstDetection, eventiDTO.firstDetection) &&
        Objects.equals(this.sellingDestination, eventiDTO.sellingDestination) &&
        Objects.equals(this.routingDestination, eventiDTO.routingDestination) &&
        Objects.equals(this.routeClass, eventiDTO.routeClass) &&
        Objects.equals(this.seized, eventiDTO.seized) &&
        Objects.equals(this.answered, eventiDTO.answered) &&
        Objects.equals(this.asr, eventiDTO.asr) &&
        Objects.equals(this.aloc, eventiDTO.aloc) &&
        Objects.equals(this.replyDelay, eventiDTO.replyDelay) &&
        Objects.equals(this.minutes, eventiDTO.minutes) &&
        Objects.equals(this.cost, eventiDTO.cost) &&
        Objects.equals(this.countryCode, eventiDTO.countryCode) &&
        Objects.equals(this.totalCost, eventiDTO.totalCost) &&
        Objects.equals(this.retroDate, eventiDTO.retroDate) &&
        Objects.equals(this.retroMinutes, eventiDTO.retroMinutes) &&
        Objects.equals(this.clis, eventiDTO.clis) &&
        Objects.equals(this.carrierIn, eventiDTO.carrierIn) &&
        Objects.equals(this.carrierOut, eventiDTO.carrierOut);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, calledNumber, data, troubleTicketBlock, troubleTicketReopen, blockedAgain, verified, firstDetection, sellingDestination, routingDestination, routeClass, seized, answered, asr, aloc, replyDelay, minutes, cost, countryCode, totalCost, retroDate, retroMinutes, clis, carrierIn, carrierOut);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EventiDTO {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    calledNumber: ").append(toIndentedString(calledNumber)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    troubleTicketBlock: ").append(toIndentedString(troubleTicketBlock)).append("\n");
    sb.append("    troubleTicketReopen: ").append(toIndentedString(troubleTicketReopen)).append("\n");
    sb.append("    blockedAgain: ").append(toIndentedString(blockedAgain)).append("\n");
    sb.append("    verified: ").append(toIndentedString(verified)).append("\n");
    sb.append("    firstDetection: ").append(toIndentedString(firstDetection)).append("\n");
    sb.append("    sellingDestination: ").append(toIndentedString(sellingDestination)).append("\n");
    sb.append("    routingDestination: ").append(toIndentedString(routingDestination)).append("\n");
    sb.append("    routeClass: ").append(toIndentedString(routeClass)).append("\n");
    sb.append("    seized: ").append(toIndentedString(seized)).append("\n");
    sb.append("    answered: ").append(toIndentedString(answered)).append("\n");
    sb.append("    asr: ").append(toIndentedString(asr)).append("\n");
    sb.append("    aloc: ").append(toIndentedString(aloc)).append("\n");
    sb.append("    replyDelay: ").append(toIndentedString(replyDelay)).append("\n");
    sb.append("    minutes: ").append(toIndentedString(minutes)).append("\n");
    sb.append("    cost: ").append(toIndentedString(cost)).append("\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("    totalCost: ").append(toIndentedString(totalCost)).append("\n");
    sb.append("    retroDate: ").append(toIndentedString(retroDate)).append("\n");
    sb.append("    retroMinutes: ").append(toIndentedString(retroMinutes)).append("\n");
    sb.append("    clis: ").append(toIndentedString(clis)).append("\n");
    sb.append("    carrierIn: ").append(toIndentedString(carrierIn)).append("\n");
    sb.append("    carrierOut: ").append(toIndentedString(carrierOut)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
