package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.HistoryDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * HistoryResponseDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class HistoryResponseDTO   {
  @JsonProperty("page")
  private Integer page = null;

  @JsonProperty("size")
  private Integer size = null;

  @JsonProperty("totalrecord")
  private Long totalrecord = null;

  @JsonProperty("historyDTOs")
  @Valid
  private List<HistoryDTO> historyDTOs = null;

  public HistoryResponseDTO page(Integer page) {
    this.page = page;
    return this;
  }

  /**
   * Get page
   * @return page
   **/
  @Schema(description = "")
  
    public Integer getPage() {
    return page;
  }

  public void setPage(Integer page) {
    this.page = page;
  }

  public HistoryResponseDTO size(Integer size) {
    this.size = size;
    return this;
  }

  /**
   * Get size
   * @return size
   **/
  @Schema(description = "")
  
    public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public HistoryResponseDTO totalrecord(Long totalrecord) {
    this.totalrecord = totalrecord;
    return this;
  }

  /**
   * Get totalrecord
   * @return totalrecord
   **/
  @Schema(description = "")
  
    public Long getTotalrecord() {
    return totalrecord;
  }

  public void setTotalrecord(Long totalrecord) {
    this.totalrecord = totalrecord;
  }

  public HistoryResponseDTO historyDTOs(List<HistoryDTO> historyDTOs) {
    this.historyDTOs = historyDTOs;
    return this;
  }

  public HistoryResponseDTO addHistoryDTOsItem(HistoryDTO historyDTOsItem) {
    if (this.historyDTOs == null) {
      this.historyDTOs = new ArrayList<HistoryDTO>();
    }
    this.historyDTOs.add(historyDTOsItem);
    return this;
  }

  /**
   * Get historyDTOs
   * @return historyDTOs
   **/
  @Schema(description = "")
      @Valid
    public List<HistoryDTO> getHistoryDTOs() {
    return historyDTOs;
  }

  public void setHistoryDTOs(List<HistoryDTO> historyDTOs) {
    this.historyDTOs = historyDTOs;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HistoryResponseDTO historyResponseDTO = (HistoryResponseDTO) o;
    return Objects.equals(this.page, historyResponseDTO.page) &&
        Objects.equals(this.size, historyResponseDTO.size) &&
        Objects.equals(this.totalrecord, historyResponseDTO.totalrecord) &&
        Objects.equals(this.historyDTOs, historyResponseDTO.historyDTOs);
  }

  @Override
  public int hashCode() {
    return Objects.hash(page, size, totalrecord, historyDTOs);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HistoryResponseDTO {\n");
    
    sb.append("    page: ").append(toIndentedString(page)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    totalrecord: ").append(toIndentedString(totalrecord)).append("\n");
    sb.append("    historyDTOs: ").append(toIndentedString(historyDTOs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
