package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ReferenceDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-28T14:14:07.966666128Z[GMT]")


public class ReferenceDTO   {
  @JsonProperty("alarmReferenceType")
  private String alarmReferenceType = null;

  @JsonProperty("alarmReferenceValue")
  private String alarmReferenceValue = null;

  public ReferenceDTO alarmReferenceType(String alarmReferenceType) {
    this.alarmReferenceType = alarmReferenceType;
    return this;
  }

  /**
   * Get alarmReferenceType
   * @return alarmReferenceType
   **/
  @Schema(description = "")
  
    public String getAlarmReferenceType() {
    return alarmReferenceType;
  }

  public void setAlarmReferenceType(String alarmReferenceType) {
    this.alarmReferenceType = alarmReferenceType;
  }

  public ReferenceDTO alarmReferenceValue(String alarmReferenceValue) {
    this.alarmReferenceValue = alarmReferenceValue;
    return this;
  }

  /**
   * Get alarmReferenceValue
   * @return alarmReferenceValue
   **/
  @Schema(description = "")
  
    public String getAlarmReferenceValue() {
    return alarmReferenceValue;
  }

  public void setAlarmReferenceValue(String alarmReferenceValue) {
    this.alarmReferenceValue = alarmReferenceValue;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReferenceDTO referenceDTO = (ReferenceDTO) o;
    return Objects.equals(this.alarmReferenceType, referenceDTO.alarmReferenceType) &&
        Objects.equals(this.alarmReferenceValue, referenceDTO.alarmReferenceValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(alarmReferenceType, alarmReferenceValue);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReferenceDTO {\n");
    
    sb.append("    alarmReferenceType: ").append(toIndentedString(alarmReferenceType)).append("\n");
    sb.append("    alarmReferenceValue: ").append(toIndentedString(alarmReferenceValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
